 
import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { getCategories, getQuestionsByCategory } from '../../services/knowledgeBase';
import {ChevronDown, ChevronUp} from 'lucide-react';

interface CategorySelectorProps {
  selectedCategory: string | null;
  onCategorySelect: (category: string) => void;
  onQuestionSelect: (question: string) => void;
}

const CategorySelector: React.FC<CategorySelectorProps> = ({
  selectedCategory,
  onCategorySelect,
  onQuestionSelect
}) => {
  const { language } = useLanguage();
  const categories = getCategories(language);
  const [isExpanded, setIsExpanded] = useState(true);
  const [isQuestionsExpanded, setIsQuestionsExpanded] = useState(true);

  if (selectedCategory) {
    const questions = getQuestionsByCategory(selectedCategory, language);
    
    return (
      <div className="bg-white border-b border-gray-200">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-2">
            <h4 className="font-medium text-gray-800 text-sm">
              {selectedCategory}
            </h4>
            <button
              onClick={() => setIsQuestionsExpanded(!isQuestionsExpanded)}
              className="p-1 hover:bg-gray-100 rounded transition-colors"
            >
              {isQuestionsExpanded ? (
                <ChevronUp className="w-4 h-4 text-gray-600" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-600" />
              )}
            </button>
          </div>
          <button
            onClick={() => onCategorySelect('')}
            className="text-xs text-green-600 hover:text-green-700 font-medium"
          >
            {language === 'zh' ? '返回分類' : 'Back to Categories'}
          </button>
        </div>
        
        {isQuestionsExpanded && (
          <div className="px-4 pb-4 space-y-2 max-h-40 overflow-y-auto">
            {questions.map((item, index) => (
              <button
                key={index}
                onClick={() => onQuestionSelect(item.question)}
                className="w-full text-left text-xs text-gray-600 hover:text-green-600 hover:bg-green-50 p-2 rounded-md transition-colors border border-gray-100 hover:border-green-200"
              >
                {item.question}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-white border-b border-gray-200">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
      >
        <h4 className="font-medium text-gray-800 text-sm">
          {language === 'zh' ? '常見問題' : 'Frequently Asked Questions'}
        </h4>
        {isExpanded ? (
          <ChevronUp className="w-4 h-4 text-gray-600" />
        ) : (
          <ChevronDown className="w-4 h-4 text-gray-600" />
        )}
      </button>
      
      {isExpanded && (
        <div className="px-4 pb-4">
          <div className="grid grid-cols-2 gap-2">
            {categories.map((category, index) => (
              <button
                key={index}
                onClick={() => onCategorySelect(category)}
                className="text-xs text-gray-600 hover:text-green-600 hover:bg-green-50 p-2 rounded-md transition-colors border border-gray-100 hover:border-green-200 text-left"
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CategorySelector; 
