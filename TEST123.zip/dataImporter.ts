import Papa from 'papaparse';
import ExcelJS from 'exceljs';
import { CSVRow, ProcessedKnowledgeItem } from '../types/uploadTypes';
import { validateData, sanitizeData } from '../utils/fileValidator';
import { knowledgeBase, KnowledgeItem } from './knowledgeBase';

export class DataImporter {
  // 解析 CSV 文件
  async parseCSV(file: File): Promise<CSVRow[]> {
    return new Promise((resolve, reject) => {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        encoding: 'UTF-8',
        complete: (results) => {
          if (results.errors.length > 0) {
            reject(new Error(`CSV 解析錯誤：${results.errors.map(e => e.message).join(', ')}`));
          } else {
            resolve(results.data as CSVRow[]);
          }
        },
        error: (error) => {
          reject(new Error(`CSV 解析失敗：${error.message}`));
        }
      });
    });
  }

  // 解析 Excel 文件 - 使用 ExcelJS
  async parseExcel(file: File): Promise<CSVRow[]> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = async (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          
          const workbook = new ExcelJS.Workbook();
          await workbook.xlsx.load(data.buffer);
          
          const worksheet = workbook.worksheets[0];
          
          if (!worksheet) {
            reject(new Error('Excel 文件中沒有工作表'));
            return;
          }

          const jsonData: any[][] = [];
          
          worksheet.eachRow((row, rowNumber) => {
            const rowValues = row.values as any[];
            jsonData.push(rowValues.slice(1));
          });
          
          if (jsonData.length < 2) {
            reject(new Error('Excel 文件至少需要標題行和一行數據'));
            return;
          }

          const headers = jsonData[0].map(h => String(h || ''));
          const rows = jsonData.slice(1);

          const csvData: CSVRow[] = rows
            .filter(row => row.some(cell => cell !== null && cell !== undefined && cell !== ''))
            .map(row => {
              const obj: any = {};
              headers.forEach((header, index) => {
                const value = row[index];
                obj[header] = value !== null && value !== undefined ? String(value) : '';
              });
              return obj;
            });

          resolve(csvData);
        } catch (error) {
          reject(new Error(`Excel 解析失敗：${error instanceof Error ? error.message : String(error)}`));
        }
      };

      reader.onerror = () => {
        reject(new Error('檔案讀取失敗'));
      };

      reader.readAsArrayBuffer(file);
    });
  }

  // 解析文件（自動判斷類型）
  async parseFile(file: File): Promise<CSVRow[]> {
    const fileExtension = file.name.toLowerCase().split('.').pop();
    
    if (fileExtension === 'csv') {
      return this.parseCSV(file);
    } else if (['xlsx', 'xls'].includes(fileExtension || '')) {
      return this.parseExcel(file);
    } else {
      throw new Error('不支援的檔案格式');
    }
  }

  // 處理並導入數據
  async importData(file: File, mode: 'replace' | 'merge' = 'replace'): Promise<{
    success: boolean;
    message: string;
    stats: {
      total: number;
      zh: number;
      en: number;
      categories: string[];
    };
  }> {
    try {
      // 1. 驗證檔案
      const rawData = await this.parseFile(file);
      const validation = validateData(rawData);
      
      if (!validation.isValid) {
        throw new Error(`數據驗證失敗：\n${validation.errors.join('\n')}`);
      }

      // 2. 上傳到後端
      const formData = new FormData();
      formData.append('file', file);
      formData.append('mode', mode);

      const response = await fetch('http://localhost:3001/api/upload-knowledge', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `伺服器錯誤：${response.status}`);
      }

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.message);
      }

      // 3. 成功後重新載入頁面
      setTimeout(() => {
        window.location.reload();
      }, 1500);

      return {
        success: true,
        message: result.message,
        stats: result.stats
      };

    } catch (error) {
      return {
        success: false,
        message: `導入失敗：${error instanceof Error ? error.message : String(error)}`,
        stats: { total: 0, zh: 0, en: 0, categories: [] }
      };
    }
  }

  // 導出當前知識庫為 Excel
  async exportToExcel(): Promise<ExcelJS.Buffer> {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Knowledge Base');

    worksheet.columns = [
      { header: 'keywords', key: 'keywords', width: 30 },
      { header: 'question', key: 'question', width: 40 },
      { header: 'answer', key: 'answer', width: 60 },
      { header: 'category', key: 'category', width: 20 },
      { header: 'priority', key: 'priority', width: 10 },
      { header: 'enabled', key: 'enabled', width: 10 },
      { header: 'language', key: 'language', width: 10 }
    ];

    knowledgeBase.zh.forEach(item => {
      worksheet.addRow({
        keywords: item.keywords.join(','),
        question: item.question,
        answer: item.answer,
        category: item.category,
        priority: item.priority,
        enabled: item.enabled,
        language: 'zh'
      });
    });

    knowledgeBase.en.forEach(item => {
      worksheet.addRow({
        keywords: item.keywords.join(','),
        question: item.question,
        answer: item.answer,
        category: item.category,
        priority: item.priority,
        enabled: item.enabled,
        language: 'en'
      });
    });

    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    return await workbook.xlsx.writeBuffer();
  }

  // 下載 Excel 範本
  async downloadTemplate(): Promise<void> {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Template');

    worksheet.columns = [
      { header: 'keywords', key: 'keywords', width: 30 },
      { header: 'question', key: 'question', width: 40 },
      { header: 'answer', key: 'answer', width: 60 },
      { header: 'category', key: 'category', width: 20 },
      { header: 'priority', key: 'priority', width: 10 },
      { header: 'enabled', key: 'enabled', width: 10 },
      { header: 'language', key: 'language', width: 10 }
    ];

    worksheet.addRow({
      keywords: '澆水,頻率,多肉',
      question: '多肉植物多久澆一次水？',
      answer: '多肉澆水指南：多肉植物建議7-10天澆水一次，冬季可延長至2週。澆水要澆透，但避免積水。小撇步：觀察土壤乾燥程度，確保排水良好。',
      category: '植栽養護',
      priority: 1,
      enabled: true,
      language: 'zh'
    });

    worksheet.addRow({
      keywords: 'watering,frequency,succulent',
      question: 'How often should I water succulents?',
      answer: 'Succulent Watering Guide: Water every 7-10 days, extending to 2 weeks in winter. Water thoroughly but avoid waterlogging. Tip: Check soil dryness and ensure good drainage.',
      category: 'Plant Care',
      priority: 1,
      enabled: true,
      language: 'en'
    });

    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { 
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
    });
    
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', 'knowledge_base_template.xlsx');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setTimeout(() => URL.revokeObjectURL(url), 100);
  }

  // 導出完整知識庫為 Excel
  async downloadKnowledgeBase(): Promise<void> {
    const buffer = await this.exportToExcel();
    
    const blob = new Blob([buffer], { 
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
    });
    
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    const now = new Date();
    const timestamp = now.toISOString().slice(0, 19).replace(/[:.]/g, '-');
    const filename = `knowledge_base_export_${timestamp}.xlsx`;
    
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    setTimeout(() => URL.revokeObjectURL(url), 100);
  }
}

export const dataImporter = new DataImporter();