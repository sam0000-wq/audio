import React, { useEffect, useState } from "react"
import {X} from 'lucide-react'

interface VideoModalProps {
  isOpen: boolean
  onClose: () => void
}

const VideoModal: React.FC<VideoModalProps> = ({ isOpen, onClose }) => {
  const [isLoading, setIsLoading] = useState(true)
  const [videoSrc, setVideoSrc] = useState("")

  useEffect(() => {
    if (isOpen) {
      setIsLoading(true)
      setVideoSrc("")
      
      const videoId = "Plcv-VsZ3Uo"
      const embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1`
      
      setTimeout(() => {
        setIsLoading(false)
        setVideoSrc(embedUrl)
      }, 1500)
    } else {
      setVideoSrc("")
      setIsLoading(true)
    }
  }, [isOpen])

  useEffect(() => {
    const handleEscapeKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("keydown", handleEscapeKey)
    }

    return () => {
      document.removeEventListener("keydown", handleEscapeKey)
    }
  }, [isOpen, onClose])

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose()
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={handleBackdropClick}>
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] md:max-h-[85vh] overflow-auto relative">
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 z-10 bg-gray-800 hover:bg-gray-900 text-white rounded-full p-3 md:p-2 shadow-lg transition-all duration-200 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-gray-600 focus:ring-offset-2"
          aria-label="關閉影片"
        >
          <X className="w-6 h-6" />
        </button>
        
        {/* 載入動畫 */}
        {isLoading && (
          <div className="flex flex-col items-center justify-center p-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mb-4"></div>
            <p className="text-gray-600">正在載入影片...</p>
          </div>
        )}
        
        {/* 影片內容 */}
        {!isLoading && (
          <div className="p-4 md:p-6">
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 text-center">悅境園藝介紹</h2>
            
            <div className="relative pb-[56.25%] h-0 mb-6">
              <iframe 
                src={videoSrc}
                className="absolute top-0 left-0 w-full h-full rounded-lg"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen
                title="悅境園藝介紹影片"
              />
            </div>
            
            <div className="text-center">
              <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-400">
                <h3 className="text-green-800 font-semibold mb-2 text-sm md:text-base">園藝景觀顧問解說</h3>
                <p className="text-green-700 text-xs md:text-sm">由豐富經驗的園藝技師和景觀設計師組成,無論是科技廠區/高檔社區或是私人會所都有相當多樣的工程實績。</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default VideoModal