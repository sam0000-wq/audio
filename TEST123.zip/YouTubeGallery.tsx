import React, { useState, useEffect, useRef, useCallback, useMemo } from "react"
import {X, Play, ChevronDown, ChevronUp} from 'lucide-react'
import { useLanguage } from "../contexts/LanguageContext"
import VideoImporter from "../services/videoImporter"

interface VideoData {
  id: string
  title: string
  description: string
}

// ==========================//
// 優化的圖片預載入元件
// ==========================//
interface OptimizedThumbnailProps {
  videoId: string
  title: string
  isVisible: boolean
  onLoad?: () => void
}

const OptimizedThumbnail: React.FC<OptimizedThumbnailProps> = ({
  videoId,
  title,
  isVisible,
  onLoad,
}) => {
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)

  useEffect(() => {
    if (!isVisible) return

    const img = imgRef.current
    if (!img) return

    const thumbnailUrl = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`

    const handleLoad = () => {
      setLoaded(true)
      onLoad?.()
    }

    const handleError = () => {
      setError(true)
      if (img.src.includes("hqdefault")) {
        img.src = `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`
      }
    }

    img.addEventListener("load", handleLoad)
    img.addEventListener("error", handleError)

    img.src = thumbnailUrl

    return () => {
      img.removeEventListener("load", handleLoad)
      img.removeEventListener("error", handleError)
    }
  }, [isVisible, videoId, onLoad])

  return (
    <>
      {!loaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-200 animate-pulse">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        </div>
      )}

      <img
        ref={imgRef}
        alt={title}
        className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ${
          loaded ? "opacity-100 scale-100" : "opacity-0 scale-95"
        }`}
        style={{ display: isVisible ? "block" : "none" }}
      />

      {!loaded && (
        <div className="absolute inset-0 overflow-hidden">
          <div
            className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/20 to-transparent"
            style={{
              animation: "shimmer 2s infinite",
            }}
          />
        </div>
      )}

      <style>{`
        @keyframes shimmer {
          100% {
            transform: translateX(100%);
          }
        }
      `}</style>
    </>
  )
}

// ==========================//
// 可折疊影片卡片元件（手機專用）
// ==========================//
interface CollapsibleVideoCardProps {
  video: VideoData
  isExpanded: boolean
  onToggle: () => void
  isVisible: boolean
  onThumbnailLoad: () => void
}

const CollapsibleVideoCard: React.FC<CollapsibleVideoCardProps> = ({
  video,
  isExpanded,
  onToggle,
  isVisible,
  onThumbnailLoad,
}) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg border-2 border-emerald-100">
      {/* 標題欄（可點擊） */}
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-4 hover:bg-emerald-50 transition-colors duration-200"
      >
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {/* 縮圖 */}
          <div className="relative w-20 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-gray-200">
            <OptimizedThumbnail
              videoId={video.id}
              title={video.title}
              isVisible={isVisible}
              onLoad={onThumbnailLoad}
            />
          </div>
          {/* 標題 */}
          <div className="text-left flex-1 min-w-0">
            <h3 className="font-semibold text-gray-900 text-sm line-clamp-2">
              {video.title}
            </h3>
          </div>
        </div>
        {/* 展開/收合圖示 */}
        <div className="ml-2 flex-shrink-0">
          {isExpanded ? (
            <ChevronUp className="w-6 h-6 text-emerald-600" />
          ) : (
            <ChevronDown className="w-6 h-6 text-emerald-600" />
          )}
        </div>
      </button>

      {/* 影片播放器（展開時顯示） */}
      {isExpanded && (
        <div className="border-t border-emerald-100">
          <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
            <iframe
              src={`https://www.youtube.com/embed/${video.id}?rel=0&modestbranding=1`}
              className="absolute top-0 left-0 w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              title={video.title}
              loading="lazy"
            />
          </div>
          {/* 描述 */}
          {video.description && (
            <div className="p-4 bg-emerald-50">
              <p className="text-sm text-gray-700">{video.description}</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// =======================//
// 主元件
// =======================//
const YouTubeGallery: React.FC = () => {
  const { t, language } = useLanguage()
  const videoImporter = VideoImporter.getInstance()
  
  // 使用 state 儲存影片列表
  const [galleryVideos, setGalleryVideos] = useState(() => 
    videoImporter.getGalleryVideos()
  )

  // 訂閱 VideoImporter 更新事件
  useEffect(() => {
    const unsubscribe = videoImporter.subscribe(() => {
      setGalleryVideos(videoImporter.getGalleryVideos())
    })
    return unsubscribe
  }, [videoImporter])
  
  const videos: VideoData[] = useMemo(() => 
    galleryVideos.map(v => ({
      id: v.videoId,
      title: language === 'zh' ? v.title_zh : v.title_en,
      description: language === 'zh' ? v.description_zh : v.description_en
    })), [galleryVideos, language])

  const [selectedVideo, setSelectedVideo] = useState<string | null>(null)
  const [hoveredVideo, setHoveredVideo] = useState<string | null>(null)
  const [visibleVideos, setVisibleVideos] = useState<Set<string>>(new Set())
  const [loadedCount, setLoadedCount] = useState(0)
  const [expandedVideos, setExpandedVideos] = useState<Set<string>>(new Set())
  const [isMobile, setIsMobile] = useState(false)
  const observerRef = useRef<IntersectionObserver | null>(null)
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const videoRefs = useRef<Map<string, HTMLDivElement>>(new Map())

  // 檢測是否為手機
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  // 優化的懶加載設置
  useEffect(() => {
    const initialVideos = videos.map((v) => v.id)
    setVisibleVideos(new Set(initialVideos))

    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const videoId = entry.target.getAttribute("data-video-id")
          if (!videoId) return

          if (entry.isIntersecting) {
            setVisibleVideos((prev) => {
              if (prev.has(videoId)) return prev
              const newSet = new Set(prev)
              newSet.add(videoId)
              return newSet
            })
          }
        })
      },
      {
        rootMargin: "100px",
        threshold: 0.01,
      }
    )

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect()
      }
    }
  }, [videos.length])

  const registerVideoRef = useCallback((videoId: string, element: HTMLDivElement | null) => {
    if (element) {
      videoRefs.current.set(videoId, element)
      if (observerRef.current) {
        observerRef.current.observe(element)
      }
    }
  }, [])

  const handleMouseEnter = (videoId: string) => {
    if (isMobile) return
    hoverTimeoutRef.current = setTimeout(() => {
      setHoveredVideo(videoId)
    }, 1000)
  }

  const handleMouseLeave = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current)
    }
    setHoveredVideo(null)
  }

  const handleThumbnailLoad = useCallback(() => {
    setLoadedCount((prev) => prev + 1)
  }, [])

  const toggleVideoExpansion = useCallback((videoId: string) => {
    setExpandedVideos((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(videoId)) {
        newSet.delete(videoId)
      } else {
        newSet.add(videoId)
      }
      return newSet
    })
  }, [])

  const expandAll = useCallback(() => {
    setExpandedVideos(new Set(videos.map((v) => v.id)))
  }, [videos])

  const collapseAll = useCallback(() => {
    setExpandedVideos(new Set())
  }, [])

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape" && selectedVideo) {
        setSelectedVideo(null)
      }
    }
    window.addEventListener("keydown", handleEsc)
    return () => window.removeEventListener("keydown", handleEsc)
  }, [selectedVideo])

  useEffect(() => {
    if (selectedVideo) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }
    return () => {
      document.body.style.overflow = ""
    }
  }, [selectedVideo])

  return (
    <section id="youtube-gallery" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-on-scroll">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t("youtube.title")}
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {t("youtube.subtitle")}
          </p>
          {loadedCount < videos.length && (
            <div className="mt-4 text-sm text-gray-500">
              載入中... {loadedCount} / {videos.length}
            </div>
          )}
        </div>

        {/* 手機版：全部展開/收合按鈕 */}
        {isMobile && (
          <div className="flex gap-3 mb-6 justify-center">
            <button
              onClick={expandAll}
              className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 transition-colors duration-200 text-sm"
            >
              全部展開
            </button>
            <button
              onClick={collapseAll}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg font-semibold hover:bg-gray-700 transition-colors duration-200 text-sm"
            >
              全部收合
            </button>
          </div>
        )}

        {/* 影片網格 */}
        <div className={`grid ${isMobile ? 'grid-cols-1 gap-4' : 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6'}`}>
          {videos.map((video, index) => {
            const isVisible = visibleVideos.has(video.id)
            const isHovered = hoveredVideo === video.id
            const isExpanded = expandedVideos.has(video.id)

            // 手機版：使用可折疊卡片
            if (isMobile) {
              return (
                <div
                  key={video.id}
                  data-video-id={video.id}
                  ref={(el) => registerVideoRef(video.id, el)}
                  className="animate-on-scroll"
                  style={{
                    animationDelay: `${index * 0.05}s`,
                  }}
                >
                  <CollapsibleVideoCard
                    video={video}
                    isExpanded={isExpanded}
                    onToggle={() => toggleVideoExpansion(video.id)}
                    isVisible={isVisible}
                    onThumbnailLoad={handleThumbnailLoad}
                  />
                </div>
              )
            }

            // 桌面版：保持原樣
            return (
              <div
                key={video.id}
                data-video-id={video.id}
                ref={(el) => registerVideoRef(video.id, el)}
                className="group relative aspect-video rounded-xl overflow-hidden cursor-pointer shadow-lg hover:shadow-2xl transform transition-all duration-500 hover:scale-105 animate-on-scroll"
                style={{
                  animationDelay: `${index * 0.05}s`,
                }}
                onMouseEnter={() => handleMouseEnter(video.id)}
                onMouseLeave={handleMouseLeave}
                onClick={() => setSelectedVideo(video.id)}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-400 via-emerald-500 to-emerald-600 rounded-xl p-[2px] group-hover:p-[3px] transition-all duration-300">
                  <div className="absolute inset-0 bg-white rounded-xl"></div>
                </div>

                <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                  <div className="absolute inset-0 bg-emerald-500/20 blur-xl"></div>
                </div>

                <div className="relative h-full rounded-2xl overflow-hidden">
                  <OptimizedThumbnail
                    videoId={video.id}
                    title={video.title}
                    isVisible={isVisible}
                    onLoad={handleThumbnailLoad}
                  />

                  {isHovered && isVisible && (
                    <div className="absolute inset-0 bg-black z-10">
                      <iframe
                        src={`https://www.youtube.com/embed/${video.id}?autoplay=1&mute=1&controls=0&loop=1&playlist=${video.id}&modestbranding=1&rel=0`}
                        className="w-full h-full"
                        allow="autoplay; encrypted-media"
                        allowFullScreen
                        title={video.title}
                        loading="lazy"
                      />
                    </div>
                  )}

                  {!isHovered && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
                      <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center transform group-hover:scale-110 transition-transform duration-300">
                        <Play
                          className="w-8 h-8 text-emerald-600 ml-1"
                          fill="currentColor"
                        />
                      </div>
                    </div>
                  )}

                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-4 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300 pointer-events-none">
                    <h3 className="text-white font-semibold text-sm mb-1 line-clamp-1">
                      {video.title}
                    </h3>
                    <p className="text-gray-300 text-xs line-clamp-2">
                      {video.description}
                    </p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* 全屏播放模態框（桌面版） */}
      {selectedVideo && !isMobile && (
        <div
          className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setSelectedVideo(null)}
        >
          <button
            className="absolute top-4 right-4 text-white hover:text-emerald-400 transition-colors duration-200 z-10 w-10 h-10 flex items-center justify-center rounded-full bg-black/50 hover:bg-black/70"
            onClick={() => setSelectedVideo(null)}
            aria-label="關閉影片"
          >
            <X className="w-6 h-6" />
          </button>
          <div
            className="w-full max-w-5xl aspect-video rounded-xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <iframe
              src={`https://www.youtube.com/embed/${selectedVideo}?autoplay=1&rel=0&modestbranding=1`}
              className="w-full h-full"
              allow="autoplay; encrypted-media; fullscreen"
              allowFullScreen
              title="YouTube video player"
            />
          </div>
        </div>
      )}
    </section>
  )
}

export default YouTubeGallery