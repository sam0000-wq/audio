import React, { useState } from 'react';
import { Upload, Button, Radio, message, Card, Space } from 'antd';
import { UploadOutlined, InboxOutlined } from '@ant-design/icons';
import type { UploadFile, UploadProps } from 'antd';

const { Dragger } = Upload;

export const KnowledgeBaseUpload: React.FC = () => {
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [mode, setMode] = useState<'replace' | 'merge'>('replace');

  const handleUpload = async () => {
    if (fileList.length === 0) {
      message.error('請選擇檔案');
      return;
    }

    const formData = new FormData();
    formData.append('file', fileList[0] as any);
    formData.append('mode', mode);

    setUploading(true);

    try {
      const response = await fetch('http://localhost:3002/api/upload-knowledge', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      if (result.success) {
        message.success(result.message);
        setFileList([]);
        
        // 顯示統計資訊
        if (result.stats) {
          message.info(
            `中文: ${result.stats.zh} 筆 | 英文: ${result.stats.en} 筆 | 分類: ${result.stats.categories.join(', ')}`
          );
        }
      } else {
        message.error(result.message || '上傳失敗');
      }
    } catch (error) {
      console.error('上傳錯誤:', error);
      message.error('上傳失敗，請檢查後端伺服器是否運行');
    } finally {
      setUploading(false);
    }
  };

  const uploadProps: UploadProps = {
    onRemove: (file) => {
      const index = fileList.indexOf(file);
      const newFileList = fileList.slice();
      newFileList.splice(index, 1);
      setFileList(newFileList);
    },
    beforeUpload: (file) => {
      const isValidType = 
        file.type === 'text/csv' || 
        file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        file.type === 'application/vnd.ms-excel';
      
      if (!isValidType) {
        message.error('只支援 CSV 或 Excel 檔案');
        return false;
      }

      setFileList([file]);
      return false;
    },
    fileList,
    maxCount: 1,
  };

  return (
    <Card title="知識庫批次上傳" style={{ maxWidth: 800, margin: '20px auto' }}>
      <Space direction="vertical" style={{ width: '100%' }} size="large">
        <Radio.Group value={mode} onChange={(e) => setMode(e.target.value)}>
          <Radio value="replace">覆蓋模式（清空後重新匯入）</Radio>
          <Radio value="merge">合併模式（保留現有資料，新增不重複項目）</Radio>
        </Radio.Group>

        <Dragger {...uploadProps}>
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">點擊或拖曳檔案到此區域上傳</p>
          <p className="ant-upload-hint">
            支援 CSV 或 Excel 檔案，檔案大小限制 10MB
          </p>
        </Dragger>

        <Button
          type="primary"
          onClick={handleUpload}
          disabled={fileList.length === 0}
          loading={uploading}
          icon={<UploadOutlined />}
          block
        >
          {uploading ? '上傳中...' : '開始上傳'}
        </Button>

        <div style={{ fontSize: '12px', color: '#666' }}>
          <p><strong>檔案格式要求：</strong></p>
          <ul>
            <li>必須包含欄位：language, keywords, question, answer, category, priority, enabled</li>
            <li>language: zh 或 en</li>
            <li>keywords: 多個關鍵字用逗號分隔</li>
            <li>enabled: true 或 false</li>
          </ul>
        </div>
      </Space>
    </Card>
  );
};
