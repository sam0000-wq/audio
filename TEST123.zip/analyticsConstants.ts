import { supabase } from "../lib/supabase";

export interface VisitorLog {
  id: number;
  ip_address: string;
  country: string | null;
  city: string | null;
  visit_count: number;
  first_visit: string;
  last_visit: string;
  user_agent: string | null;
  created_at: string;
}

export interface ChartData {
  date: string;
  count: number;
  compareCount?: number;
}

export interface CountryData {
  country: string;
  count: number;
  visitors: number;
}

export interface ComparisonStats {
  currentTotal: number;
  previousTotal: number;
  changePercent: number;
  changeType: "increase" | "decrease" | "neutral";
}

export interface OperationLog {
  id: number;
  username: string;
  operation_type: string;
  operation_detail: string;
  ip_address: string;
  user_agent: string;
  created_at: string;
}

export interface OperationStats {
  total_operations: number;
  login_success: number;
  login_failed: number;
  login_blocked: number;
  today_operations: number;
  last_7_days: number;
}

export type TimeRange = "week" | "twoWeeks" | "month" | "year";
export type DashboardTab = "visitors" | "operations" | "knowledge" | "videos";  // ← 加了 "videos"

export const COUNTRY_NAME_MAP: { [key: string]: string } = {
  "United States of America": "United States",
  "USA": "United States",
  "US": "United States",
  "UK": "United Kingdom",
  "Great Britain": "United Kingdom",
  "Holland": "Netherlands",
  "UAE": "United Arab Emirates",
  "South Korea": "South Korea",
  "Korea, Republic of": "South Korea",
  "Korea, Democratic People's Republic of": "North Korea",
  "Viet Nam": "Vietnam",
  "Czech Republic": "Czech Republic",
  "Czechia": "Czech Republic",
  "Macedonia": "North Macedonia",
  "Burma": "Myanmar",
  "Ivory Coast": "Côte d'Ivoire",
  "Côte d'Ivoire": "Côte d'Ivoire",
  "Republic of the Congo": "Congo",
  "Democratic Republic of the Congo": "DR Congo",
  "DRC": "DR Congo",
  "Congo-Kinshasa": "DR Congo",
  "Congo-Brazzaville": "Congo",
  "Laos": "Lao PDR",
  "Lao People's Democratic Republic": "Lao PDR",
  "East Timor": "Timor-Leste",
  "Swaziland": "Eswatini",
  "The Gambia": "Gambia",
  "The Bahamas": "Bahamas",
  "Cape Verde": "Cabo Verde",
  "São Tomé and Príncipe": "Sao Tome and Principe",
  "Bosnia": "Bosnia and Herzegovina",
  "Herzegovina": "Bosnia and Herzegovina",
  "Trinidad": "Trinidad and Tobago",
  "Saint Kitts": "Saint Kitts and Nevis",
  "Saint Vincent": "Saint Vincent and the Grenadines",
  "Antigua": "Antigua and Barbuda",
  "Vatican": "Vatican City",
  "Holy See": "Vatican City",
  "Brunei Darussalam": "Brunei",
  "Micronesia": "Federated States of Micronesia",
  "FSM": "Federated States of Micronesia",
  "Marshall Islands": "Marshall Islands",
  "Palau": "Palau",
  "Solomon Islands": "Solomon Islands",
  "Kiribati": "Kiribati",
  "Tuvalu": "Tuvalu",
  "Nauru": "Nauru",
  "Vanuatu": "Vanuatu",
  "Fiji": "Fiji",
  "Samoa": "Samoa",
  "Tonga": "Tonga",
};

export const WORLD_MAP_PATHS: { [key: string]: string } = {
  "United States": "M100,150 L250,150 L250,250 L100,250 Z",
  "Canada": "M100,80 L280,80 L280,140 L100,140 Z",
  "Mexico": "M120,220 L180,220 L180,260 L120,260 Z",
  "Guatemala": "M175,255 L200,255 L200,270 L175,270 Z",
  "Belize": "M200,255 L210,255 L210,265 L200,265 Z",
  "El Salvador": "M190,260 L210,260 L210,270 L190,270 Z",
  "Honduras": "M185,255 L210,255 L210,265 L185,265 Z",
  "Nicaragua": "M195,265 L220,265 L220,280 L195,280 Z",
  "Costa Rica": "M200,265 L220,265 L220,275 L200,275 Z",
  "Panama": "M215,275 L240,275 L240,282 L215,282 Z",
  "Cuba": "M200,240 L250,240 L250,250 L200,250 Z",
  "Jamaica": "M220,250 L235,250 L235,258 L220,258 Z",
  "Haiti": "M235,245 L250,245 L250,255 L235,255 Z",
  "Dominican Republic": "M240,245 L260,245 L260,255 L240,255 Z",
  "Bahamas": "M250,230 L270,230 L270,245 L250,245 Z",
  "Trinidad and Tobago": "M270,265 L280,265 L280,272 L270,272 Z",
  "Barbados": "M275,268 L280,268 L280,273 L275,273 Z",
  "Saint Lucia": "M272,267 L276,267 L276,271 L272,271 Z",
  "Saint Vincent and the Grenadines": "M271,268 L275,268 L275,272 L271,272 Z",
  "Grenada": "M270,269 L274,269 L274,273 L270,273 Z",
  "Antigua and Barbuda": "M268,260 L273,260 L273,264 L268,264 Z",
  "Dominica": "M270,264 L274,264 L274,268 L270,268 Z",
  "Saint Kitts and Nevis": "M265,258 L270,258 L270,262 L265,262 Z",
  "Brazil": "M280,280 L360,280 L360,380 L280,380 Z",
  "Argentina": "M260,380 L310,380 L310,450 L260,450 Z",
  "Chile": "M240,350 L260,350 L260,450 L240,450 Z",
  "Colombia": "M240,260 L280,260 L280,290 L240,290 Z",
  "Peru": "M240,290 L280,290 L280,340 L240,340 Z",
  "Venezuela": "M250,260 L290,260 L290,285 L250,285 Z",
  "Ecuador": "M220,280 L250,280 L250,300 L220,300 Z",
  "Bolivia": "M260,310 L300,310 L300,350 L260,350 Z",
  "Paraguay": "M280,350 L315,350 L315,385 L280,385 Z",
  "Uruguay": "M295,385 L320,385 L320,410 L295,410 Z",
  "Guyana": "M280,270 L295,270 L295,285 L280,285 Z",
  "Suriname": "M295,270 L310,270 L310,285 L295,285 Z",
  "French Guiana": "M310,270 L325,270 L325,285 L310,285 Z",
  "United Kingdom": "M400,120 L440,120 L440,150 L400,150 Z",
  "Ireland": "M380,125 L400,125 L400,150 L380,150 Z",
  "France": "M420,140 L450,140 L450,170 L420,170 Z",
  "Germany": "M450,130 L480,130 L480,160 L450,160 Z",
  "Spain": "M410,170 L440,170 L440,190 L410,190 Z",
  "Portugal": "M390,170 L410,170 L410,195 L390,195 Z",
  "Italy": "M460,160 L480,160 L480,200 L460,200 Z",
  "Netherlands": "M440,125 L460,125 L460,140 L440,140 Z",
  "Belgium": "M440,140 L455,140 L455,150 L440,150 Z",
  "Switzerland": "M455,150 L470,150 L470,160 L455,160 Z",
  "Austria": "M470,145 L490,145 L490,155 L470,155 Z",
  "Poland": "M480,120 L510,120 L510,145 L480,145 Z",
  "Czech Republic": "M470,135 L485,135 L485,145 L470,145 Z",
  "Sweden": "M460,90 L480,90 L480,125 L460,125 Z",
  "Norway": "M440,80 L465,80 L465,120 L440,120 Z",
  "Finland": "M480,85 L510,85 L510,120 L480,120 Z",
  "Denmark": "M455,115 L470,115 L470,125 L455,125 Z",
  "Greece": "M490,165 L515,165 L515,185 L490,185 Z",
  "Turkey": "M515,155 L560,155 L560,180 L515,180 Z",
  "Romania": "M490,145 L520,145 L520,165 L490,165 Z",
  "Ukraine": "M510,125 L560,125 L560,155 L510,155 Z",
  "Hungary": "M480,145 L505,145 L505,155 L480,155 Z",
  "Belarus": "M490,115 L520,115 L520,130 L490,130 Z",
  "Bulgaria": "M485,155 L510,155 L510,165 L485,165 Z",
  "Serbia": "M475,150 L490,150 L490,160 L475,160 Z",
  "Croatia": "M465,145 L480,145 L480,155 L465,155 Z",
  "Bosnia and Herzegovina": "M470,150 L485,150 L485,160 L470,160 Z",
  "Slovenia": "M465,142 L478,142 L478,150 L465,150 Z",
  "Slovakia": "M475,135 L495,135 L495,145 L475,145 Z",
  "Albania": "M475,160 L490,160 L490,170 L475,170 Z",
  "North Macedonia": "M480,160 L495,160 L495,168 L480,168 Z",
  "Montenegro": "M472,155 L482,155 L482,162 L472,162 Z",
  "Kosovo": "M478,157 L487,157 L487,164 L478,164 Z",
  "Estonia": "M485,100 L505,100 L505,110 L485,110 Z",
  "Latvia": "M480,105 L500,105 L500,115 L480,115 Z",
  "Lithuania": "M475,110 L495,110 L495,120 L475,120 Z",
  "Moldova": "M505,140 L520,140 L520,150 L505,150 Z",
  "Iceland": "M380,75 L410,75 L410,90 L380,90 Z",
  "Luxembourg": "M445,137 L452,137 L452,143 L445,143 Z",
  "Monaco": "M447,165 L450,165 L450,167 L447,167 Z",
  "Liechtenstein": "M462,152 L465,152 L465,155 L462,155 Z",
  "Andorra": "M418,175 L422,175 L422,178 L418,178 Z",
  "San Marino": "M468,162 L471,162 L471,165 L468,165 Z",
  "Vatican City": "M469,168 L471,168 L471,170 L469,170 Z",
  "Malta": "M470,195 L475,195 L475,198 L470,198 Z",
  "Cyprus": "M515,170 L525,170 L525,175 L515,175 Z",
  "Russia": "M480,60 L750,60 L750,140 L480,140 Z",
  "China": "M650,150 L750,150 L750,240 L650,240 Z",
  "India": "M600,200 L650,200 L650,270 L600,270 Z",
  "Japan": "M770,180 L800,180 L800,240 L770,240 Z",
  "South Korea": "M740,195 L760,195 L760,215 L740,215 Z",
  "North Korea": "M740,185 L760,185 L760,195 L740,195 Z",
  "Taiwan": "M720,230 L730,230 L730,245 L720,245 Z",
  "Thailand": "M670,240 L690,240 L690,280 L670,280 Z",
  "Vietnam": "M690,230 L710,230 L710,280 L690,280 Z",
  "Malaysia": "M680,280 L710,280 L710,295 L680,295 Z",
  "Singapore": "M685,295 L690,295 L690,298 L685,298 Z",
  "Indonesia": "M680,295 L750,295 L750,320 L680,320 Z",
  "Philippines": "M720,250 L745,250 L745,285 L720,285 Z",
  "Pakistan": "M575,185 L605,185 L605,215 L575,215 Z",
  "Bangladesh": "M640,215 L655,215 L655,230 L640,230 Z",
  "Myanmar": "M655,215 L675,215 L675,260 L655,260 Z",
  "Iran": "M540,165 L580,165 L580,195 L540,195 Z",
  "Iraq": "M520,165 L545,165 L545,185 L520,185 Z",
  "Saudi Arabia": "M520,185 L560,185 L560,220 L520,220 Z",
  "Israel": "M505,175 L515,175 L515,185 L505,185 Z",
  "Palestine": "M506,177 L512,177 L512,183 L506,183 Z",
  "Jordan": "M515,180 L530,180 L530,190 L515,190 Z",
  "Lebanon": "M510,175 L520,175 L520,182 L510,182 Z",
  "Syria": "M515,165 L540,165 L540,180 L515,180 Z",
  "Yemen": "M540,210 L570,210 L570,230 L540,230 Z",
  "Oman": "M565,205 L585,205 L585,225 L565,225 Z",
  "United Arab Emirates": "M555,210 L575,210 L575,220 L555,220 Z",
  "Qatar": "M555,200 L565,200 L565,208 L555,208 Z",
  "Kuwait": "M540,190 L555,190 L555,200 L540,200 Z",
  "Bahrain": "M556,202 L560,202 L560,206 L556,206 Z",
  "Afghanistan": "M580,180 L610,180 L610,200 L580,200 Z",
  "Kazakhstan": "M540,120 L620,120 L620,160 L540,160 Z",
  "Uzbekistan": "M565,155 L600,155 L600,175 L565,175 Z",
  "Turkmenistan": "M560,165 L595,165 L595,185 L560,185 Z",
  "Kyrgyzstan": "M590,155 L615,155 L615,170 L590,170 Z",
  "Tajikistan": "M580,165 L605,165 L605,180 L580,180 Z",
  "Mongolia": "M650,130 L720,130 L720,160 L650,160 Z",
  "Nepal": "M630,200 L650,200 L650,210 L630,210 Z",
  "Bhutan": "M650,205 L665,205 L665,213 L650,213 Z",
  "Sri Lanka": "M625,265 L640,265 L640,285 L625,285 Z",
  "Maldives": "M615,275 L622,275 L622,283 L615,283 Z",
  "Cambodia": "M690,255 L710,255 L710,275 L690,275 Z",
  "Lao PDR": "M680,230 L700,230 L700,260 L680,260 Z",
  "Brunei": "M705,285 L715,285 L715,292 L705,292 Z",
  "Timor-Leste": "M740,308 L755,308 L755,315 L740,315 Z",
  "Armenia": "M535,160 L550,160 L550,170 L535,170 Z",
  "Azerbaijan": "M550,160 L570,160 L570,175 L550,175 Z",
  "Georgia": "M525,155 L545,155 L545,165 L525,165 Z",
  "Egypt": "M490,195 L520,195 L520,220 L490,220 Z",
  "South Africa": "M480,360 L530,360 L530,410 L480,410 Z",
  "Nigeria": "M430,250 L460,250 L460,275 L430,275 Z",
  "Kenya": "M510,270 L535,270 L535,295 L510,295 Z",
  "Ethiopia": "M515,245 L545,245 L545,275 L515,275 Z",
  "Morocco": "M395,190 L425,190 L425,210 L395,210 Z",
  "Algeria": "M420,195 L470,195 L470,230 L420,230 Z",
  "Libya": "M465,205 L505,205 L505,235 L465,235 Z",
  "Sudan": "M495,230 L530,230 L530,260 L495,260 Z",
  "South Sudan": "M500,260 L530,260 L530,280 L500,280 Z",
  "Tanzania": "M510,290 L540,290 L540,315 L510,315 Z",
  "Ghana": "M410,260 L430,260 L430,280 L410,280 Z",
  "Angola": "M460,310 L495,310 L495,350 L460,350 Z",
  "Mozambique": "M515,315 L545,315 L545,360 L515,360 Z",
  "Madagascar": "M545,320 L565,320 L565,360 L545,360 Z",
  "Cameroon": "M455,260 L480,260 L480,285 L455,285 Z",
  "Côte d'Ivoire": "M400,265 L420,265 L420,280 L400,280 Z",
  "Niger": "M435,225 L475,225 L475,250 L435,250 Z",
  "Burkina Faso": "M410,245 L435,245 L435,260 L410,260 Z",
  "Mali": "M405,220 L445,220 L445,250 L405,250 Z",
  "Malawi": "M515,305 L530,305 L530,325 L515,325 Z",
  "Zambia": "M495,315 L530,315 L530,345 L495,345 Z",
  "Zimbabwe": "M505,340 L535,340 L535,365 L505,365 Z",
  "Botswana": "M490,350 L520,350 L520,375 L490,375 Z",
  "Namibia": "M475,350 L510,350 L510,390 L475,390 Z",
  "Senegal": "M385,235 L405,235 L405,248 L385,248 Z",
  "Guinea": "M390,255 L410,255 L410,270 L390,270 Z",
  "Sierra Leone": "M385,260 L400,260 L400,272 L385,272 Z",
  "Liberia": "M390,270 L405,270 L405,282 L390,282 Z",
  "Tunisia": "M450,185 L470,185 L470,205 L450,205 Z",
  "Uganda": "M505,275 L525,275 L525,290 L505,290 Z",
  "Rwanda": "M505,285 L520,285 L520,295 L505,295 Z",
  "Burundi": "M508,292 L520,292 L520,302 L508,302 Z",
  "Somalia": "M530,255 L560,255 L560,285 L530,285 Z",
  "Djibouti": "M530,250 L542,250 L542,258 L530,258 Z",
  "Eritrea": "M520,240 L540,240 L540,253 L520,253 Z",
  "Chad": "M460,225 L495,225 L495,260 L460,260 Z",
  "Central African Republic": "M470,260 L505,260 L505,280 L470,280 Z",
  "Congo": "M465,280 L495,280 L495,310 L465,310 Z",
  "DR Congo": "M475,280 L520,280 L520,325 L475,325 Z",
  "Gabon": "M455,285 L475,285 L475,305 L455,305 Z",
  "Equatorial Guinea": "M450,280 L462,280 L462,288 L450,288 Z",
  "Benin": "M425,258 L438,258 L438,275 L425,275 Z",
  "Togo": "M420,260 L430,260 L430,275 L420,275 Z",
  "Mauritania": "M385,210 L420,210 L420,235 L385,235 Z",
  "Western Sahara": "M380,200 L410,200 L410,218 L380,218 Z",
  "Gambia": "M385,240 L400,240 L400,245 L385,245 Z",
  "Guinea-Bissau": "M385,248 L398,248 L398,258 L385,258 Z",
  "Lesotho": "M505,395 L518,395 L518,405 L505,405 Z",
  "Eswatini": "M520,375 L532,375 L532,385 L520,385 Z",
  "Mauritius": "M570,360 L578,360 L578,368 L570,368 Z",
  "Comoros": "M540,300 L548,300 L548,308 L540,308 Z",
  "Seychelles": "M560,270 L568,270 L568,278 L560,278 Z",
  "Sao Tome and Principe": "M448,288 L454,288 L454,294 L448,294 Z",
  "Cape Verde": "M365,235 L373,235 L373,243 L365,243 Z",
  "Australia": "M700,330 L800,330 L800,420 L700,420 Z",
  "New Zealand": "M820,380 L850,380 L850,430 L820,430 Z",
  "Papua New Guinea": "M760,295 L800,295 L800,315 L760,315 Z",
  "Fiji": "M855,330 L870,330 L870,342 L855,342 Z",
  "Solomon Islands": "M810,305 L830,305 L830,318 L810,318 Z",
  "Vanuatu": "M825,320 L838,320 L838,335 L825,335 Z",
  "New Caledonia": "M830,340 L845,340 L845,352 L830,352 Z",
  "Samoa": "M875,325 L888,325 L888,335 L875,335 Z",
  "Tonga": "M870,340 L880,340 L880,350 L870,350 Z",
  "Kiribati": "M880,310 L895,310 L895,320 L880,320 Z",
  "Micronesia": "M810,290 L830,290 L830,300 L810,300 Z",
  "Marshall Islands": "M835,295 L850,295 L850,305 L835,305 Z",
  "Palau": "M755,295 L765,295 L765,303 L755,303 Z",
  "Nauru": "M825,305 L832,305 L832,312 L825,312 Z",
  "Tuvalu": "M845,318 L852,318 L852,325 L845,325 Z",
};

export const MILESTONES = [100, 500, 1000, 5000, 10000];