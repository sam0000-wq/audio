import { ValidationResult, CSVRow, UploadConfig } from "../types/uploadTypes";

export const uploadConfig: UploadConfig = {
  allowedFormats: [".csv", ".xlsx", ".xls"],
  maxFileSize: 10, // 10MB
  requiredColumns: ["keywords", "question", "answer", "category", "priority", "enabled", "language"],
  supportedLanguages: ["zh", "en"]
};

export const validateFile = (file: File): ValidationResult => {
  const errors: string[] = [];
  const warnings: string[] = [];

  // 檢查文件類型
  const fileExtension = file.name.toLowerCase().split(".").pop();
  if (!uploadConfig.allowedFormats.some(format => format.includes(fileExtension || ""))) {
    errors.push(`不支援的檔案格式。支援格式:${uploadConfig.allowedFormats.join(", ")}`);
  }

  // 檢查文件大小
  const fileSizeMB = file.size / (1024 * 1024);
  if (fileSizeMB > uploadConfig.maxFileSize) {
    errors.push(`檔案大小超過限制 ${uploadConfig.maxFileSize}MB,目前大小:${fileSizeMB.toFixed(2)}MB`);
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
};

export const validateData = (data: CSVRow[]): ValidationResult => {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!data || data.length === 0) {
    errors.push("檔案內容為空");
    return { isValid: false, errors, warnings };
  }

  // 檢查必要欄位
  const firstRow = data[0];
  const missingColumns = uploadConfig.requiredColumns.filter(
    col => !(col in firstRow)
  );

  if (missingColumns.length > 0) {
    errors.push(`缺少必要欄位:${missingColumns.join(", ")}`);
  }

  // 驗證每一行數據
  data.forEach((row, index) => {
    const rowNumber = index + 1;

    // 檢查必填欄位
    uploadConfig.requiredColumns.forEach(col => {
      if (!row[col as keyof CSVRow] || row[col as keyof CSVRow].trim() === "") {
        errors.push(`第 ${rowNumber} 行:${col} 欄位不能為空`);
      }
    });

    // 檢查語言格式
    if (row.language && !uploadConfig.supportedLanguages.includes(row.language)) {
      errors.push(`第 ${rowNumber} 行:不支援的語言 "${row.language}",支援:${uploadConfig.supportedLanguages.join(", ")}`);
    }

    // 檢查優先級格式
    if (row.priority && isNaN(Number(row.priority))) {
      errors.push(`第 ${rowNumber} 行:優先級必須是數字`);
    }

    // 檢查啟用狀態格式
    if (row.enabled && !["true", "false", "1", "0"].includes(row.enabled.toLowerCase())) {
      warnings.push(`第 ${rowNumber} 行:啟用狀態建議使用 true/false 或 1/0`);
    }

    // 檢查關鍵字格式
    if (row.keywords && row.keywords.includes(",")) {
      // 關鍵字應該用逗號分隔,這是正確的
    } else if (row.keywords && !row.keywords.includes(",")) {
      warnings.push(`第 ${rowNumber} 行:關鍵字建議用逗號分隔多個詞彙`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    data
  };
};

export const sanitizeData = (data: CSVRow[]): any[] => {
  return data.map(row => ({
    keywords: row.keywords?.split(",").map(k => k.trim()).filter(k => k) || [],
    question: row.question?.trim() || "",
    answer: row.answer?.trim() || "",
    category: row.category?.trim() || "",
    priority: parseInt(row.priority) || 1,
    enabled: ["true", "1"].includes(row.enabled?.toLowerCase()) || false,
    language: (row.language?.toLowerCase() as "zh" | "en") || "zh"
  }));
}; 
