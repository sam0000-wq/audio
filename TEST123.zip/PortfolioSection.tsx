import React from "react"
import {ArrowRight} from 'lucide-react'
import { useLanguage } from "../contexts/LanguageContext"

const PortfolioSection: React.FC = () => {
  const { t } = useLanguage()

  const projects = [
    {
      title: t("portfolio.residential"),
      description: t("portfolio.residentialDesc"),
      category: t("portfolio.category.residential"),
      image: "https://i.ibb.co/4L5CZpD/2.webp",
      categoryColor: "bg-emerald-500"
    },
    {
      title: t("portfolio.commercial"),
      description: t("portfolio.commercialDesc"),
      category: t("portfolio.category.commercial"),
      image: "https://i.ibb.co/cKbbDJ5t/3.webp",
      categoryColor: "bg-emerald-600"
    },
    {
      title: t("portfolio.public"),
      description: t("portfolio.publicDesc"),
      category: t("portfolio.category.public"),
      image: "https://i.ibb.co/h1MHh1w3/1.webp",
      categoryColor: "bg-emerald-700"
    },
    {
      title: t("portfolio.rooftop"),
      description: t("portfolio.rooftopDesc"),
      category: t("portfolio.category.specialty"),
      image: "https://i.ibb.co/5xX5Dxtq/4.webp",
      categoryColor: "bg-emerald-800"
    }
  ]

  return (
    <section id="portfolio" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-on-scroll">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t("portfolio.title")}
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {t("portfolio.subtitle")}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="relative group rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 animate-on-scroll min-h-[280px] md:min-h-[400px]"
              style={{ 
                animationDelay: `${index * 0.1}s`,
              }}
            >
              {/* 背景圖片 */}
              <div className="absolute inset-0">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                {/* 漸層遮罩 */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
              </div>

              {/* 內容區域 */}
              <div className="relative z-10 h-full flex flex-col justify-between p-6 md:p-8">
                {/* 頂部標籤 */}
                <div className="flex justify-start">
                  <span className={`${project.categoryColor} text-white px-3 py-1 md:px-4 md:py-2 rounded-full text-xs md:text-sm font-semibold shadow-lg`}>
                    {project.category}
                  </span>
                </div>

                {/* 底部內容 */}
                <div className="space-y-3 md:space-y-4">
                  <h3 className="text-xl md:text-2xl font-bold text-white leading-tight">
                    {project.title}
                  </h3>
                  <p className="text-gray-200 leading-relaxed text-sm md:text-base">
                    {project.description}
                  </p>
                  
                  {/* 查看項目按鈕 */}
                  <a 
                    href="#contact"
                    className="inline-flex items-center gap-2 text-white bg-white/20 backdrop-blur-sm hover:bg-white/30 px-4 py-2 md:px-6 md:py-3 rounded-lg font-semibold transition-all duration-300 group-hover:translate-x-2 text-sm md:text-base"
                  >
                    {t("portfolio.viewProject")}
                    <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </a>
                </div>
              </div>

              {/* Hover效果 */}
              <div className="absolute inset-0 bg-emerald-600/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default PortfolioSection