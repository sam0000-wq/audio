import React, { useState, useEffect } from "react";
import * as ExcelJS from "exceljs";
import AdminLogin from "./AdminLogin";
import { AnalyticsCharts } from "./AnalyticsCharts";
import { OperationsTab } from "./AnalyticsTabContent";
import VideoManager from "./VideoManager";
import KnowledgeBaseManager from "./KnowledgeBaseManager";
import { DashboardTab, TimeRange, VisitorLog } from "../constants/analyticsConstants";
import { useAnalyticsData } from "../hooks/useAnalyticsData";

import { supabase } from "../lib/supabase";

const VisitorAnalytics: React.FC = () => {
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [activeTab, setActiveTab] = useState<DashboardTab>("visitors");

  const {
    visitors,
    chartData,
    countryData,
    timeRange,
    setTimeRange,
    loading,
    totalVisits,
    uniqueVisitors,
    comparisonStats,
    reachedMilestone,
    showCookieConsent,
    handleCookieConsent,
    fetchVisitorData,
    operationLogs,
    operationStats,
    logFilter,
    setLogFilter,
    logsLoading,
    fetchOperationLogs,
    fetchOperationStats,
    hoveredCountry,
    setHoveredCountry,
  } = useAnalyticsData();

  useEffect(() => {
    const checkAdminSession = () => {
      const sessionToken = sessionStorage.getItem("admin_session_token");
      const sessionExpiry = sessionStorage.getItem("admin_session_expiry");
      
      if (sessionToken && sessionExpiry) {
        const expiryTime = parseInt(sessionExpiry, 10);
        if (Date.now() < expiryTime) {
          setIsAuthenticated(true);
          return;
        }
      }
      
      sessionStorage.removeItem("admin_session_token");
      sessionStorage.removeItem("admin_session_expiry");
      setIsAuthenticated(false);
    };

    checkAdminSession();
  }, []);

  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
    setShowLogin(false);
  };

  const handleLogout = () => {
    sessionStorage.removeItem("admin_session_token");
    sessionStorage.removeItem("admin_session_expiry");
    setIsAuthenticated(false);
    setShowAnalytics(false);
  };

  const exportToXLSX = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("訪客數據");

    worksheet.columns = [
      { header: "IP地址", key: "ip_address", width: 20 },
      { header: "國家", key: "country", width: 15 },
      { header: "城市", key: "city", width: 15 },
      { header: "訪問次數", key: "visit_count", width: 12 },
      { header: "首次訪問", key: "first_visit", width: 20 },
      { header: "最後訪問", key: "last_visit", width: 20 },
    ];

    visitors.forEach((v: VisitorLog) => {
      worksheet.addRow({
        ip_address: v.ip_address,
        country: v.country || "Unknown",
        city: v.city || "Unknown",
        visit_count: v.visit_count,
        first_visit: new Date(v.first_visit).toLocaleString("zh-TW"),
        last_visit: new Date(v.last_visit).toLocaleString("zh-TW"),
      });
    });

    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FF10B981" },
    };

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `visitor_analytics_${timeRange}_${
      new Date().toISOString().split("T")[0]
    }.xlsx`;
    link.click();
    window.URL.revokeObjectURL(url);
  };

  useEffect(() => {
    if (showAnalytics && isAuthenticated) {
      fetchVisitorData();
      const interval = setInterval(fetchVisitorData, 30000);
      return () => clearInterval(interval);
    }
  }, [showAnalytics, isAuthenticated, fetchVisitorData]);

  useEffect(() => {
    if (showAnalytics && isAuthenticated && activeTab === "operations") {
      fetchOperationLogs();
      fetchOperationStats();
    }
  }, [showAnalytics, isAuthenticated, activeTab, logFilter, fetchOperationLogs, fetchOperationStats]);

  const handleOpenAnalytics = () => {
    if (isAuthenticated) {
      setShowAnalytics(true);
    } else {
      setShowLogin(true);
    }
  };

  return (
    <>
      {showCookieConsent && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-end justify-center p-4">
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white rounded-2xl shadow-2xl max-w-2xl w-full p-8 border border-emerald-500/30 animate-slide-up">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-emerald-500/20 rounded-full flex items-center justify-center">
                <svg className="w-6 h-6 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">🍪 我們使用Cookie (We Use Cookies)</h3>
                <p className="text-gray-300 mb-4 leading-relaxed">
                  為了確保網站正常運作並提升您的體驗，我們使用功能性 Cookie。我們也希望使用分析性 (Analytics) 
				  和行銷性 (Marketing) Cookie 來了解您如何使用我們的網站，
				  以便我們優化相關內容。您可隨時拒絕或前往設定管理您的偏好。
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => handleCookieConsent(true)}
                    className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
                  >
                    ✓ 接受所有 (Accept All)
                  </button>
                  <button
                    onClick={() => handleCookieConsent(false)}
                    className="flex-1 bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300"
                  >
                    ✗ 拒絕非必要 (Decline All)
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-3">
                  您可以隨時在瀏覽器中清除 Cookie 來重置此設定
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {showLogin && (
        <AdminLogin 
          onSuccess={handleLoginSuccess} 
          onClose={() => setShowLogin(false)} 
        />
      )}

      <div className="fixed top-2 right-1 z-50">
        {!showAnalytics ? (
          <button
            onClick={handleOpenAnalytics}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 flex items-center gap-2"
          >
            {isAuthenticated ? "管理儀錶板" : "🔒 管理儀錶板"}
          </button>
        ) : (
          <div className="bg-gray-900 text-white rounded-2xl shadow-2xl w-[900px] max-h-[80vh] overflow-y-auto">
            <div className="sticky top-0 bg-gradient-to-r from-emerald-500 to-teal-600 p-6 rounded-t-2xl z-10">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">管理儀表板</h2>
                <div className="flex items-center gap-3">
                  <button
                    onClick={handleLogout}
                    className="text-white hover:bg-white/20 rounded-full px-4 py-2 transition-colors text-sm flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                    </svg>
                    登出
                  </button>
                  <button
                    onClick={() => setShowAnalytics(false)}
                    className="text-white hover:bg-white/20 rounded-full p-2 transition-colors"
                  >
                    <svg
                      className="w-6 h-6"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </div>
              </div>
              
              <div className="flex gap-2 flex-wrap">
                <button
                  onClick={() => setActiveTab("visitors")}
                  className={`px-6 py-2 rounded-lg font-semibold transition-all ${
                    activeTab === "visitors"
                      ? "bg-white text-emerald-600"
                      : "bg-white/20 text-white hover:bg-white/30"
                  }`}
                >
                  📊 訪客分析
                </button>
                <button
                  onClick={() => setActiveTab("operations")}
                  className={`px-6 py-2 rounded-lg font-semibold transition-all ${
                    activeTab === "operations"
                      ? "bg-white text-emerald-600"
                      : "bg-white/20 text-white hover:bg-white/30"
                  }`}
                >
                  📋 操作日誌
                </button>
                <button
                  onClick={() => setActiveTab("knowledgeBase")}
                  className={`px-6 py-2 rounded-lg font-semibold transition-all ${
                    activeTab === "knowledgeBase"
                      ? "bg-white text-emerald-600"
                      : "bg-white/20 text-white hover:bg-white/30"
                  }`}
                >
                  💾 知識庫管理
                </button>
                <button
                  onClick={() => setActiveTab("videos")}
                  className={`px-6 py-2 rounded-lg font-semibold transition-all ${
                    activeTab === "videos"
                      ? "bg-white text-emerald-600"
                      : "bg-white/20 text-white hover:bg-white/30"
                  }`}
                >
                  🎬 影片管理
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {activeTab === "visitors" ? (
                <AnalyticsCharts
                  visitors={visitors}
                  chartData={chartData}
                  countryData={countryData}
                  timeRange={timeRange}
                  setTimeRange={setTimeRange}
                  loading={loading}
                  totalVisits={totalVisits}
                  uniqueVisitors={uniqueVisitors}
                  comparisonStats={comparisonStats}
                  reachedMilestone={reachedMilestone}
                  exportToXLSX={exportToXLSX}
                  hoveredCountry={hoveredCountry}
                  setHoveredCountry={setHoveredCountry}
                />
              ) : activeTab === "operations" ? (
                <OperationsTab
                  operationStats={operationStats}
                  operationLogs={operationLogs}
                  logsLoading={logsLoading}
                  logFilter={logFilter}
                  setLogFilter={setLogFilter}
                />
              ) : activeTab === "knowledgeBase" ? (
                <KnowledgeBaseManager />
              ) : activeTab === "videos" ? (
                <VideoManager />
              ) : null}
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes slide-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        .animate-slide-up {
          animation: slide-up 0.4s ease-out;
        }
      `}</style>
    </>
  );
};

export default VisitorAnalytics;
