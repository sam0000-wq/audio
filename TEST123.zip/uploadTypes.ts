export interface CSVRow {
  keywords: string;
  question: string;
  answer: string;
  category: string;
  priority: string;
  enabled: string;
  language: string;
}

// 新增：影片 CSV 行定義
export interface VideoCSVRow {
  videoId: string;
  title_zh: string;
  title_en: string;
  description_zh: string;
  description_en: string;
  category: string;
  enabled: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  data?: any[];
}

export interface UploadProgress {
  status: 'idle' | 'uploading' | 'processing' | 'validating' | 'success' | 'error';
  progress: number;
  message: string;
}

export interface UploadConfig {
  allowedFormats: string[];
  maxFileSize: number;
  requiredColumns: string[];
  supportedLanguages: string[];
}

export interface ProcessedKnowledgeItem {
  keywords: string[];
  question: string;
  answer: string;
  category: string;
  priority: number;
  enabled: boolean;
  language: 'zh' | 'en';
}

// 新增：處理後的影片項目
export interface ProcessedVideoItem {
  videoId: string;
  title_zh: string;
  title_en: string;
  description_zh: string;
  description_en: string;
  category: 'hero' | 'gallery';
  enabled: boolean;
}