import React, { useEffect, useRef, useState } from "react"
import { useLanguage } from "../contexts/LanguageContext"
import VideoImporter from "../services/videoImporter"

// =========================================================
// 優化圖片元件(內部實現 - 簡化版)
// =========================================================
const OptimizedImage: React.FC<{
  src: string
  alt: string
  className?: string
  style?: React.CSSProperties
}> = ({ src, alt, className = "", style = {} }) => {
  const [isLoaded, setIsLoaded] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)

  useEffect(() => {
    const img = imgRef.current
    if (!img) return

    if (img.complete) {
      setIsLoaded(true)
    }
  }, [])

  return (
    <div
      className={className}
      style={{
        ...style,
        position: "relative",
        overflow: "hidden",
      }}
    >
      <img
        ref={imgRef}
        src={src}
        alt={alt}
        onLoad={() => setIsLoaded(true)}
        style={{
          width: "100%",
          height: "100%",
          objectFit: "cover",
          opacity: isLoaded ? 1 : 0,
          transition: "opacity 0.5s ease-in-out",
        }}
      />
      {!isLoaded && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%)",
            backgroundSize: "200% 100%",
            animation: "shimmer 1.5s infinite",
          }}
        />
      )}
    </div>
  )
}

// =========================================================
// 樣式定義
// =========================================================
const styles = {
  card: {
    width: "25%",
    height: "100%",
    perspective: 1000,
    cursor: "default",
    userSelect: "none" as const,
    position: "relative" as const,
  },
  cardInner: (flipped: boolean) => ({
    position: "relative" as const,
    width: "100%",
    height: "100%",
    transition: "transform 0.3s ease-in-out",
    transformStyle: "preserve-3d" as const,
    transform: flipped ? "rotateY(180deg)" : "none",
  }),
  cardFace: {
    position: "absolute" as const,
    width: "100%",
    height: "100%",
    borderRadius: "30px",
    backfaceVisibility: "hidden" as const,
    top: 0,
    left: 0,
    boxShadow: "0 4px 12px rgba(0,0,0,0.25)",
  },
  cardFront: {
    background: "linear-gradient(145deg, #d9d9d9, #a6a6a6)",
    border: "1.5px solid #b0b0b0",
    boxShadow:
      "inset 0 2px 5px rgba(255,255,255,0.8), inset 0 -2px 8px rgba(0,0,0,0.3), 0 8px 15px rgba(0,0,0,0.25)",
    zIndex: 2,
  },
  cardBack: {
    transform: "rotateY(180deg)",
    border: "2px solid #b0b0b0",
    backgroundColor: "#eee",
    boxShadow: "0 4px 12px rgba(0,0,0,0.3), inset 0 0 0 2px rgba(255,255,255,0.3)",
    borderRadius: "30px",
    zIndex: 1,
    overflow: "hidden",
  },
}

// =========================================================
// 圖片 URL 定義(優化:集中管理)
// =========================================================
const IMAGES = [
  "https://i.ibb.co/Ldkc2p6N/1.webp",
  "https://i.ibb.co/YBDT6g47/2.webp",
  "https://i.ibb.co/XxwjJy3R/3.webp",
  "https://i.ibb.co/vvYDHmxP/4.webp",
  "https://i.ibb.co/Jwzg3JYF/5.webp",
  "https://i.ibb.co/HTP2jxTp/6.webp",
  "https://i.ibb.co/jqbsBfT/7.webp",
  "https://i.ibb.co/xKHhVRjQ/8.webp",
]

// =========================================================
// 幫助函式
// =========================================================
function getRandomIndices(total: number, count: number): number[] {
  const indices = Array.from({ length: total }, (_, i) => i)
  const result: number[] = []
  for (let i = 0; i < count; i++) {
    const randIdx = Math.floor(Math.random() * indices.length)
    result.push(indices[randIdx])
    indices.splice(randIdx, 1)
  }
  return result
}

// =========================================================
// FlipCard 元件(優化版)
// =========================================================
const FlipCard: React.FC<{ imageUrl: string; flipped: boolean }> = ({
  imageUrl,
  flipped,
}) => (
  <div style={styles.card}>
    <div style={styles.cardInner(flipped)}>
      <div style={{ ...styles.cardFace, ...styles.cardFront }}>
        <div
          style={{
            position: "absolute",
            top: 18,
            left: "50%",
            transform: "translateX(-50%)",
            width: 150,
            height: 8,
            background: "#e0e0e0",
            borderRadius: 20,
            boxShadow: "0 2px 6px rgba(0,0,0,0.15)",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: 18,
            left: "50%",
            transform: "translateX(-50%)",
            width: 90,
            height: 8,
            background: "#e0e0e0",
            borderRadius: 20,
            boxShadow: "0 2px 5px rgba(0,0,0,0.12)",
          }}
        />
      </div>
      <div
        style={{
          ...styles.cardFace,
          ...styles.cardBack,
        }}
      >
        <img
          src={imageUrl}
          alt="卡片背面"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            borderRadius: "28px",
          }}
        />
      </div>
    </div>
  </div>
)

// =========================================================
// VideoPlayerTabs 元件
// =========================================================
declare global {
  interface Window {
    YT: any
    onYouTubeIframeAPIReady: (() => void) | null
  }
}

const VideoPlayerTabs: React.FC = () => {
  const { language } = useLanguage()
  const videoImporter = VideoImporter.getInstance()
  const heroVideos = videoImporter.getHeroVideos()
  const videos = heroVideos.map(v => ({
    id: v.videoId,
    title: language === 'zh' ? v.title_zh : v.title_en
  }))

  const playerRef = useRef<any>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [selected, setSelected] = useState(0)
  const [ready, setReady] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  // 檢測是否為手機
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => window.removeEventListener("resize", checkMobile)
  }, [])

  useEffect(() => {
    const initPlayer = () => {
      if (containerRef.current && window.YT?.Player) {
        window.YT.ready(() => {
          playerRef.current = new window.YT.Player(containerRef.current, {
            height: isMobile ? "180" : "238",
            width: isMobile ? "320" : "424",
            videoId: videos[selected].id,
            playerVars: { autoplay: 0, mute: 1, controls: 1, modestbranding: 1, rel: 0 },
            events: { onReady: () => setReady(true) },
          })
        })
      }
    }

    if (!window.YT || !window.YT.Player) {
      const script = document.createElement("script")
      script.src = "https://www.youtube.com/iframe_api"
      script.async = true
      script.onload = initPlayer
      document.body.appendChild(script)
    } else {
      initPlayer()
    }

    return () => {
      if (playerRef.current?.destroy) playerRef.current.destroy()
      playerRef.current = null
    }
  }, [isMobile])

  useEffect(() => {
    if (ready && playerRef.current) {
      playerRef.current.loadVideoById(videos[selected].id)
      playerRef.current.mute()
    }
  }, [selected, ready])

  const currentTitle = videos[selected].title

  return (
    <div className="flex flex-col items-center bg-black/10 backdrop-blur rounded-xl p-3 shadow-xl max-w-lg mx-auto">
      <h3 className="text-base md:text-xl font-semibold mb-2 text-white text-center px-2">{currentTitle}</h3>
      <div className="mb-2 text-white text-xs md:text-sm font-medium">Sound On for the full experience.</div>
      
      {/* 固定尺寸容器 */}
      <div 
        className="relative flex justify-center items-center bg-black rounded-lg overflow-hidden"
        style={{ 
          width: isMobile ? "320px" : "424px",
          height: isMobile ? "180px" : "238px"
        }}
      >
        <div ref={containerRef} className="w-full h-full" />
      </div>

      <div className="flex flex-wrap justify-center gap-x-2 md:gap-x-3 gap-y-2 mt-3">
        {videos.map((v, i) => (
          <button
            key={i}
            className={`w-7 h-7 md:w-5 md:h-5 rounded-full border-2 flex items-center justify-center transition ${
              i === selected ? "border-white bg-white" : "border-gray-400 bg-gray-600/70"
            }`}
            style={{
              outline: i === selected ? "2px solid #22c55e" : "none",
              outlineOffset: i === selected ? "2px" : "0",
            }}
            onClick={() => setSelected(i)}
            aria-label={v.title}
          >
            {i === selected ? <span className="w-2 h-2 md:w-3 md:h-3 rounded-full bg-green-500 block" /> : null}
          </button>
        ))}
      </div>
    </div>
  )
}

// =========================================================
// 添加 shimmer 動畫樣式
// =========================================================
if (typeof document !== "undefined") {
  const style = document.createElement("style")
  style.textContent = `
    @keyframes shimmer {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }
  `
  document.head.appendChild(style)
}

// =========================================================
// HeroSection 元件(優化版)
// =========================================================
const HeroSection: React.FC = () => {
  const { t } = useLanguage()
  const [isMobile, setIsMobile] = useState(false)
  const [indices, setIndices] = useState<number[]>([])
  const [flipped, setFlipped] = useState([false, false, false, false])

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768)
    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    if (isMobile) {
      setIndices([0, 1, 2, 3])
      setFlipped([false, false, false, false])
      return
    }

    let currentIndex = -1
    let timeoutId: NodeJS.Timeout | null = null
    let intervalId: NodeJS.Timeout | null = null

    let currentRound = getRandomIndices(IMAGES.length, 4)
    setIndices(currentRound)

    const flipNext = () => {
      currentIndex++
      if (currentIndex < currentRound.length) {
        setFlipped((prev) => {
          const next = [...prev]
          next[currentIndex] = true
          return next
        })
      } else if (currentIndex === currentRound.length) {
        timeoutId = setTimeout(() => {
          setFlipped([false, false, false, false])
          currentRound = getRandomIndices(IMAGES.length, 4)
          setIndices(currentRound)
          currentIndex = -1
        }, 2000)
      }
    }

    intervalId = setInterval(() => {
      if (currentIndex === currentRound.length) return
      flipNext()
    }, 2000)

    flipNext()
    return () => {
      if (intervalId) clearInterval(intervalId)
      if (timeoutId) clearTimeout(timeoutId)
    }
  }, [isMobile])

  return (
    <section className="relative min-h-screen overflow-hidden">
      <div className="absolute inset-0 w-full h-full">
        {isMobile ? (
          <div className="w-full h-full relative">
            <OptimizedImage
              src={IMAGES[0]}
              alt="背景圖"
              className="w-full h-full"
            />
            <div className="absolute inset-0 bg-black/40" />
          </div>
        ) : (
          <div className="flex w-full h-full">
            {indices.map((img, i) => (
              <FlipCard
                key={img}
                imageUrl={IMAGES[img]}
                flipped={flipped[i]}
              />
            ))}
            <div className="absolute inset-0 bg-black/40" />
          </div>
        )}
      </div>

      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-[40%] z-10 text-center text-white px-4 sm:px-6 lg:px-8 max-w-4xl w-full">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 drop-shadow-lg">{t("hero.title")}</h1>
        <p className="text-xl md:text-2xl mb-6 text-gray-200 font-light">{t("hero.subtitle")}</p>
        <p className="text-sm md:text-base mb-6 text-gray-300 leading-relaxed">
          {t("hero.description")}
        </p>
        <div className="flex justify-center">
          <VideoPlayerTabs />
        </div>
      </div>
    </section>
  )
}

export default HeroSection