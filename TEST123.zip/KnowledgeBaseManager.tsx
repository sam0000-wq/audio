import React, { useState, useCallback, useRef } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle, Download, RefreshCw, X, FileDown } from 'lucide-react';
import { validateFile } from '../utils/fileValidator';
import { UploadProgress, ValidationResult } from '../types/uploadTypes';
import toast from 'react-hot-toast';

const KnowledgeBaseManager: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({
    status: 'idle',
    progress: 0,
    message: ''
  });
  const [validation, setValidation] = useState<ValidationResult | null>(null);
  const [mode, setMode] = useState<'replace' | 'merge'>('replace');

  // 重置上傳狀態
  const resetUpload = useCallback(() => {
    setSelectedFile(null);
    setValidation(null);
    setUploadProgress({ status: 'idle', progress: 0, message: '' });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, []);

  // 處理拖拽
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, []);

  // 處理檔案選擇
  const handleFileSelect = async (file: File) => {
    console.log('=== 檔案選擇 ===');
    console.log('檔案名稱:', file.name);
    console.log('檔案大小:', file.size);
    console.log('檔案類型:', file.type);
    
    // 重置之前的狀態
    setUploadProgress({ status: 'idle', progress: 0, message: '' });
    setSelectedFile(file);
    
    // 立即驗證檔案
    const fileValidation = validateFile(file);
    setValidation(fileValidation);
    
    console.log('驗證結果:', fileValidation);

    if (fileValidation.isValid) {
      toast.success('檔案選擇成功');
    } else {
      toast.error(fileValidation.errors.join('\n'));
    }
  };

  // 執行上傳
  const handleUpload = async () => {
    if (!selectedFile || !validation?.isValid) return;

    // 確認對話框
    const confirmMessage = mode === 'replace' 
      ? '確認替換整個知識庫嗎？此操作無法復原。'
      : '確認合併到現有知識庫嗎？';
    
    if (!window.confirm(confirmMessage)) {
      return;
    }

    try {
      setUploadProgress({ status: 'uploading', progress: 20, message: '上傳中...' });
      
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('mode', mode);

      const response = await fetch('http://localhost:3002/api/upload-knowledge', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      setUploadProgress({ status: 'processing', progress: 60, message: '處理中...' });
      await new Promise(resolve => setTimeout(resolve, 500));

      setUploadProgress({ status: 'validating', progress: 90, message: '驗證中...' });
      await new Promise(resolve => setTimeout(resolve, 300));

      if (result.success) {
        setUploadProgress({ status: 'success', progress: 100, message: '導入成功!' });
        toast.success(result.message);
        
        // 顯示統計資訊
        if (result.stats) {
          toast.success(
            `中文: ${result.stats.zh} 筆 | 英文: ${result.stats.en} 筆 | 分類: ${result.stats.categories.join(', ')}`
          );
        }
        
        // 成功後自動重置
        setTimeout(() => {
          resetUpload();
        }, 1500);
      } else {
        throw new Error(result.message);
      }
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '未知錯誤';
      setUploadProgress({ status: 'error', progress: 0, message: `導入失敗: ${errorMessage}` });
      toast.error(`導入失敗: ${errorMessage}`);
      
      // 3秒後自動重置為可重試狀態
      setTimeout(() => {
        setUploadProgress({ status: 'idle', progress: 0, message: '' });
      }, 3000);
    }
  };

  // 執行導出
  const handleExport = async () => {
    try {
      const response = await fetch('http://localhost:3002/api/export-knowledge');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `knowledge-base-${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      toast.success('知識庫導出成功!');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '未知錯誤';
      toast.error(`導出失敗: ${errorMessage}`);
    }
  };

  // 執行範本下載
  const handleTemplateDownload = async () => {
    try {
      const response = await fetch('http://localhost:3002/api/download-template');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'knowledge-base-template.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      toast.success('範本下載成功!');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '未知錯誤';
      toast.error(`範本下載失敗: ${errorMessage}`);
    }
  };

  // 判斷是否正在上傳中
  const isUploading = ['uploading', 'processing', 'validating'].includes(uploadProgress.status);

  return (
    <div className="space-y-6">
      {/* 模式選擇 */}
      <div className="flex gap-4 p-4 bg-gray-50 rounded-lg">
        <label className="flex items-center space-x-2 cursor-pointer">
          <input
            type="radio"
            name="mode"
            value="replace"
            checked={mode === 'replace'}
            onChange={(e) => setMode(e.target.value as 'replace' | 'merge')}
            className="w-4 h-4 text-red-600"
          />
          <span className="text-sm font-medium text-gray-700">覆蓋模式（清空後重新匯入）</span>
        </label>
        <label className="flex items-center space-x-2 cursor-pointer">
          <input
            type="radio"
            name="mode"
            value="merge"
            checked={mode === 'merge'}
            onChange={(e) => setMode(e.target.value as 'replace' | 'merge')}
            className="w-4 h-4 text-blue-600"
          />
          <span className="text-sm font-medium text-gray-700">合併模式（保留現有資料）</span>
        </label>
      </div>

      {/* 工具欄 */}
      <div className="flex flex-wrap gap-4">
        <button
          onClick={handleTemplateDownload}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>下載範本</span>
        </button>
        
        <button
          onClick={handleExport}
          className="flex items-center space-x-2 px-4 py-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-colors"
        >
          <FileDown className="w-4 h-4" />
          <span>導出知識庫</span>
        </button>

        {/* 重置按鈕 - 當有選擇檔案時顯示 */}
        {selectedFile && (
          <button
            onClick={resetUpload}
            disabled={isUploading}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed ml-auto"
          >
            <X className="w-4 h-4" />
            <span>重新選擇檔案</span>
          </button>
        )}
      </div>

      {/* 上傳區域 */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
          isDragOver
            ? 'border-blue-400 bg-blue-50'
            : selectedFile
            ? 'border-blue-300 bg-blue-50'
            : 'border-gray-300 hover:border-blue-300'
        }`}
      >
        <div className="flex flex-col items-center space-y-4">
          <div className={`p-4 rounded-full ${selectedFile ? 'bg-blue-100' : 'bg-gray-100'}`}>
            {selectedFile ? (
              <CheckCircle className="w-8 h-8 text-blue-600" />
            ) : (
              <Upload className="w-8 h-8 text-gray-400" />
            )}
          </div>
          
          <div>
            {selectedFile ? (
              <div className="space-y-2">
                <p className="text-sm text-gray-500">已選擇:</p>
                <p className="text-lg font-medium text-gray-700">
                  {selectedFile.name}
                </p>
                <p className="text-xs text-gray-400">
                  {(selectedFile.size / 1024).toFixed(2)} KB
                </p>
              </div>
            ) : (
              <>
                <p className="text-lg font-medium text-gray-200 mb-2">拖放檔案到此處，或點擊選擇檔案</p>
                <p className="text-sm text-gray-300 mt-1">支援格式: CSV, Excel (.xlsx, .xls)</p>
                <p className="text-xs text-gray-500">最大檔案大小: 10MB</p>
              </>
            )}
          </div>

          {!selectedFile && (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              選擇檔案
            </button>
          )}
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx,.xls,.csv"
        onChange={(e) => {
          console.log('檔案輸入變更事件觸發');
          console.log('檔案列表:', e.target.files);
          if (e.target.files?.[0]) {
            handleFileSelect(e.target.files[0]);
          }
        }}
        className="hidden"
      />

      {/* 檔案資訊顯示 - 只要選擇檔案就顯示 */}
      {selectedFile && (
        <div className="rounded-lg p-4 bg-blue-50 border border-blue-200">
          <div className="flex items-start space-x-3">
            <FileText className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-blue-800 mb-2">檔案路徑</h3>
              <p className="text-sm text-blue-700 break-all font-mono bg-blue-100 p-2 rounded">
                {selectedFile.name}
              </p>
              <div className="mt-2 flex gap-4 text-xs text-blue-600">
                <span>大小: {(selectedFile.size / 1024).toFixed(2)} KB</span>
                <span>類型: {selectedFile.type || '未知'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 驗證結果 */}
      {validation && (
        <div className={`rounded-lg p-4 ${
          validation.isValid ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
        }`}>
          <div className="flex items-center space-x-2 mb-2">
            {validation.isValid ? (
              <CheckCircle className="w-5 h-5 text-green-600" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600" />
            )}
            <h3 className={`font-medium ${validation.isValid ? 'text-green-800' : 'text-red-800'}`}>
              {validation.isValid ? '驗證通過' : '驗證失敗'}
            </h3>
          </div>

          {validation.errors.length > 0 && (
            <div className="mt-2">
              <p className="text-sm font-medium text-red-700 mb-1">錯誤:</p>
              <ul className="text-sm text-red-600 space-y-1">
                {validation.errors.map((error, index) => (
                  <li key={index}>• {error}</li>
                ))}
              </ul>
            </div>
          )}

          {validation.warnings.length > 0 && (
            <div className="mt-2">
              <p className="text-sm font-medium text-yellow-700 mb-1">警告:</p>
              <ul className="text-sm text-yellow-600 space-y-1">
                {validation.warnings.map((warning, index) => (
                  <li key={index}>• {warning}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* 錯誤訊息顯示 */}
      {uploadProgress.status === 'error' && (
        <div className="rounded-lg p-4 bg-red-50 border border-red-200">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-red-600" />
            <p className="text-sm text-red-700">{uploadProgress.message}</p>
          </div>
        </div>
      )}

      {/* 按鈕區域 - 只要有選擇檔案就顯示 */}
      {selectedFile && (
        <div className="flex gap-4">
          <button
            onClick={resetUpload}
            disabled={isUploading}
            className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium text-lg"
          >
            <X className="w-5 h-5" />
            <span>取消</span>
          </button>

          <button
            onClick={handleUpload}
            disabled={!validation?.isValid || isUploading || uploadProgress.status === 'success'}
            className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium text-lg"
          >
            {isUploading ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>{uploadProgress.message}</span>
              </>
            ) : uploadProgress.status === 'success' ? (
              <>
                <CheckCircle className="w-5 h-5" />
                <span>導入成功!</span>
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                <span>確認導入</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* 上傳進度 */}
      {(isUploading || uploadProgress.status === 'success') && (
        <div>
          <div className="bg-gray-200 rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${
                uploadProgress.status === 'success' ? 'bg-green-600' : 'bg-blue-600'
              }`}
              style={{ width: `${uploadProgress.progress}%` }}
            />
          </div>
          <p className="text-sm text-gray-600 mt-2 text-center">{uploadProgress.message}</p>
        </div>
      )}
    </div>
  );
};

export default KnowledgeBaseManager;
