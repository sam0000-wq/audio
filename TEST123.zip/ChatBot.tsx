import React, { useState, useEffect, useRef } from 'react';
import {MessageCircleDashed as MessageCircle, X, Send, RotateCcw} from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';
import { searchKnowledge, getRandomResponse } from '../../services/knowledgeBase';
import ChatMessage from './ChatMessage';
import ChatInput from './ChatInput';
import ChatAvatar from './ChatAvatar';
import CategorySelector from './CategorySelector';
import NoResultsMessage from './NoResultsMessage';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  isTyping?: boolean;
}

const ChatBot: React.FC = () => {
  const { language } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const isPlayingRef = useRef(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        type: 'bot',
        content: language === 'zh' 
          ? '您好!我是景觀設計助手,很高興為您服務!\n\n我可以幫您解答關於:\n• 植栽養護\n• 景觀設計\n• 施工作業\n• 付款條件\n• 社區承作\n• 菁英高階服務\n\n請告訴我您想了解什麼?'
          : 'Hello! I\'m your landscape design assistant, happy to help!\n\nI can answer questions about:\n• Plant Care\n• Landscape Design\n• Construction\n• Payment Terms\n• Community Projects\n• Premium Services\n\nWhat would you like to know?',
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen, language]);

  const handleMouseEnter = () => {
    if (isPlayingRef.current) return;
    
    // 根據語系選擇不同的音頻檔案
    const audioUrl = language === 'zh' 
      ? 'https://raw.githubusercontent.com/jojoyo37198/audio/refs/heads/main/DRGrant_CH.mp3'
      : 'https://raw.githubusercontent.com/jojoyo37198/audio/refs/heads/main/DRGrant.mp3'; 
    
    const audio = new Audio(audioUrl);
    audioRef.current = audio;
    isPlayingRef.current = true;
    
    audio.play().catch(err => console.log('Audio play failed:', err));
    
    audio.onended = () => {
      isPlayingRef.current = false;
      audioRef.current = null;
    };
  };

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;

    // 添加用戶消息
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: content.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    // 模擬思考時間
    await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 700));

    // 搜索知識庫
    const knowledge = searchKnowledge(content, language);
    const response = knowledge ? knowledge.answer : getRandomResponse(language);

    // 添加機器人回應
    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      type: 'bot',
      content: response,
      timestamp: new Date()
    };

    setIsTyping(false);
    setMessages(prev => [...prev, botMessage]);
  };

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
  };

  const handleQuestionSelect = (question: string) => {
    handleSendMessage(question);
  };

  const handleReset = () => {
    setMessages([]);
    setSelectedCategory(null);
    setIsTyping(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        onMouseEnter={handleMouseEnter}
        className="fixed bottom-6 right-6 transform hover:scale-105 transition-all duration-200 z-40 group"
      >
        <img 
          src="https://i.ibb.co/wZfhQSBs/OK.webp"
          alt="Landscape Assistant"
          className="w-[200px] h-[200px] object-contain"
        />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-gray-800 text-white px-3 py-1 rounded-lg text-sm opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
          {language === 'zh' ? '我是Dr. Grant，專業景觀顧問' : 'Landscape Consultation'}
        </div>
      </button>
    );
  }

  return (
    <>
      <div className="fixed bottom-6 right-6 w-96 h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col z-40 border border-gray-200">
        {/* 標題欄 */}
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white p-4 rounded-t-2xl flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <ChatAvatar />
            <div>
              <h3 className="font-semibold text-sm">
                {language === 'zh' ? '景觀設計助手' : 'Landscape Assistant'}
              </h3>
              <p className="text-xs text-green-100">
                {language === 'zh' ? '線上為您服務' : 'Online to help you'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {/* 重置按鈕 */}
            <button
              onClick={handleReset}
              className="p-2 rounded-full hover:bg-white hover:bg-opacity-20 transition-colors"
              title={language === 'zh' ? '重新開始' : 'Reset Chat'}
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* 關閉按鈕 */}
            <button
              onClick={() => setIsOpen(false)}
              className="p-2 rounded-full hover:bg-white hover:bg-opacity-20 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 常見問題選擇器 */}
        <CategorySelector
          selectedCategory={selectedCategory}
          onCategorySelect={handleCategorySelect}
          onQuestionSelect={handleQuestionSelect}
        />

        {/* 消息區域 */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))}
          
          {isTyping && (
            <div className="flex items-start space-x-3">
              <ChatAvatar size="sm" />
              <div className="bg-white rounded-2xl rounded-tl-md p-3 shadow-sm border max-w-[80%]">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}

          {messages.length === 1 && messages[0].type === 'bot' && (
            <NoResultsMessage />
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* 輸入區域 */}
        <div className="border-t border-gray-200 p-4">
          <ChatInput onSendMessage={handleSendMessage} disabled={isTyping} />
        </div>
      </div>
    </>
  );
};

export default ChatBot;
