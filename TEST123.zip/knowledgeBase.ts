// 知識庫類型定義
export interface KnowledgeItem {
  keywords: string[];
  question: string;
  answer: string;
  category: string;
  priority: number;
  enabled: boolean;
}

// 知識庫數據
export const knowledgeBase: Record<'zh' | 'en', KnowledgeItem[]> = {
  zh: [
    {
      keywords: ['[[[[澆水', '頻率', '多肉', '多久'],
      question: '多肉植物多久澆一次水？',
      answer: '多肉澆水指南：\n\n多肉植物建議7-10天澆水一次，冬季可延長至2週。澆水要澆透，但避免積水。\n\n小撇步：觀察土壤乾燥程度，確保排水良好。',
      category: '植栽養護',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[澆水', '時間', '夏天', '每天', '中午'],
      question: '夏天植物需要每天澆水嗎？',
      answer: '夏季澆水指南：\n\n大部分植物需要早晚澆水，避免中午高溫時段，可能造成根部燙傷。\n\n重要提醒：中午澆水會傷害植物根系，選擇清晨或傍晚時段。',
      category: '植栽養護',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[施肥', '頻率', '盆栽', '多久'],
      question: '盆栽植物多久施肥一次？',
      answer: '盆栽施肥時程：\n\n• 春夏季：每月一次\n• 秋冬季：每2-3個月一次\n• 注意：避免過量造成肥傷\n\n適當施肥有助植物健康成長。',
      category: '植栽養護',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[修剪', '時機', '樹木', '什麼時候'],
      question: '樹木什麼時候修剪最好？',
      answer: '修剪最佳時機：\n\n落葉樹在冬季休眠期修剪，常綠樹在春季新芽萌發前。避免梅雨季修剪。\n\n正確修剪促進健康生長。',
      category: '植栽養護',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[病蟲害', '防治', '預防', '處理'],
      question: '如何預防植物病蟲害？',
      answer: '病蟲害防治：\n\n定期檢查葉片、保持通風、適度澆水，發現問題及早處理。\n\n早期發現早期治療最有效。',
      category: '植栽養護',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[土壤', '改良', '排水', '透氣'],
      question: '如何改良土壤排水？',
      answer: '土壤改良方法：\n\n添加珍珠岩、蛭石或粗砂改善排水，混合腐葉土增加透氣性。\n\n良好排水是植物健康的基礎。',
      category: '植栽養護',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[換盆', '時機', '盆栽', '什麼時候'],
      question: '盆栽什麼時候需要換盆？',
      answer: '換盆時機判斷：\n\n當根系從排水孔長出或土壤板結時需要換盆，通常1-2年一次。\n\n適時換盆讓植物持續健康成長。',
      category: '植栽養護',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[陽光', '需求', '室內', '光照'],
      question: '室內植物需要多少陽光？',
      answer: '室內植物光照需求：\n\n大部分室內植物需要明亮散射光，避免直射強光。可放置在窗邊或使用植物燈補光。\n\n適當光照是植物生長的關鍵。',
      category: '植栽養護',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[色彩', '搭配', '花園', '植物'],
      question: '花園植物色彩該如何搭配？',
      answer: '色彩搭配原則：\n\n運用三色原則：主色調吸引目光，輔助色平衡視覺，點綴色增加層次變化。\n\n創造和諧又有變化的視覺效果。',
      category: '景觀設計',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[空間', '規劃', '小庭院', '設計'],
      question: '小庭院如何規劃空間？',
      answer: '小空間設計技巧：\n\n採用垂直綠化、多層次種植，運用鏡面或淺色系放大視覺空間。\n\n巧妙設計讓小空間也能很精彩。',
      category: '景觀設計',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[風格', '選擇', '庭院', '設計風格'],
      question: '庭院設計有哪些風格？',
      answer: '常見庭院風格：\n\n• 現代簡約：線條俐落，色彩單純\n• 自然野趣：模擬自然生態\n• 日式禪風：注重意境與平衡\n• 歐式古典：對稱布局，精緻雕飾\n\n選擇符合生活型態的風格。',
      category: '景觀設計',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[水景', '設計', '庭院', '噴泉'],
      question: '庭院水景如何設計？',
      answer: '水景設計要點：\n\n考慮水循環系統、防水處理、周邊植栽搭配，營造自然生態感。\n\n流水聲能創造放鬆氛圍。',
      category: '景觀設計',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[照明', '夜景', '庭院', '燈光'],
      question: '庭院夜間照明如何規劃？',
      answer: '夜景照明設計：\n\n結合功能照明與情境照明，重點照射植栽與景觀特色，避免光害。\n\n營造溫馨浪漫的夜間氛圍。',
      category: '景觀設計',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[步道', '設計', '庭院', '動線'],
      question: '庭院步道如何設計？',
      answer: '步道設計原則：\n\n考慮動線流暢性、材質防滑性、寬度適宜性，搭配兩側植栽引導視線。\n\n好的步道設計引導探索樂趣。',
      category: '景觀設計',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[圍籬', '隱私', '庭院', '遮蔽'],
      question: '如何設計庭院隱私空間？',
      answer: '隱私空間營造：\n\n運用植栽圍籬、格柵屏風或高低層次種植，既保有隱私又不失美觀。\n\n自然圍籬比硬體圍牆更有生命力。',
      category: '景觀設計',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[施工', '時間', '工期', '多久'],
      question: '庭院施工需要多長時間？',
      answer: '施工工期評估：\n\n小型庭院1-2週，大型景觀約3-4週，需視天氣與複雜度調整。\n\n實際工期依現場狀況而定。',
      category: '施工作業',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[準備', '施工前', '注意事項', '準備工作'],
      question: '施工前需要準備什麼？',
      answer: '施工前準備事項：\n\n• 確認設計圖面\n• 清理施工區域\n• 確保水電管線位置\n• 準備臨時停車空間\n\n充分準備讓施工更順利。',
      category: '施工作業',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[天氣', '影響', '施工', '下雨'],
      question: '天氣會影響施工進度嗎？',
      answer: '天氣對施工的影響：\n\n雨天會暫停戶外作業，強風影響高空作業，我們會依天氣調整工序。\n\n安全第一，品質為重。',
      category: '施工作業',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[材料', '選擇', '品質', '建材'],
      question: '如何選擇合適的施工材料？',
      answer: '材料選擇原則：\n\n考慮耐候性、維護便利性、美觀性與預算平衡，選用品質認證材料。\n\n好材料是品質保證的基礎。',
      category: '施工作業',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[安全', '施工', '注意', '防護'],
      question: '施工現場如何確保安全？',
      answer: '施工安全措施：\n\n設置安全圍籬、配戴防護設備、定期安全檢查，確保工作人員與住戶安全。\n\n安全是我們的首要考量。',
      category: '施工作業',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[驗收', '完工', '檢查', '標準'],
      question: '完工後如何進行驗收？',
      answer: '驗收檢查項目：\n\n• 植栽存活狀況\n• 排水系統功能\n• 硬體設施完整性\n• 清潔整理完成度\n\n詳細驗收確保品質。',
      category: '施工作業',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[付款', '方式', '施工', '分期'],
      question: '施工付款如何安排？',
      answer: '付款方式說明：\n\n一般採三階段付款：簽約30%、施工中40%、完工30%。\n\n依工程進度付款較有保障。',
      category: '付款條件',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[報價', '費用', '估價', '多少錢'],
      question: '庭院設計費用如何計算？',
      answer: '費用計算方式：\n\n依設計複雜度、施工面積、材料等級綜合評估，提供透明化報價單。\n\n詳細報價讓您清楚每項費用。',
      category: '付款條件',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[保固', '期間', '維修', '保養'],
      question: '完工後有保固期嗎？',
      answer: '保固服務說明：\n\n植栽提供3個月保固，硬體設施1年保固，保固期內免費維修更換。\n\n完善保固讓您安心。',
      category: '付款條件',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[合約', '內容', '簽約', '注意'],
      question: '簽約時需要注意什麼？',
      answer: '合約注意事項：\n\n• 確認設計圖面與規格\n• 了解付款時程\n• 明確工期與保固條件\n• 保留變更設計彈性\n\n詳閱合約保障雙方權益。',
      category: '付款條件',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[服務', '範圍', '社區', '景觀', '維護'],
      question: '社區景觀維護包含哪些服務？',
      answer: '維護服務內容：\n\n包含修剪、除草、施肥、病蟲害防治及植栽補植等。\n\n全方位維護保持美觀。',
      category: '社區承作',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[合約', '社區', '長期', '維護'],
      question: '社區維護合約如何簽訂？',
      answer: '維護合約說明：\n\n可簽訂年度或多年期合約，依社區需求客製化服務內容與頻率。\n\n長期合作關係更穩定。',
      category: '社區承作',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[團隊', '專業', '證照', '經驗'],
      question: '維護團隊具備什麼專業？',
      answer: '專業團隊介紹：\n\n團隊具備園藝技術士證照，豐富社區維護經驗，定期教育訓練。\n\n專業認證品質保證。',
      category: '社區承作',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[緊急', '處理', '颱風', '災害'],
      question: '遇到緊急狀況如何處理？',
      answer: '緊急應變機制：\n\n24小時緊急聯絡專線，颱風後立即巡檢，優先處理安全隱患。\n\n快速應變確保安全。',
      category: '社區承作',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[規劃', '社區', '景觀', '整體'],
      question: '社區整體景觀如何規劃？',
      answer: '社區景觀規劃：\n\n考慮整體風格統一、分區功能明確、維護便利性，創造宜居環境。\n\n整體規劃提升居住品質。',
      category: '社區承作',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[風格', '諮詢', '別墅', '花園', '適合'],
      question: '別墅花園適合什麼風格？',
      answer: '別墅風格選擇：\n\n可選擇現代簡約、地中海、英式花園或日式禪風，依生活型態設計。\n\n打造專屬夢想花園。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[客製化', '設計', '個人', '需求'],
      question: '可以完全客製化設計嗎？',
      answer: '客製化設計服務：\n\n當然可以！我們提供一對一設計諮詢，依您的喜好與需求量身打造。\n\n獨一無二的專屬設計。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[智慧', '澆水', '自動', '系統'],
      question: '有智慧澆水系統嗎？',
      answer: '智慧澆水系統：\n\n提供自動澆水系統，可依天氣、土壤濕度自動調節，手機APP遠端控制。\n\n科技讓園藝更輕鬆。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[進口', '植栽', '特殊', '品種'],
      question: '可以種植進口特殊品種嗎？',
      answer: '進口植栽服務：\n\n可協助引進適合台灣氣候的進口品種，提供專業馴化與養護建議。\n\n引進世界級珍稀植栽。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[戶外家具', '庭園家具', '挑選', '家具'],
      question: '庭園家具如何挑選？',
      answer: '戶外家具選擇：\n\n選防水、防UV材質如鋁合金或藤編家具，兼顧美觀與耐用。\n\n耐候材質經久耐用。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[泳池景觀', '搭配', '泳池', '綠化'],
      question: '如何搭配泳池與綠化？',
      answer: '泳池景觀設計：\n\n採用棕櫚、芒果樹等熱帶植物搭配石材步道，營造度假氛圍。\n\n熱帶風情度假感受。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[地形設計', '坡地別墅', '造景', '坡地'],
      question: '坡地別墅如何造景？',
      answer: '坡地造景技巧：\n\n以階梯式花壇與天然石擋土牆分層設計，強化景觀深度。\n\n善用地形創造層次。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[環境永續', '高端景觀', 'ESG', '結合'],
      question: '高端景觀可結合ESG嗎？',
      answer: '永續景觀設計：\n\n可使用節能照明與雨水回收系統，符合永續理念。\n\n環保與美觀兼具。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[景觀維護', '完工後', '定期維護', '提供'],
      question: '完工後是否提供定期維護？',
      answer: '維護服務承諾：\n\n是，可提供月或季維護方案，確保綠化長期穩定。\n\n專業維護長期保障。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[視覺焦點', '庭院', '主視覺', '設計'],
      question: '庭院主視覺該如何設計？',
      answer: '視覺焦點設計：\n\n以雕塑、水景或孤植大樹作為焦點，加強空間層次。\n\n打造令人印象深刻的焦點。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[材料保養', '高階建材', '維護', '保養'],
      question: '高階建材要如何維護？',
      answer: '建材保養方法：\n\n定期清潔與防水塗層更新，延長耐候材料壽命。\n\n細心保養延長使用壽命。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[聲音設計', '靜謐氛圍', '打造', '氛圍'],
      question: '如何打造靜謐氛圍？',
      answer: '靜謐空間營造：\n\n利用流水聲或自然風鈴聲遮蔽外界噪音，營造放鬆空間。\n\n自然音律舒緩心靈。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[景觀整合', '花園', '建築外觀', '協調'],
      question: '花園與建築外觀如何協調？',
      answer: '建築景觀協調：\n\n採用相同色系與材質延續，使景觀與建築和諧統一。\n\n整體設計和諧統一。',
      category: '菁英高階',
      priority: 1,
      enabled: true
    }
  ],
  en: [
    {
      keywords: ['[[[[watering', 'frequency', 'succulent', 'how often'],
      question: 'How often should I water succulents?',
      answer: 'Succulent Watering Guide:\n\nSucculents should be watered every 7-10 days, extending to 2 weeks in winter. Water thoroughly but avoid waterlogging.\n\nTip: Check soil dryness and ensure good drainage.',
      category: 'Plant Care',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[watering', 'time', 'summer', 'daily', 'noon'],
      question: 'Do plants need daily watering in summer?',
      answer: 'Summer Watering Guidelines:\n\nMost plants need watering morning and evening, avoid noon high temperature periods that may cause root burn.\n\nImportant: Noon watering can damage plant roots, choose early morning or evening.',
      category: 'Plant Care',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[fertilizer', 'frequency', 'potted', 'how often'],
      question: 'How often should I fertilize potted plants?',
      answer: 'Potted Plant Fertilizing Schedule:\n\n• Spring/Summer: Once a month\n• Fall/Winter: Every 2-3 months\n• Note: Avoid excess to prevent fertilizer burn\n\nProper fertilizing promotes healthy plant growth.',
      category: 'Plant Care',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[color', 'matching', 'garden', 'plants'],
      question: 'How should garden plant colors be matched?',
      answer: 'Color Matching Principles:\n\nUse three main color rule: main color for attraction, secondary color for balance, accent color for layered variation.\n\nCreate harmonious yet varied visual effects.',
      category: 'Landscape Design',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[construction', 'duration', 'how long', 'time'],
      question: 'How long does garden construction take?',
      answer: 'Construction Duration Estimate:\n\nSmall gardens 1-2 weeks, large landscaping about 3-4 weeks, adjusted for weather and complexity.\n\nActual duration depends on site conditions.',
      category: 'Construction',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[payment', 'method', 'construction', 'installment'],
      question: 'How is construction payment structured?',
      answer: 'Payment Structure:\n\nGeneral three-stage payment: 30% at signing, 40% mid-construction, 30% at completion.\n\nProgress-based payment provides security.',
      category: 'Payment Terms',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[service', 'scope', 'community', 'landscape', 'maintenance'],
      question: 'What does community landscape maintenance include?',
      answer: 'Maintenance Service Content:\n\nIncludes pruning, weeding, fertilizing, pest control and plant replacement.\n\nComprehensive maintenance keeps beauty.',
      category: 'Community Projects',
      priority: 1,
      enabled: true
    },
    {
      keywords: ['[[[[style', 'consultation', 'villa', 'garden', 'suitable'],
      question: 'What styles suit villa gardens?',
      answer: 'Villa Style Options:\n\nChoose from modern minimalist, Mediterranean, English garden or Japanese zen, designed according to lifestyle.\n\nCreate your exclusive dream garden.',
      category: 'Premium Services',
      priority: 1,
      enabled: true
    }
  ]
};

// 搜索知識庫
export const searchKnowledge = (query: string, language: 'zh' | 'en' = 'zh'): KnowledgeItem | null => {
  const items = knowledgeBase[language] || knowledgeBase.zh;
  const lowerQuery = query.toLowerCase();
  
  // 尋找最佳匹配
  for (const item of items) {
    // 跳過未啟用的項目
    if (item.enabled === false) continue;
    
    for (const keyword of item.keywords) {
      if (lowerQuery.includes(keyword.toLowerCase())) {
        return item;
      }
    }
  }
  
  return null;
};

// 獲取隨機回應(當沒有找到匹配時)
export const getRandomResponse = (language: 'zh' | 'en' = 'zh'): string => {
  const responses = language === 'zh' ? [
    '很抱歉，我在知識庫中沒有找到相關的資訊。\n\n不過別擔心！您可以：\n• 直接聯繫我們的專業園藝顧問\n• 重新描述您的問題，我會再次為您查找\n• 查看我們的常見問題頁面\n\n我們的專家團隊隨時準備為您提供專業建議！',
    '抱歉我暫時無法回答這個問題。\n\n建議您可以：\n• 嘗試用不同的關鍵字重新提問\n• 撥打我們的服務專線\n• 透過聯絡表單詳細描述您的需求\n\n我們會盡快為您提供專業的園藝建議！',
    '這個問題超出了我目前的知識範圍。\n\n為了給您最專業的回答：\n• 建議預約免費諮詢服務\n• 加入我們的官方LINE獲得即時協助\n• 瀏覽我們的作品集找尋靈感\n\n讓專業團隊為您打造夢想花園！'
  ] : [
    'I apologize, but I couldn\'t find relevant information in my knowledge base.\n\nDon\'t worry! You can:\n• Contact our professional gardening consultants directly\n• Rephrase your question and I\'ll search again\n• Check our FAQ page\n\nOur expert team is always ready to provide professional advice!',
    'Sorry, I can\'t answer this question at the moment.\n\nI suggest you:\n• Try different keywords to rephrase your question\n• Call our service hotline\n• Use our contact form to describe your needs in detail\n\nWe\'ll provide professional gardening advice as soon as possible!',
    'This question is beyond my current knowledge scope.\n\nFor the most professional answer:\n• Book a free consultation service\n• Join our official LINE for instant assistance\n• Browse our portfolio for inspiration\n\nLet our professional team create your dream garden!'
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
};

// 獲取所有分類
export const getCategories = (language: 'zh' | 'en' = 'zh'): string[] => {
  const items = knowledgeBase[language] || knowledgeBase.zh;
  const categories = [...new Set(items.map(item => item.category))];
  return categories;
};

// 根據分類獲取問題
export const getQuestionsByCategory = (category: string, language: 'zh' | 'en' = 'zh'): KnowledgeItem[] => {
  const items = knowledgeBase[language] || knowledgeBase.zh;
  return items.filter(item => item.category === category && item.enabled !== false);
};
