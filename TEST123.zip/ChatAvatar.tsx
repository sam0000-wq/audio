import React from 'react';

interface ChatAvatarProps {
  size?: 'small' | 'normal' | 'large';
  animate?: boolean;
}

const ChatAvatar: React.FC<ChatAvatarProps> = ({ 
  size = 'normal', 
  animate = true 
}) => {
  const getSizeClasses = () => {
    switch (size) {
      case 'small':
        return 'w-8 h-8 text-xs';
      case 'large':
        return 'w-14 h-14 text-lg';
      default:
        return 'w-10 h-10 text-sm';
    }
  };
  
  return (
    <div className={`${getSizeClasses()} bg-gradient-to-br from-green-100 via-emerald-50 to-green-200 rounded-full border-2 border-green-400 flex items-center justify-center shadow-lg relative overflow-hidden flex-shrink-0`}>
      {/* 虛擬園藝客服人像 */}
      <div className={`relative z-10 ${animate ? 'animate-pulse' : ''} flex items-center justify-center`}>
        {/* 主要人像 - 園藝師女性形象 */}
        <div className="relative">
          {/* 臉部 */}
          <div className="w-6 h-6 bg-gradient-to-b from-amber-100 to-amber-200 rounded-full border border-amber-300 flex items-center justify-center relative">
            {/* 眼睛 */}
            <div className="flex space-x-1 mb-1">
              <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
              <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
            </div>
            {/* 微笑 */}
            <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-1 border-b border-gray-600 rounded-full"></div>
          </div>
          
          {/* 頭髮 - 園藝師帽子 */}
          <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-7 h-3 bg-gradient-to-r from-green-600 to-green-500 rounded-t-full border border-green-700">
            {/* 身體 - 園藝圍裙 */}
            <div className="absolute top-5 left-1/2 transform -translate-x-1/2 w-4 h-2 bg-gradient-to-b from-green-300 to-green-400 rounded-b border border-green-500"></div>
          </div>
        </div>
      </div>
      
      {/* 背景動畫層 */}
      {animate && (
        <>
          <div className="absolute inset-0 bg-gradient-to-t from-green-300/30 to-transparent rounded-full animate-ping opacity-75"></div>
          <div className="absolute inset-0 bg-gradient-radial from-green-200/40 to-transparent rounded-full animate-pulse"></div>
        </>
      )}
      
      {/* 光暈效果 */}
      <div className="absolute -inset-1 bg-gradient-to-r from-green-400/20 to-emerald-400/20 rounded-full blur-sm animate-pulse"></div>
      
      {/* 專業園藝師光環效果 */}
      {animate && size !== 'small' && (
        <div className="absolute -top-1 -right-1 w-3 h-3">
          <div className="w-full h-full bg-yellow-300 rounded-full animate-bounce opacity-60 flex items-center justify-center text-xs">
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatAvatar;
 
