import React, { createContext, useContext, useState, ReactNode } from 'react'

type Language = 'zh' | 'en'

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
  getAudioUrl: () => string
}

// 音频文件 URL 配置
const audioUrls = {
  zh: "https://raw.githubusercontent.com/jojoyo37198/audio/refs/heads/main/Public_TW.mp3",
  en: "https://raw.githubusercontent.com/jojoyo37198/audio/refs/heads/main/Public_EN.mp3"
}

const translations = {
  zh: {
    // 導航欄 - 保持原始內容
    'nav.home': '首頁',
    'nav.about': '關於我們',
    'nav.services': '服務項目',
    'nav.portfolio': '作品集',
    'nav.testimonials': '客戶見證',
    'nav.contact': '免費諮詢',
    'nav.watchVideo': '觀看影片',
    'nav.videos': '影片展示',
    
    // 英雄區塊 - 園藝主題
    'hero.title': '專業園藝景觀設計',
    'hero.subtitle': '打造您的綠色夢想空間',
    'hero.description': '一站式園藝服務:設計、施工、植栽維護。專注創造美麗舒適的戶外環境。',
    'hero.getStarted': '立即開始',
    'hero.learnMore': '了解更多',
    
    // 服務項目 - 園藝相關
    'services.title': '我們的服務(桃園新屋/新竹地區)',
    'services.subtitle': '專業全方位園藝景觀解決方案',
    'services.gardenDesign': '花園設計',
    'services.gardenDesignDesc': '量身打造專屬花園設計,融合美學與實用性',
    'services.landscaping': '景觀工程',
    'services.landscapingDesc': '專業景觀施工團隊,確保工程品質與安全',
    'services.maintenance': '植栽維護',
    'services.maintenanceDesc': '定期養護服務,讓您的花園四季常綠',
    'services.irrigation': '灌溉系統',
    'services.irrigationDesc': '智能灌溉系統設計,節水環保又便利',
    
    // 關於我們 - 園藝專業
    'about.title': '關於悅境園藝',
    'about.subtitle': '專業團隊,用心服務',
    'about.description': '我們是一支充滿熱忱的專業園藝團隊,致力於為客戶創造美麗的戶外空間。憑藉多年的園藝經驗與專業技術,我們已成功完成眾多園藝景觀項目,為客戶打造夢想中的綠色家園。',
    'about.experience': '豐富經驗',
    'about.experienceDesc': '超過20年的園藝設計經驗',
    'about.projects': '成功案例',
    'about.projectsDesc': '完成500+個園藝項目',
    'about.support': '專業維護',
    'about.supportDesc': '提供長期植栽維護服務',
    
    // 作品集 - 按照圖片更新為4個項目
    'portfolio.title': '作品集',
    'portfolio.subtitle': '我們的園藝傑作',
    'portfolio.residential': '住宅庭園',
    'portfolio.residentialDesc': '私人住宅景觀設計,打造溫馨庭院綠洲',
    'portfolio.commercial': '商業空間',
    'portfolio.commercialDesc': '辦公大樓景觀工程,提升作業環境品質',
    'portfolio.public': '公共園區',
    'portfolio.publicDesc': '社區公園景觀改造,創造休憩新天地',
    'portfolio.rooftop': '屋頂花園',
    'portfolio.rooftopDesc': '都市屋頂綠化,充分利用垂直造景',
    'portfolio.viewProject': '查看項目',
    'portfolio.category.residential': '住宅',
    'portfolio.category.commercial': '商業',
    'portfolio.category.public': '公共',
    'portfolio.category.specialty': '專業',
    
    // 客戶見證 - 更新為6位客戶
    'testimonials.title': '客戶見證',
    'testimonials.subtitle': '客戶的滿意是我們的榮耀',
    'testimonials.client1': '林先生',
    'testimonials.client1Title': '超大型社區(>500戶)',
    'testimonials.client1Text': '悅境團隊作到了他們承諾的優化改造,我們對住戶有交代了,大家都很滿意。',
    'testimonials.client2': '王先生',
    'testimonials.client2Title': '地方首長公館(別墅)',
    'testimonials.client2Text': '為公館裡帶來豐富多樣的舒適感,維護工作也很棒,深得我們官長滿意.',
    'testimonials.client3': '李先生',
    'testimonials.client3Title': '科技廠商',
    'testimonials.client3Text': '廠區整體維護一致化,園藝技師專業優質。',
    'testimonials.client4': '黃小姐',
    'testimonials.client4Title': '商務大樓',
    'testimonials.client4Text': '長期配合的廠商,園藝師父們都很熱情好配合。',
    'testimonials.client5': '陳小姐',
    'testimonials.client5Title': '四星級飯店',
    'testimonials.client5Text': '利用巧妙的設計和創新點子,展現園藝工藝的細節,增添人氣感與活力。',
    'testimonials.client6': '張先生',
    'testimonials.client6Title': '頂級私人會所',
    'testimonials.client6Text': '在過去的合作經驗很不錯,但高峰期要提早約時間。',
    
    // 聯絡我們 - 園藝需求表單
    'contact.title': '讓您的綠色夢想啟航!',
    'contact.subtitle': '讓我們開始合作',
    'contact.description': '我們會準備您專屬的園藝景觀優惠方案。請填寫以下資訊,讓我們更了解您的需求。',
    'contact.name': '姓名',
    'contact.namePlaceholder': '請輸入您的姓名',
    'contact.email': '電子郵件',
    'contact.emailPlaceholder': '請輸入您的電子郵件',
    'contact.phone': '聯絡電話',
    'contact.phonePlaceholder': '請輸入您的聯絡電話',
    'contact.location': '專案地點',
    'contact.locationPlaceholder': '請輸入專案所在地區',
    'contact.serviceType': '服務類型',
    'contact.selectService': '請選擇服務類型',
    'contact.gardenDesign': '花園設計',
    'contact.landscaping': '景觀工程',
    'contact.maintenance': '園藝維護',
    'contact.planting': '植栽規劃',
    'contact.irrigation': '灌溉系統',
    'contact.consultation': '諮詢服務',
    'contact.projectSize': '專案規模',
    'contact.selectSize': '請選擇專案規模',
    'contact.smallProject': '小型專案(20坪以下)',
    'contact.mediumProject': '中型專案(20-100坪)',
    'contact.largeProject': '大型專案(100坪以上)',
    'contact.budget': '預算範圍',
    'contact.selectBudget': '請選擇預算範圍',
    'contact.budgetUnder50k': '2萬以下',
    'contact.budget50k100k': '2-10萬',
    'contact.budget100k200k': '10-50萬',
    'contact.budgetOver200k': '50萬以上',
    'contact.timeline': '預期時程',
    'contact.selectTimeline': '請選擇預期時程',
    'contact.timelineASAP': '盡快開始',
    'contact.timeline1to3': '1週內',
    'contact.timeline3to6': '2週內',
    'contact.timeline6plus': '1個月以上',
    'contact.message': '詳細需求描述',
    'contact.messagePlaceholder': '請描述您的園藝需求、特殊要求或其他相關資訊...',
    'contact.send': '提交需求',
    'contact.sending': '提交中...',
    'contact.successMessage': '感謝您的提交!我們會在24小時內與您聯繫,為您準備專屬的園藝方案。',
    'contact.errorMessage': '提交失敗,請稍後再試或直接聯繫我們。',
    'contact.address': '地址',
    'contact.freeConsult': '免費諮詢',
    'contact.consultDesc': '立即預約免費諮詢,了解我們如何為您打造夢想花園',
    'contact.bookConsult': '預約諮詢',
    
    // 頁尾
    'footer.description': '悅境園藝專業提供園藝設計、景觀工程與植栽維護服務,為您打造完美的綠色空間。',
    'footer.quickLinks': '快速連結',
    'footer.services': '服務項目',
    'footer.contact': '聯絡資訊',
    'footer.rights': '版權所有',
    
    // YouTube影片展示區
    'youtube.title': '觀看次數超過 60K⁺ 的精選影片',
    'youtube.subtitle': '探索我們的專業園藝作品與服務實例',
	
    // 音頻播放器
    'audio.promptTitle': '想聽聽 EGD 的故事嗎?',
    'audio.promptSubtitle': '了解我們的理念',
    'audio.startListening': '開始聆聽',
    'audio.decline': '稍後再說',
    'audio.title': 'EGD 介紹 (30秒)',
    'audio.minimize': '最小化',
    'audio.expand': '展開',
    'audio.play': '播放',
    'audio.pause': '暫停',
    'audio.close': '關閉',
  },
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.about': 'About Us',
    'nav.services': 'Services',
    'nav.portfolio': 'Portfolio',
    'nav.testimonials': 'Testimonials',
    'nav.contact': 'Free Consultation',
    'nav.watchVideo': 'Watch Video',
    'nav.videos': 'Videos',
    
    // Hero Section - Garden Theme
    'hero.title': 'Landscape Design',
    'hero.subtitle': 'Create Your Dream Green Space',
    'hero.description': 'Professional landscape design and engineering.',
    'hero.getStarted': 'Get Started',
    'hero.learnMore': 'Learn More',
    
    // Services - Garden Related
    'services.title': 'Our Services (Taoyuan / Hsinchu Area)',
    'services.subtitle': 'Professional Comprehensive Garden & Landscape Solutions',
    'services.gardenDesign': 'Garden Design',
    'services.gardenDesignDesc': 'Custom garden design that combines aesthetics with functionality',
    'services.landscaping': 'Landscape Construction',
    'services.landscapingDesc': 'Professional landscape construction team ensuring quality and safety',
    'services.maintenance': 'Plant Maintenance',
    'services.maintenanceDesc': 'Regular maintenance services to keep your garden green all year round',
    'services.irrigation': 'Irrigation System',
    'services.irrigationDesc': 'Smart irrigation system design that saves water and is eco-friendly',
    
    // About - Garden Professional
    'about.title': 'About EG Design',
    'about.subtitle': 'Professional Team, Dedicated Service',
    'about.description': 'We are a passionate professional garden team dedicated to creating beautiful outdoor spaces for our clients. With years of gardening experience and professional expertise, we have successfully completed numerous garden landscape projects, creating dream green homes for our clients.',
    'about.experience': 'Rich Experience',
    'about.experienceDesc': 'Over 20 years of garden design experience',
    'about.projects': 'Success Stories',
    'about.projectsDesc': 'Completed 500+ garden projects',
    'about.support': 'Professional Maintenance',
    'about.supportDesc': 'Providing long-term plant maintenance services',
    
    // Portfolio - Updated to match the 4 projects in image
    'portfolio.title': 'Portfolio',
    'portfolio.subtitle': 'Our Garden Masterpieces',
    'portfolio.residential': 'Residential Garden',
    'portfolio.residentialDesc': 'Private residential landscape design, creating cozy courtyard oasis',
    'portfolio.commercial': 'Commercial Space',
    'portfolio.commercialDesc': 'Office building landscape projects, enhancing work environment quality',
    'portfolio.public': 'Public Garden',
    'portfolio.publicDesc': 'Community park landscape renovation, creating new recreational spaces',
    'portfolio.rooftop': 'Rooftop Garden',
    'portfolio.rooftopDesc': 'Urban rooftop greening, maximizing vertical landscaping',
    'portfolio.viewProject': 'View Project',
    'portfolio.category.residential': 'Residential',
    'portfolio.category.commercial': 'Commercial',
    'portfolio.category.public': 'Public',
    'portfolio.category.specialty': 'Specialty',
    
    // Testimonials - Updated to 6 clients
    'testimonials.title': 'Testimonials',
    'testimonials.subtitle': 'Client satisfaction is our pride',
    'testimonials.client1': 'Mr. Lin',
    'testimonials.client1Title': 'Large Community (>500 Units)',
    'testimonials.client1Text': 'Project Harmony delivered the promised upgrades, satisfying all residents.',
    'testimonials.client2': 'Mr. Wang',
    'testimonials.client2Title': 'Governor\'s Residence (Villa)',
    'testimonials.client2Text': 'The residence now offers diverse and luxurious comfort, and the excellent maintenance work has completely satisfied our supervising officer.',
    'testimonials.client3': 'Mr. Li',
    'testimonials.client3Title': 'Technology Company',
    'testimonials.client3Text': 'Uniform facility maintenance is achieved across the entire site, supported by professional and high-quality horticultural technicians.',
    'testimonials.client4': 'Ms. Huang',
    'testimonials.client4Title': 'Commercial Building',
    'testimonials.client4Text': 'Our long-term vendor, whose horticultural staff are both enthusiastic and highly cooperative.',
    'testimonials.client5': 'Ms. Chen',
    'testimonials.client5Title': 'Four-Star Hotel',
    'testimonials.client5Text': 'Utilizing ingenious designs and innovative ideas to showcase detailed horticultural craftsmanship, boosting both vitality and a sense of inviting warmth.',
    'testimonials.client6': 'Mr. Zhang',
    'testimonials.client6Title': 'Premium Private Club',
    'testimonials.client6Text': 'Our past collaborations have been excellent, but advance booking is essential during peak seasons.',
    
    // Contact - Garden Requirements Form
    'contact.title': 'Let Your Green Dreams Take Flight!',
    'contact.subtitle': 'Let\'s Start Working Together',
    'contact.description': 'We will prepare an exclusive garden landscape package just for you. Please fill out the following information so we can better understand your needs.',
    'contact.name': 'Name',
    'contact.namePlaceholder': 'Please enter your name',
    'contact.email': 'Email',
    'contact.emailPlaceholder': 'Please enter your email address',
    'contact.phone': 'Phone',
    'contact.phonePlaceholder': 'Please enter your phone number',
    'contact.location': 'Project Location',
    'contact.locationPlaceholder': 'Please enter the project location',
    'contact.serviceType': 'Service Type',
    'contact.selectService': 'Please select service type',
    'contact.gardenDesign': 'Garden Design',
    'contact.landscaping': 'Landscaping',
    'contact.maintenance': 'Garden Maintenance',
    'contact.planting': 'Planting Planning',
    'contact.irrigation': 'Irrigation System',
    'contact.consultation': 'Consultation Service',
    'contact.projectSize': 'Project Size',
    'contact.selectSize': 'Please select project size',
    'contact.smallProject': 'Small Project (Under 1,800 sq ft)',
    'contact.mediumProject': 'Medium Project (1,800-7,200 sq ft)',
    'contact.largeProject': 'Large Project (Over 7,200 sq ft)',
    'contact.budget': 'Budget Range',
    'contact.selectBudget': 'Please select budget range',
    'contact.budgetUnder50k': 'Under $1,500',
    'contact.budget50k100k': '$1,500-$3,000',
    'contact.budget100k200k': '$3,000-$6,000',
    'contact.budgetOver200k': 'Over $6,000',
    'contact.timeline': 'Timeline',
    'contact.selectTimeline': 'Please select expected timeline',
    'contact.timelineASAP': 'Start ASAP',
    'contact.timeline1to3': 'Within 1-3 months',
    'contact.timeline3to6': 'Within 3-6 months',
    'contact.timeline6plus': 'Over 6 months',
    'contact.message': 'Detailed Requirements',
    'contact.messagePlaceholder': 'Please describe your garden requirements, special requests, or other relevant information...',
    'contact.send': 'Submit Requirements',
    'contact.sending': 'Submitting...',
    'contact.successMessage': 'Thank you for your submission! We will contact you within 24 hours to prepare an exclusive garden plan for you.',
    'contact.errorMessage': 'Submission failed. Please try again later or contact us directly.',
    'contact.address': 'Address',
    'contact.freeConsult': 'Free Consultation',
    'contact.consultDesc': 'Book a free consultation now to learn how we can create your dream garden',
    'contact.bookConsult': 'Book Consultation',
    
    // Footer
    'footer.description': 'EG Design Garden professionally provides garden design, landscape construction and plant maintenance services to create the perfect green space for you.',
    'footer.quickLinks': 'Quick Links',
    'footer.services': 'Services',
    'footer.contact': 'Contact Info',
    'footer.rights': 'All rights reserved',
    
    // YouTube Gallery
    'youtube.title': 'Our Most Popular Videos (60K⁺ Views)',
    'youtube.subtitle': 'Explore our professional garden works and service examples',
	
    // AudioPlayer
    'audio.promptTitle': 'Would you like to hear EGD story?',
    'audio.promptSubtitle': 'Understand our philosophy in 30 Seconds',
    'audio.startListening': 'Start Listening',
    'audio.decline': 'Later',
    'audio.title': 'EGD Introduction (30 Seconds)',
    'audio.minimize': 'Minimize',
    'audio.expand': 'Expand',
    'audio.play': 'Play',
    'audio.pause': 'Pause',
    'audio.close': 'Close',
  }
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en')

  const t = (key: string): string => {
    return translations[language][key] || key
  }

  const getAudioUrl = (): string => {
    return audioUrls[language]
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, getAudioUrl }}>
      {children}
    </LanguageContext.Provider>
  )
}