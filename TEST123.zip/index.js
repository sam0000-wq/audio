const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs').promises;
const path = require('path');
const Papa = require('papaparse');
const ExcelJS = require('exceljs');

const app = express();
const PORT = 3002;

// 修正 CORS 設定
app.use(cors({
  origin: '*',
  credentials: true
}));

app.use(express.json());

const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 }
});

const KNOWLEDGE_BASE_PATH = path.join(__dirname, '../../src/services/knowledgeBase.ts');

async function parseCSV(filePath) {
  const fileContent = await fs.readFile(filePath, 'utf-8');
  return new Promise((resolve, reject) => {
    Papa.parse(fileContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => resolve(results.data),
      error: (error) => reject(error)
    });
  });
}

async function parseExcel(filePath) {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(filePath);
  
  const worksheet = workbook.worksheets[0];
  if (!worksheet) throw new Error('Excel 文件中沒有工作表');

  const jsonData = [];
  worksheet.eachRow((row, rowNumber) => {
    const rowValues = row.values.slice(1);
    jsonData.push(rowValues);
  });

  if (jsonData.length < 2) throw new Error('Excel 文件至少需要標題行和一行數據');

  const headers = jsonData[0].map(h => String(h || ''));
  const rows = jsonData.slice(1);

  return rows
    .filter(row => row.some(cell => cell !== null && cell !== undefined && cell !== ''))
    .map(row => {
      const obj = {};
      headers.forEach((header, index) => {
        const value = row[index];
        obj[header] = value !== null && value !== undefined ? String(value) : '';
      });
      return obj;
    });
}

app.post('/api/upload-knowledge', upload.single('file'), async (req, res) => {
  let uploadedFilePath = null;
  
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: '沒有上傳檔案' });
    }

    uploadedFilePath = req.file.path;
    const mode = req.body.mode || 'replace';
    const fileExtension = req.file.originalname.toLowerCase().split('.').pop();

    let rawData;
    if (fileExtension === 'csv') {
      rawData = await parseCSV(uploadedFilePath);
    } else if (['xlsx', 'xls'].includes(fileExtension)) {
      rawData = await parseExcel(uploadedFilePath);
    } else {
      throw new Error('不支援的檔案格式');
    }

    const zhData = [];
    const enData = [];
    const categories = new Set();

    rawData.forEach(row => {
      const item = {
        keywords: row.keywords ? row.keywords.split(',').map(k => k.trim()) : [],
        question: row.question || '',
        answer: row.answer || '',
        category: row.category || '其他',
        priority: parseInt(row.priority) || 1,
        enabled: row.enabled === 'true' || row.enabled === true
      };

      categories.add(item.category);

      if (row.language === 'zh') {
        zhData.push(item);
      } else if (row.language === 'en') {
        enData.push(item);
      }
    });

    const dir = path.dirname(KNOWLEDGE_BASE_PATH);
    await fs.mkdir(dir, { recursive: true });

    let existingZh = [];
    let existingEn = [];
    
    try {
      const fileContent = await fs.readFile(KNOWLEDGE_BASE_PATH, 'utf-8');
      if (mode === 'merge') {
        existingZh = extractExistingData(fileContent, 'zh');
        existingEn = extractExistingData(fileContent, 'en');
      }
    } catch (e) {
      console.log('無法讀取現有知識庫，將建立新檔案');
    }

    const finalZh = mode === 'merge' ? mergeData(existingZh, zhData) : zhData;
    const finalEn = mode === 'merge' ? mergeData(existingEn, enData) : enData;

    const newContent = generateKnowledgeBaseContent(finalZh, finalEn);
    await fs.writeFile(KNOWLEDGE_BASE_PATH, newContent, 'utf-8');

    await fs.unlink(uploadedFilePath);

    res.json({
      success: true,
      message: `成功導入 ${rawData.length} 筆資料`,
      stats: {
        total: rawData.length,
        zh: zhData.length,
        en: enData.length,
        categories: Array.from(categories)
      }
    });

    console.log(`✅ 成功上傳知識庫: ${rawData.length} 筆資料 (中文: ${zhData.length}, 英文: ${enData.length})`);

  } catch (error) {
    console.error('上傳錯誤:', error);
    
    if (uploadedFilePath) {
      try {
        await fs.unlink(uploadedFilePath);
      } catch (e) {
        console.error('刪除暫存檔失敗:', e);
      }
    }

    res.status(500).json({
      success: false,
      message: error.message || '上傳失敗'
    });
  }
});

app.get('/api/download-template', async (req, res) => {
  try {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('知識庫範本');

    worksheet.columns = [
      { header: 'language', key: 'language', width: 10 },
      { header: 'keywords', key: 'keywords', width: 30 },
      { header: 'question', key: 'question', width: 40 },
      { header: 'answer', key: 'answer', width: 50 },
      { header: 'category', key: 'category', width: 15 },
      { header: 'priority', key: 'priority', width: 10 },
      { header: 'enabled', key: 'enabled', width: 10 }
    ];

    worksheet.addRow({
      language: 'zh',
      keywords: '關鍵字1,關鍵字2',
      question: '這是問題範例',
      answer: '這是答案範例',
      category: '一般問題',
      priority: 1,
      enabled: true
    });

    worksheet.addRow({
      language: 'en',
      keywords: 'keyword1,keyword2',
      question: 'This is a sample question',
      answer: 'This is a sample answer',
      category: 'General',
      priority: 1,
      enabled: true
    });

    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=knowledge-template.xlsx');

    await workbook.xlsx.write(res);
    res.end();

    console.log('✅ 成功下載範本');

  } catch (error) {
    console.error('下載範本錯誤:', error);
    res.status(500).json({ success: false, message: '下載範本失敗: ' + error.message });
  }
});

app.get('/api/export-knowledge', async (req, res) => {
  try {
    const fileContent = await fs.readFile(KNOWLEDGE_BASE_PATH, 'utf-8');
    const zhData = extractExistingData(fileContent, 'zh');
    const enData = extractExistingData(fileContent, 'en');

    if (zhData.length === 0 && enData.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: '知識庫中沒有資料' 
      });
    }

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('知識庫');

    worksheet.columns = [
      { header: 'language', key: 'language', width: 10 },
      { header: 'keywords', key: 'keywords', width: 30 },
      { header: 'question', key: 'question', width: 40 },
      { header: 'answer', key: 'answer', width: 50 },
      { header: 'category', key: 'category', width: 15 },
      { header: 'priority', key: 'priority', width: 10 },
      { header: 'enabled', key: 'enabled', width: 10 }
    ];

    zhData.forEach(item => {
      worksheet.addRow({
        language: 'zh',
        keywords: Array.isArray(item.keywords) ? item.keywords.join(',') : '',
        question: item.question || '',
        answer: item.answer || '',
        category: item.category || '',
        priority: item.priority || 1,
        enabled: item.enabled !== false
      });
    });

    enData.forEach(item => {
      worksheet.addRow({
        language: 'en',
        keywords: Array.isArray(item.keywords) ? item.keywords.join(',') : '',
        question: item.question || '',
        answer: item.answer || '',
        category: item.category || '',
        priority: item.priority || 1,
        enabled: item.enabled !== false
      });
    });

    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `knowledge-export-${timestamp}.xlsx`;

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=${filename}`);

    await workbook.xlsx.write(res);
    res.end();

    console.log(`✅ 成功導出知識庫: ${zhData.length + enData.length} 筆資料`);

  } catch (error) {
    console.error('導出知識庫錯誤:', error);
    res.status(500).json({ success: false, message: '導出知識庫失敗: ' + error.message });
  }
});

function generateKnowledgeBaseContent(zhData, enData) {
  const formatItem = (item) => {
    const keywords = item.keywords.map(k => `'${k}'`).join(', ');
    const question = item.question.replace(/'/g, "\\'").replace(/\n/g, '\\n');
    const answer = item.answer.replace(/'/g, "\\'").replace(/\n/g, '\\n');
    return `    {
      keywords: [${keywords}],
      question: '${question}',
      answer: '${answer}',
      category: '${item.category}',
      priority: ${item.priority},
      enabled: ${item.enabled}
    }`;
  };

  const zhItems = zhData.map(formatItem).join(',\n');
  const enItems = enData.map(formatItem).join(',\n');

  return `// 知識庫類型定義
export interface KnowledgeItem {
  keywords: string[];
  question: string;
  answer: string;
  category: string;
  priority: number;
  enabled: boolean;
}

// 知識庫數據
export const knowledgeBase: Record<'zh' | 'en', KnowledgeItem[]> = {
  zh: [
${zhItems}
  ],
  en: [
${enItems}
  ]
};

// 搜索知識庫
export const searchKnowledge = (query: string, language: 'zh' | 'en' = 'zh'): KnowledgeItem | null => {
  const items = knowledgeBase[language] || knowledgeBase.zh;
  const lowerQuery = query.toLowerCase();
  
  // 尋找最佳匹配
  for (const item of items) {
    // 跳過未啟用的項目
    if (item.enabled === false) continue;
    
    for (const keyword of item.keywords) {
      if (lowerQuery.includes(keyword.toLowerCase())) {
        return item;
      }
    }
  }
  
  return null;
};

// 獲取隨機回應(當沒有找到匹配時)
export const getRandomResponse = (language: 'zh' | 'en' = 'zh'): string => {
  const responses = language === 'zh' ? [
    '很抱歉，我在知識庫中沒有找到相關的資訊。\\n\\n不過別擔心！您可以：\\n• 直接聯繫我們的專業園藝顧問\\n• 重新描述您的問題，我會再次為您查找\\n• 查看我們的常見問題頁面\\n\\n我們的專家團隊隨時準備為您提供專業建議！',
    '抱歉我暫時無法回答這個問題。\\n\\n建議您可以：\\n• 嘗試用不同的關鍵字重新提問\\n• 撥打我們的服務專線\\n• 透過聯絡表單詳細描述您的需求\\n\\n我們會盡快為您提供專業的園藝建議！',
    '這個問題超出了我目前的知識範圍。\\n\\n為了給您最專業的回答：\\n• 建議預約免費諮詢服務\\n• 加入我們的官方LINE獲得即時協助\\n• 瀏覽我們的作品集找尋靈感\\n\\n讓專業團隊為您打造夢想花園！'
  ] : [
    'I apologize, but I couldn\\'t find relevant information in my knowledge base.\\n\\nDon\\'t worry! You can:\\n• Contact our professional gardening consultants directly\\n• Rephrase your question and I\\'ll search again\\n• Check our FAQ page\\n\\nOur expert team is always ready to provide professional advice!',
    'Sorry, I can\\'t answer this question at the moment.\\n\\nI suggest you:\\n• Try different keywords to rephrase your question\\n• Call our service hotline\\n• Use our contact form to describe your needs in detail\\n\\nWe\\'ll provide professional gardening advice as soon as possible!',
    'This question is beyond my current knowledge scope.\\n\\nFor the most professional answer:\\n• Book a free consultation service\\n• Join our official LINE for instant assistance\\n• Browse our portfolio for inspiration\\n\\nLet our professional team create your dream garden!'
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
};

// 獲取所有分類
export const getCategories = (language: 'zh' | 'en' = 'zh'): string[] => {
  const items = knowledgeBase[language] || knowledgeBase.zh;
  const categories = [...new Set(items.map(item => item.category))];
  return categories;
};

// 根據分類獲取問題
export const getQuestionsByCategory = (category: string, language: 'zh' | 'en' = 'zh'): KnowledgeItem[] => {
  const items = knowledgeBase[language] || knowledgeBase.zh;
  return items.filter(item => item.category === category && item.enabled !== false);
};
`;
}

function extractExistingData(fileContent, lang) {
  const data = [];
  
  const langStart = fileContent.indexOf(`${lang}: [`);
  if (langStart === -1) return data;
  
  let braceCount = 0;
  let inArray = false;
  let currentItem = {};
  let currentKey = '';
  let currentValue = '';
  let inString = false;
  let inArray2 = false;
  
  for (let i = langStart; i < fileContent.length; i++) {
    const char = fileContent[i];
    
    if (char === '[' && !inString) {
      if (!inArray) {
        inArray = true;
        continue;
      } else {
        inArray2 = true;
      }
    }
    
    if (char === ']' && !inString) {
      if (inArray2) {
        inArray2 = false;
        if (currentKey === 'keywords') {
          currentItem.keywords = currentValue.split(',').map(k => k.trim().replace(/'/g, ''));
          currentValue = '';
        }
      } else if (inArray && braceCount === 0) {
        if (Object.keys(currentItem).length > 0) {
          data.push(currentItem);
        }
        break;
      }
    }
    
    if (char === '{' && !inString) {
      braceCount++;
      if (braceCount === 1) {
        currentItem = {};
      }
      continue;
    }
    
    if (char === '}' && !inString) {
      braceCount--;
      if (braceCount === 0 && Object.keys(currentItem).length > 0) {
        if (currentKey && currentValue) {
          if (currentKey === 'priority') {
            currentItem[currentKey] = parseInt(currentValue);
          } else if (currentKey === 'enabled') {
            currentItem[currentKey] = currentValue.trim() === 'true';
          } else {
            currentItem[currentKey] = currentValue.replace(/\\n/g, '\n').replace(/\\'/g, "'");
          }
        }
        data.push(currentItem);
        currentItem = {};
        currentKey = '';
        currentValue = '';
      }
      continue;
    }
    
    if (braceCount > 0) {
      if (char === "'" && fileContent[i - 1] !== '\\') {
        inString = !inString;
        continue;
      }
      
      if (!inString && char === ':') {
        currentKey = currentValue.trim();
        currentValue = '';
        continue;
      }
      
      if (!inString && (char === ',' || char === '\n') && currentKey && !inArray2) {
        if (currentKey === 'keywords') {
        } else if (currentKey === 'priority') {
          currentItem[currentKey] = parseInt(currentValue.trim());
        } else if (currentKey === 'enabled') {
          currentItem[currentKey] = currentValue.trim() === 'true';
        } else {
          currentItem[currentKey] = currentValue.trim().replace(/\\n/g, '\n').replace(/\\'/g, "'");
        }
        currentKey = '';
        currentValue = '';
        continue;
      }
      
      if (inString || inArray2 || (char !== ' ' && char !== '\n' && char !== '\t') || currentValue.length > 0) {
        currentValue += char;
      }
    }
  }
  
  return data;
}

function mergeData(existing, newData) {
  const questionSet = new Set(existing.map(item => item.question));
  const merged = [...existing];

  newData.forEach(item => {
    if (!questionSet.has(item.question)) {
      merged.push(item);
    }
  });

  return merged;
}

app.listen(PORT, () => {
  console.log(`🚀 後端伺服器運行在 http://localhost:${PORT}`);
  console.log(`📁 知識庫路徑: ${KNOWLEDGE_BASE_PATH}`);
});
