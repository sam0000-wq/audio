import React from "react";
import ChatAvatar from "./ChatAvatar";

interface Message {
  id: string;
  type: "user" | "bot";
  content: string;
  timestamp: Date;
  isTyping?: boolean;
}

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const formatContent = (content: string) => {
    return content.split("\n").map((line, index) => (
      <span key={index}>
        {line}
        {index < content.split("\n").length - 1 && <br />}
      </span>
    ));
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("zh-TW", {
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  if (message.type === "bot") {
    return (
      <div className="flex items-start space-x-3 animate-fade-in">
        <ChatAvatar size="sm" />
        <div className="bg-white rounded-2xl rounded-tl-md p-4 shadow-sm border max-w-[85%] min-h-[40px]">
          <div className="text-gray-800 text-sm leading-relaxed whitespace-pre-wrap">
            {formatContent(message.content)}
          </div>
          <div className="text-xs text-gray-400 mt-2">
            {formatTime(message.timestamp)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start space-x-3 justify-end animate-fade-in">
      <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-2xl rounded-tr-md p-4 shadow-sm max-w-[85%] min-h-[40px]">
        <div className="text-sm leading-relaxed whitespace-pre-wrap">
          {formatContent(message.content)}
        </div>
        <div className="text-xs text-green-100 mt-2 text-right">
          {formatTime(message.timestamp)}
        </div>
      </div>
      <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
        <span className="text-xs font-medium text-gray-600">您</span>
      </div>
    </div>
  );
};

export default ChatMessage;
 
