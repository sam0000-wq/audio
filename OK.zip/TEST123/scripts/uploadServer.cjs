const express = require('express');
const multer = require('multer');
const cors = require('cors');
const ExcelJS = require('exceljs');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const upload = multer({ storage: multer.memoryStorage() });

app.use(cors());
app.use(express.json());

// 寫入 LOG 的函數 - 使用 GMT+8 時間
async function writeLog(message) {
  const now = new Date();
  // 轉換成 GMT+8 時間
  const taiwanTime = new Date(now.getTime() + (8 * 60 * 60 * 1000));
  const timestamp = taiwanTime.toISOString().replace('T', ' ').substring(0, 19);
  const logMessage = `[${timestamp}] ${message}\n`;
  const logPath = path.join(__dirname, '../upload.log');
  
  try {
    await fs.appendFile(logPath, logMessage, 'utf-8');
    console.log(message); // 同時輸出到終端
  } catch (error) {
    console.error('寫入 LOG 失敗:', error);
  }
}

// 上傳端點
app.post('/api/upload-videos', upload.single('file'), async (req, res) => {
  try {
    await writeLog('\n========== 開始新的上傳 ==========');
    
    if (!req.file) {
      await writeLog('❌ 沒有收到檔案');
      return res.status(400).json({ success: false, message: '沒有收到檔案' });
    }

    await writeLog(`📁 檔案名稱: ${req.file.originalname}`);
    await writeLog(`📊 檔案大小: ${(req.file.size / 1024).toFixed(2)} KB`);

    // 解析 Excel
    await writeLog('🔍 開始解析 Excel...');
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(req.file.buffer);
    const worksheet = workbook.getWorksheet(1);

    const videos = [];
    const headers = worksheet.getRow(1).values;

    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;

      const rowData = {};
      headers.forEach((header, index) => {
        if (header) {
          rowData[header] = row.getCell(index).value;
        }
      });

      videos.push({
        videoId: String(rowData.videoId || ''),
        title_zh: String(rowData.title_zh || ''),
        title_en: String(rowData.title_en || ''),
        description_zh: String(rowData.description_zh || ''),
        description_en: String(rowData.description_en || ''),
        category: (rowData.category === 'hero' || rowData.category === 'gallery') ? rowData.category : 'gallery',
        enabled: rowData.enabled === 'true' || rowData.enabled === true || rowData.enabled === 1
      });
    });

    await writeLog(`✅ 解析完成，共 ${videos.length} 筆資料`);
    
    // 記錄每筆資料
    await writeLog('\n📋 資料內容：');
    for (let i = 0; i < videos.length; i++) {
      const v = videos[i];
      await writeLog(`  ${i + 1}. [${v.category}] ${v.videoId} - ${v.title_zh} (enabled: ${v.enabled})`);
    }

    // 生成新的 videoBase.ts 內容
    const fileContent = `// src/services/videoBase.ts

export interface VideoItem {
  videoId: string;
  title_zh: string;
  title_en: string;
  description_zh: string;
  description_en: string;
  category: 'hero' | 'gallery';
  enabled: boolean;
}

export const videoBase: VideoItem[] = ${JSON.stringify(videos, null, 2)};
`;

    // 寫入檔案
    const filePath = path.join(__dirname, '../src/services/videoBase.ts');
    await writeLog(`\n📝 準備寫入檔案: ${filePath}`);
    
    // 備份舊檔案 - 使用易讀的日期格式 (GMT+8)
    try {
      const oldContent = await fs.readFile(filePath, 'utf-8');
      const now = new Date();
      const taiwanTime = new Date(now.getTime() + (8 * 60 * 60 * 1000));
      const dateStr = taiwanTime.toISOString().replace(/[:.]/g, '-').substring(0, 19); // 2025-11-20T10-30-45
      const backupPath = path.join(__dirname, `../videoBase.backup.${dateStr}.ts`);
      await fs.writeFile(backupPath, oldContent, 'utf-8');
      await writeLog(`💾 已備份舊檔案: ${backupPath}`);
    } catch (error) {
      await writeLog(`⚠️  無法備份舊檔案: ${error.message}`);
    }
    
    await fs.writeFile(filePath, fileContent, 'utf-8');
    
    await writeLog('✅ 已成功寫入檔案');
    await writeLog(`📊 寫入統計: ${videos.length} 筆資料, 檔案大小: ${(fileContent.length / 1024).toFixed(2)} KB`);
    await writeLog('========== 上傳完成 ==========\n');

    res.json({
      success: true,
      message: `成功更新 ${videos.length} 筆影片資料到 videoBase.ts`
    });

  } catch (error) {
    await writeLog(`❌ 上傳失敗: ${error.message}`);
    await writeLog(`❌ 錯誤堆疊: ${error.stack}`);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

const PORT = 3001;
app.listen(PORT, async () => {
  const message = `✅ 上傳服務器運行在 http://localhost:${PORT}`;
  console.log(message);
  await writeLog(message);
  await writeLog(`📁 LOG 檔案位置: ${path.join(__dirname, '../upload.log')}`);
});