import React from "react"
import {Star} from 'lucide-react'
import { useLanguage } from "../contexts/LanguageContext"

const TestimonialsSection: React.FC = () => {
  const { t } = useLanguage()

  const testimonials = [
    {
      name: t("testimonials.client1"),
      title: t("testimonials.client1Title"),
      text: t("testimonials.client1Text"),
      rating: 5
    },
    {
      name: t("testimonials.client2"),
      title: t("testimonials.client2Title"),
      text: t("testimonials.client2Text"),
      rating: 5
    },
    {
      name: t("testimonials.client3"),
      title: t("testimonials.client3Title"),
      text: t("testimonials.client3Text"),
      rating: 5
    },
    {
      name: t("testimonials.client4"),
      title: t("testimonials.client4Title"),
      text: t("testimonials.client4Text"),
      rating: 5
    },
    {
      name: t("testimonials.client5"),
      title: t("testimonials.client5Title"),
      text: t("testimonials.client5Text"),
      rating: 5
    },
    {
      name: t("testimonials.client6"),
      title: t("testimonials.client6Title"),
      text: t("testimonials.client6Text"),
      rating: 5
    }
  ]

  return (
    <section id="testimonials" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t("testimonials.title")}
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {t("testimonials.subtitle")}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300"
            >
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <p className="text-gray-700 mb-6 leading-relaxed text-sm">
                "{testimonial.text}"
              </p>
              
              <div className="border-t pt-4">
                <h3 className="font-semibold text-gray-900 text-sm">
                  {testimonial.name}
                </h3>
                <p className="text-gray-600 text-sm">{testimonial.title}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default TestimonialsSection 
