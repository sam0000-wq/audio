import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';

interface NoResultsMessageProps {
  message: string;
}

const NoResultsMessage: React.FC<NoResultsMessageProps> = ({ message }) => {
  const { language } = useLanguage();

  return (
    <div className="bg-gradient-to-r from-orange-50 to-yellow-50 border border-orange-200 rounded-2xl rounded-tl-md px-4 py-3 shadow-sm">
      <div className="flex items-start space-x-2">
        <span className="text-orange-500 text-lg flex-shrink-0">🤔</span>
        <div className="flex-1">
          <p className="whitespace-pre-line leading-relaxed text-gray-700">
            {message}
          </p>
          
          {/* 快速操作按鈕 */}
          <div className="mt-3 flex flex-wrap gap-2">
          {/*  <button className="text-xs px-3 py-1 bg-green-100 text-green-700 rounded-full border border-green-200 hover:bg-green-200 transition-colors">
              {language === 'zh' ? '📞 聯繫專家' : '📞 Contact Expert'}
            </button> 
          */}

          <button
    onClick={() => window.open('https://line.me/R/oa/call/@055hjhgm?confirmation=true&from=call_url', '_blank')}
    className="text-xs px-3 py-1 bg-green-100 text-green-700 rounded-full border border-green-200 hover:bg-green-200 transition-colors"
  >
    {language === 'zh' ? '📞 聯繫專家' : '📞 Contact Expert'}
  </button>

            <button className="text-xs px-3 py-1 bg-blue-100 text-blue-700 rounded-full border border-blue-200 hover:bg-blue-200 transition-colors">
              {language === 'zh' ? '📋 常見問題' : '📋 FAQ'}
            </button>
            <button className="text-xs px-3 py-1 bg-purple-100 text-purple-700 rounded-full border border-purple-200 hover:bg-purple-200 transition-colors">
              {language === 'zh' ? '💬 重新提問' : '💬 Ask Again'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NoResultsMessage;
