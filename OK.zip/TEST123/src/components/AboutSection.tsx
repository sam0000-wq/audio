import React from 'react'
import {Award, Users, Clock} from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'

const AboutSection: React.FC = () => {
  const { t } = useLanguage()

  const stats = [
    {
      icon: <Award className="w-8 h-8 text-emerald-600" />,
      title: t('about.experience'),
      description: t('about.experienceDesc')
    },
    {
      icon: <Users className="w-8 h-8 text-emerald-600" />,
      title: t('about.projects'),
      description: t('about.projectsDesc')
    },
    {
      icon: <Clock className="w-8 h-8 text-emerald-600" />,
      title: t('about.support'),
      description: t('about.supportDesc')
    }
  ]

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="animate-on-scroll">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              {t('about.title')}
            </h2>
            <h3 className="text-xl text-emerald-600 font-semibold mb-6">
              {t('about.subtitle')}
            </h3>
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              {t('about.description')}
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-4">
                  <div className="flex justify-center mb-3">{stat.icon}</div>
                  <h4 className="font-semibold text-gray-900 mb-2">{stat.title}</h4>
                  <p className="text-sm text-gray-600">{stat.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="animate-on-scroll">
            <img
              src="https://i.ibb.co/HLz737Jn/5.webp"
              className="rounded-xl shadow-lg w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  )
}

export default AboutSection 
