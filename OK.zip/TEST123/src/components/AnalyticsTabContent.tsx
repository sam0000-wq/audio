import React from "react";
import { OperationLog, OperationStats } from "../constants/analyticsConstants";

interface OperationsTabProps {
  operationStats: OperationStats | null;
  operationLogs: OperationLog[];
  logsLoading: boolean;
  logFilter: string | null;
  setLogFilter: (filter: string | null) => void;
}

export const OperationsTab: React.FC<OperationsTabProps> = ({
  operationStats,
  operationLogs,
  logsLoading,
  logFilter,
  setLogFilter,
}) => {
  return (
    <>
      {operationStats && (
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/20 p-6 rounded-xl border border-blue-500/30">
            <div className="text-blue-400 text-sm mb-2">總操作數</div>
            <div className="text-4xl font-bold">{operationStats.total_operations}</div>
            <div className="text-xs text-gray-400 mt-2">最近 7 天: {operationStats.last_7_days}</div>
          </div>
          <div className="bg-gradient-to-br from-green-500/20 to-green-600/20 p-6 rounded-xl border border-green-500/30">
            <div className="text-green-400 text-sm mb-2">成功登入</div>
            <div className="text-4xl font-bold">{operationStats.login_success}</div>
            <div className="text-xs text-gray-400 mt-2">今日: {operationStats.today_operations}</div>
          </div>
          <div className="bg-gradient-to-br from-red-500/20 to-red-600/20 p-6 rounded-xl border border-red-500/30">
            <div className="text-red-400 text-sm mb-2">失敗/阻擋</div>
            <div className="text-4xl font-bold">{operationStats.login_failed + operationStats.login_blocked}</div>
            <div className="text-xs text-gray-400 mt-2">失敗: {operationStats.login_failed} | 阻擋: {operationStats.login_blocked}</div>
          </div>
        </div>
      )}

      <div className="bg-gray-800 p-6 rounded-xl">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">操作記錄</h3>
          <div className="flex gap-2">
            <button
              onClick={() => setLogFilter(null)}
              className={`px-3 py-1 rounded-lg text-sm transition-all ${
                logFilter === null
                  ? "bg-emerald-600 text-white"
                  : "bg-gray-700 text-gray-400 hover:bg-gray-600"
              }`}
            >
              全部
            </button>
            <button
              onClick={() => setLogFilter("login_success")}
              className={`px-3 py-1 rounded-lg text-sm transition-all ${
                logFilter === "login_success"
                  ? "bg-green-600 text-white"
                  : "bg-gray-700 text-gray-400 hover:bg-gray-600"
              }`}
            >
              成功
            </button>
            <button
              onClick={() => setLogFilter("login_failed")}
              className={`px-3 py-1 rounded-lg text-sm transition-all ${
                logFilter === "login_failed"
                  ? "bg-red-600 text-white"
                  : "bg-gray-700 text-gray-400 hover:bg-gray-600"
              }`}
            >
              失敗
            </button>
            <button
              onClick={() => setLogFilter("login_blocked")}
              className={`px-3 py-1 rounded-lg text-sm transition-all ${
                logFilter === "login_blocked"
                  ? "bg-orange-600 text-white"
                  : "bg-gray-700 text-gray-400 hover:bg-gray-600"
              }`}
            >
              阻擋
            </button>
          </div>
        </div>

        {logsLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-3 px-2">時間</th>
                  <th className="text-left py-3 px-2">帳號</th>
                  <th className="text-left py-3 px-2">操作類型</th>
                  <th className="text-left py-3 px-2">詳情</th>
                  <th className="text-left py-3 px-2">IP 地址</th>
                </tr>
              </thead>
              <tbody>
                {operationLogs.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="text-center py-8 text-gray-500">
                      暫無操作記錄
                    </td>
                  </tr>
                ) : (
                  operationLogs.map((log) => (
                    <tr
                      key={log.id}
                      className="border-b border-gray-700/50 hover:bg-gray-700/30 transition-colors"
                    >
                      <td className="py-3 px-2 text-xs text-gray-400">
                        {new Date(log.created_at).toLocaleString("zh-TW")}
                      </td>
                      <td className="py-3 px-2 font-semibold">
                        {log.username}
                      </td>
                      <td className="py-3 px-2">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            log.operation_type === "login_success"
                              ? "bg-green-600 text-white"
                              : log.operation_type === "login_failed"
                              ? "bg-red-600 text-white"
                              : log.operation_type === "login_blocked"
                              ? "bg-orange-600 text-white"
                              : "bg-gray-600 text-white"
                          }`}
                        >
                          {log.operation_type === "login_success" && "✓ 登入成功"}
                          {log.operation_type === "login_failed" && "✗ 登入失敗"}
                          {log.operation_type === "login_blocked" && "🚫 登入阻擋"}
                          {!log.operation_type.startsWith("login") && log.operation_type}
                        </span>
                      </td>
                      <td className="py-3 px-2 text-xs text-gray-400">
                        {log.operation_detail}
                      </td>
                      <td className="py-3 px-2 font-mono text-xs">
                        {log.ip_address}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
};
