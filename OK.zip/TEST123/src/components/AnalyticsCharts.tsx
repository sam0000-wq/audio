import React from "react";
import { ChartData, CountryData, TimeRange, VisitorLog, ComparisonStats, COUNTRY_NAME_MAP, WORLD_MAP_PATHS } from "../constants/analyticsConstants";

interface AnalyticsChartsProps {
  visitors: VisitorLog[];
  chartData: ChartData[];
  countryData: CountryData[];
  timeRange: TimeRange;
  setTimeRange: (range: TimeRange) => void;
  loading: boolean;
  totalVisits: number;
  uniqueVisitors: number;
  comparisonStats: ComparisonStats | null;
  reachedMilestone: number | null;
  exportToXLSX: () => void;
  hoveredCountry: string | null;
  setHoveredCountry: (country: string | null) => void;
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({
  visitors,
  chartData,
  countryData,
  timeRange,
  setTimeRange,
  loading,
  totalVisits,
  uniqueVisitors,
  comparisonStats,
  reachedMilestone,
  exportToXLSX,
  hoveredCountry,
  setHoveredCountry,
}) => {
  const normalizeCountryName = (country: string): string => {
    return COUNTRY_NAME_MAP[country] || country;
  };

  // ✅ 修改：淺綠色 → 黃色 → 橘色 → 紅色
  const getCountryColor = (country: string): string => {
    const normalizedCountry = normalizeCountryName(country);
    const data = countryData.find((c) => normalizeCountryName(c.country) === normalizedCountry);
    if (!data) return "#374151"; // 深灰色（無數據）

    const maxCount = Math.max(...countryData.map((c) => c.count), 1);
    const intensity = data.count / maxCount;

    if (intensity > 0.7) return "#dc2626"; // 紅色（熱區）
    if (intensity > 0.4) return "#f97316"; // 橘色（頻繁）
    if (intensity > 0.2) return "#eab308"; // 黃色（中等）
    return "#86efac"; // 淺綠色（一般）
  };

  const maxCount = Math.max(
    ...chartData.map((d) => Math.max(d.count, d.compareCount || 0)),
    1
  );

  return (
    <>
      {/* 統計卡片區 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/20 p-6 rounded-xl border border-blue-500/30">
          <div className="text-blue-400 text-sm mb-2">總訪問次數</div>
          <div className="text-4xl font-bold">{totalVisits}</div>
          {comparisonStats && (
            <div className={`text-xs mt-2 ${
              comparisonStats.changeType === "increase" ? "text-green-400" : 
              comparisonStats.changeType === "decrease" ? "text-red-400" : "text-gray-400"
            }`}>
              {comparisonStats.changeType === "increase" ? "↑" : 
               comparisonStats.changeType === "decrease" ? "↓" : "→"} 
              {Math.abs(comparisonStats.changePercent).toFixed(1)}% vs 上期
            </div>
          )}
        </div>

        <div className="bg-gradient-to-br from-emerald-500/20 to-emerald-600/20 p-6 rounded-xl border border-emerald-500/30">
          <div className="text-emerald-400 text-sm mb-2">獨立訪客</div>
          <div className="text-4xl font-bold">{uniqueVisitors}</div>
          <div className="text-xs text-gray-400 mt-2">來自 {countryData.length} 個國家</div>
        </div>

        <div className="bg-gradient-to-br from-purple-500/20 to-purple-600/20 p-6 rounded-xl border border-purple-500/30">
          <div className="text-purple-400 text-sm mb-2">時間範圍</div>
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as TimeRange)}
            className="bg-gray-700 text-white px-4 py-2 rounded-lg text-sm w-full"
          >
            <option value="week">最近 7 天</option>
            <option value="twoWeeks">最近 14 天</option>  {/* ✅ 新增 */}
            <option value="month">最近 30 天</option>
            <option value="year">最近 1 年</option>
          </select>
          {reachedMilestone && (
            <div className="text-xs text-yellow-400 mt-2">
              🎉 達成 {reachedMilestone} 訪客里程碑！
            </div>
          )}
        </div>
      </div>

      {/* 地圖區 + 匯出按鈕 */}
      <div className="bg-gray-800 p-6 rounded-xl">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">全球訪客分佈 (支援 195+ 國家)</h3>
          <button
            onClick={exportToXLSX}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            匯出 Excel
          </button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
          </div>
        ) : (
          <div className="relative">
            <svg
              viewBox="0 0 900 500"
              className="w-full h-auto"
              style={{ maxHeight: "400px" }}
            >
              <rect width="900" height="500" fill="#1f2937" />
              
              {Object.entries(WORLD_MAP_PATHS).map(([country, path]) => {
                const color = getCountryColor(country);
                const normalizedCountry = normalizeCountryName(country);
                const matchedData = countryData.find((c) => normalizeCountryName(c.country) === normalizedCountry);
                
                return (
                  <path
                    key={country}
                    d={path}
                    fill={color}
                    stroke="#374151"
                    strokeWidth="1"
                    className="transition-all duration-300 cursor-pointer hover:opacity-80"
                    onMouseEnter={() => setHoveredCountry(matchedData ? matchedData.country : country)}
                    onMouseLeave={() => setHoveredCountry(null)}
                  />
                );
              })}
            </svg>

            {hoveredCountry && (
              <div className="absolute top-4 left-4 bg-gray-900 border border-emerald-500 rounded-lg p-3 shadow-xl z-20">
                <div className="font-semibold text-emerald-400">{hoveredCountry}</div>
                {countryData.find((c) => c.country === hoveredCountry) && (
                  <div className="text-sm text-gray-300 mt-1">
                    訪問次數: {countryData.find((c) => c.country === hoveredCountry)?.count || 0}
                    <br />
                    訪客數: {countryData.find((c) => c.country === hoveredCountry)?.visitors || 0}
                  </div>
                )}
              </div>
            )}

            {/* ✅ 修改：圖例顏色 */}
            <div className="flex items-center gap-4 mt-4 text-sm">
              <span className="text-gray-400">訪問密度:</span>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 bg-[#86efac] rounded"></div>
                <span className="text-gray-400">一般</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 bg-[#eab308] rounded"></div>
                <span className="text-gray-400">中等</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 bg-[#f97316] rounded"></div>
                <span className="text-gray-400">頻繁</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-4 bg-[#dc2626] rounded"></div>
                <span className="text-gray-400">熱區</span>
              </div>
            </div>
            
            {countryData.length > 0 && (
              <div className="mt-4 p-3 bg-gray-900 rounded-lg text-xs">
                <div className="font-semibold text-emerald-400 mb-2">
                  數據庫中的國家 ({countryData.length}) | 地圖支援: {Object.keys(WORLD_MAP_PATHS).length} 個國家
                </div>
                <div className="flex flex-wrap gap-2">
                  {countryData.map((c) => {
                    const normalized = normalizeCountryName(c.country);
                    const hasMap = WORLD_MAP_PATHS.hasOwnProperty(normalized);
                    return (
                      <span
                        key={c.country}
                        className={`px-2 py-1 rounded ${
                          hasMap ? "bg-green-900 text-green-300" : "bg-red-900 text-red-300"
                        }`}
                        title={hasMap ? "已匹配" : "未匹配地圖"}
                      >
                        {c.country} {!hasMap && "❌"}
                      </span>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="bg-gray-800 p-6 rounded-xl">
        <h3 className="text-lg font-semibold mb-4">國家訪問排行</h3>
        <div className="space-y-3">
          {countryData.slice(0, 5).map((country, index) => {
            const maxCountryCount = countryData[0]?.count || 1;
            const percentage = (country.count / maxCountryCount) * 100;
            
            return (
              <div key={country.country} className="space-y-1">
                <div className="flex justify-between items-center text-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-400 font-bold">#{index + 1}</span>
                    <span>{country.country}</span>
                  </div>
                  <div className="text-gray-400">
                    {country.count} 次訪問 · {country.visitors} 訪客
                  </div>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-emerald-500 to-teal-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-gray-800 p-6 rounded-xl">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">訪問趨勢對比</h3>
          <div className="flex gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gradient-to-t from-emerald-600 to-teal-500 rounded"></div>
              <span className="text-gray-400">當前期間</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gradient-to-t from-orange-600 to-yellow-500 rounded"></div>
              <span className="text-gray-400">對比期間</span>
            </div>
          </div>
        </div>
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
          </div>
        ) : (
          <div className="h-64 flex items-end justify-between gap-1">
            {chartData.map((item, index) => (
              <div
                key={index}
                className="flex-1 flex flex-col items-center group"
              >
                <div className="relative w-full flex gap-0.5">
                  <div
                    className="flex-1 bg-gradient-to-t from-emerald-600 to-teal-500 rounded-t transition-all duration-300 hover:from-emerald-500 hover:to-teal-400 cursor-pointer"
                    style={{
                      height: `${(item.count / maxCount) * 200}px`,
                      minHeight: "4px",
                    }}
                  >
                    <div className="absolute -top-16 left-1/2 transform -translate-x-1/2 bg-gray-900 px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                      當前: {item.count} 次<br/>
                      對比: {item.compareCount || 0} 次
                    </div>
                  </div>
                  <div
                    className="flex-1 bg-gradient-to-t from-orange-600 to-yellow-500 rounded-t transition-all duration-300 opacity-60 hover:opacity-80 cursor-pointer"
                    style={{
                      height: `${((item.compareCount || 0) / maxCount) * 200}px`,
                      minHeight: "4px",
                    }}
                  ></div>
                </div>
                <div className="text-xs text-gray-400 mt-2 transform -rotate-45 origin-left whitespace-nowrap">
                  {item.date}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};