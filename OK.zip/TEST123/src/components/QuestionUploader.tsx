import React, { useState, useCallback, useRef } from 'react';
import {Upload, FileText, AlertCircle, CheckCircle, Download, RefreshCw, X, FileDown} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { dataImporter } from '../services/dataImporter';
import { validateFile } from '../utils/fileValidator';
import { UploadProgress, ValidationResult } from '../types/uploadTypes';
import toast from 'react-hot-toast';

interface QuestionUploaderProps {
  onClose: () => void;
  onSuccess?: () => void;
}

const QuestionUploader: React.FC<QuestionUploaderProps> = ({ onClose, onSuccess }) => {
  const { language } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({
    status: 'idle',
    progress: 0,
    message: ''
  });
  const [validation, setValidation] = useState<ValidationResult | null>(null);

  const texts = {
    zh: {
      title: '知識庫管理',
      subtitle: '導入CSV檔案替換整個知識庫',
      dragText: '拖拽檔案到此處，或點擊選擇檔案',
      supportedFormats: '支援格式:CSV, Excel (.xlsx, .xls)',
      maxSize: '最大檔案大小:10MB',
      selectFile: '選擇檔案',
      downloadTemplate: '下載範本',
      exportData: '導出知識庫',
      upload: '確認導入',
      uploading: '導入中...',
      processing: '處理中...',
      validating: '驗證中...',
      success: '導入成功!',
      close: '關閉',
      cancel: '取消',
      errors: '錯誤',
      warnings: '警告',
      fileSelected: '已選擇檔案',
      validationPassed: '驗證通過',
      validationFailed: '驗證失敗',
      exportSuccess: '知識庫導出成功!',
      templateDownloadSuccess: '範本下載成功!',
      confirmReplace: '確認替換整個知識庫嗎?此操作無法復原。',
      resetUpload: '重新選擇檔案',
      selectedFile: '已選擇',
      filePath: '檔案路徑',
      fileSize: '大小',
      fileType: '類型',
      unknown: '未知'
    },
    en: {
      title: 'Knowledge Base Management',
      subtitle: 'Import CSV file to replace entire knowledge base',
      dragText: 'Drag files here, or click to select file',
      supportedFormats: 'Supported formats: CSV, Excel (.xlsx, .xls)',
      maxSize: 'Maximum file size: 10MB',
      selectFile: 'Select File',
      downloadTemplate: 'Download Template',
      exportData: 'Export Knowledge Base',
      upload: 'Confirm Import',
      uploading: 'Importing...',
      processing: 'Processing...',
      validating: 'Validating...',
      success: 'Import Successful!',
      close: 'Close',
      cancel: 'Cancel',
      errors: 'Errors',
      warnings: 'Warnings',
      fileSelected: 'File Selected',
      validationPassed: 'Validation Passed',
      validationFailed: 'Validation Failed',
      exportSuccess: 'Knowledge base exported successfully!',
      templateDownloadSuccess: 'Template downloaded successfully!',
      confirmReplace: 'Are you sure you want to replace the entire knowledge base? This action cannot be undone.',
      resetUpload: 'Select New File',
      selectedFile: 'Selected',
      filePath: 'File Path',
      fileSize: 'Size',
      fileType: 'Type',
      unknown: 'Unknown'
    }
  };

  const t = texts[language];

  // 重置上傳狀態
  const resetUpload = useCallback(() => {
    setSelectedFile(null);
    setValidation(null);
    setUploadProgress({ status: 'idle', progress: 0, message: '' });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, []);

  // 處理拖拽
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, []);

  // 處理檔案選擇
  const handleFileSelect = (file: File) => {
    console.log('=== 檔案選擇 ===');
    console.log('檔案名稱:', file.name);
    console.log('檔案大小:', file.size);
    console.log('檔案類型:', file.type);
    
    // 重置之前的狀態
    setUploadProgress({ status: 'idle', progress: 0, message: '' });
    setSelectedFile(file);
    
    // 立即驗證檔案
    const fileValidation = validateFile(file);
    setValidation(fileValidation);
    
    console.log('驗證結果:', fileValidation);

    if (fileValidation.isValid) {
      toast.success(t.fileSelected);
    } else {
      toast.error(fileValidation.errors.join('\n'));
    }
  };

  // 執行上傳
  const handleUpload = async () => {
    if (!selectedFile || !validation?.isValid) return;

    // 確認對話框
    if (!window.confirm(t.confirmReplace)) {
      return;
    }

    try {
      setUploadProgress({ status: 'uploading', progress: 20, message: t.uploading });
      
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setUploadProgress({ status: 'processing', progress: 60, message: t.processing });
      
      const result = await dataImporter.importData(selectedFile, 'replace');
      
      setUploadProgress({ status: 'validating', progress: 90, message: t.validating });
      
      await new Promise(resolve => setTimeout(resolve, 300));
      
      if (result.success) {
        setUploadProgress({ status: 'success', progress: 100, message: t.success });
        toast.success(result.message);
        
        setTimeout(() => {
          onSuccess?.();
          onClose();
        }, 1500);
      } else {
        throw new Error(result.message);
      }
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '未知錯誤';
      setUploadProgress({ status: 'error', progress: 0, message: `導入失敗: ${errorMessage}` });
      toast.error(`導入失敗: ${errorMessage}`);
      
      // 3秒後自動重置為可重試狀態
      setTimeout(() => {
        setUploadProgress({ status: 'idle', progress: 0, message: '' });
      }, 3000);
    }
  };

  // 執行導出
  const handleExport = () => {
    try {
      dataImporter.downloadKnowledgeBase();
      toast.success(t.exportSuccess);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '未知錯誤';
      toast.error(`導出失敗: ${errorMessage}`);
    }
  };

  // 執行範本下載
  const handleTemplateDownload = () => {
    try {
      dataImporter.downloadTemplate();
      toast.success(t.templateDownloadSuccess);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : '未知錯誤';
      toast.error(`範本下載失敗: ${errorMessage}`);
    }
  };

  // 判斷是否正在上傳中
  const isUploading = ['uploading', 'processing', 'validating'].includes(uploadProgress.status);

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
          {/* 標題欄 */}
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">{t.title}</h2>
              </div>
              <button
                onClick={onClose}
                className="text-white hover:bg-white hover:bg-opacity-20 rounded-full p-2 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
            {/* 工具欄 */}
            <div className="flex flex-wrap gap-4 mb-6">
              <button
                onClick={handleTemplateDownload}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>{t.downloadTemplate}</span>
              </button>
              
              <button
                onClick={handleExport}
                className="flex items-center space-x-2 px-4 py-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-colors"
              >
                <FileDown className="w-4 h-4" />
                <span>{t.exportData}</span>
              </button>

              {/* 重置按鈕 - 當有選擇檔案時顯示 */}
              {selectedFile && (
                <button
                  onClick={resetUpload}
                  disabled={isUploading}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed ml-auto"
                >
                  <X className="w-4 h-4" />
                  <span>{t.resetUpload}</span>
                </button>
              )}
            </div>

            {/* 上傳區域 */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
                isDragOver
                  ? 'border-green-400 bg-green-50'
                  : selectedFile
                  ? 'border-green-300 bg-green-50'
                  : 'border-gray-300 hover:border-green-300'
              }`}
            >
              <div className="flex flex-col items-center space-y-4">
                <div className={`p-4 rounded-full ${selectedFile ? 'bg-green-100' : 'bg-gray-100'}`}>
                  {selectedFile ? (
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  ) : (
                    <Upload className="w-8 h-8 text-gray-400" />
                  )}
                </div>
                
                <div>
                  {selectedFile ? (
                    <div className="space-y-2">
                      <p className="text-sm text-gray-500">{t.selectedFile}:</p>
                      <p className="text-lg font-medium text-gray-700">
                        {selectedFile.name}
                      </p>
                      <p className="text-xs text-gray-400">
                        {(selectedFile.size / 1024).toFixed(2)} KB
                      </p>
                    </div>
                  ) : (
                    <>
                      <p className="text-lg font-medium text-gray-700">{t.dragText}</p>
                      <p className="text-sm text-gray-500 mt-1">{t.supportedFormats}</p>
                      <p className="text-xs text-gray-400">{t.maxSize}</p>
                    </>
                  )}
                </div>

                {!selectedFile && (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                  >
                    {t.selectFile}
                  </button>
                )}
              </div>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={(e) => {
                console.log('檔案輸入變更事件觸發');
                console.log('檔案列表:', e.target.files);
                if (e.target.files?.[0]) {
                  handleFileSelect(e.target.files[0]);
                }
              }}
              className="hidden"
            />

            {/* 檔案資訊顯示 - 只要選擇檔案就顯示 */}
            {selectedFile && (
              <div className="mt-6">
                <div className="rounded-lg p-4 bg-blue-50 border border-blue-200">
                  <div className="flex items-start space-x-3">
                    <FileText className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-blue-800 mb-2">{t.filePath}</h3>
                      <p className="text-sm text-blue-700 break-all font-mono bg-blue-100 p-2 rounded">
                        {selectedFile.name}
                      </p>
                      <div className="mt-2 flex gap-4 text-xs text-blue-600">
                        <span>{t.fileSize}: {(selectedFile.size / 1024).toFixed(2)} KB</span>
                        <span>{t.fileType}: {selectedFile.type || t.unknown}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 驗證結果 */}
            {validation && (
              <div className="mt-6">
                <div className={`rounded-lg p-4 ${
                  validation.isValid ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
                }`}>
                  <div className="flex items-center space-x-2 mb-2">
                    {validation.isValid ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-red-600" />
                    )}
                    <h3 className={`font-medium ${validation.isValid ? 'text-green-800' : 'text-red-800'}`}>
                      {validation.isValid ? t.validationPassed : t.validationFailed}
                    </h3>
                  </div>

                  {validation.errors.length > 0 && (
                    <div className="mt-2">
                      <p className="text-sm font-medium text-red-700 mb-1">{t.errors}:</p>
                      <ul className="text-sm text-red-600 space-y-1">
                        {validation.errors.map((error, index) => (
                          <li key={index}>• {error}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {validation.warnings.length > 0 && (
                    <div className="mt-2">
                      <p className="text-sm font-medium text-yellow-700 mb-1">{t.warnings}:</p>
                      <ul className="text-sm text-yellow-600 space-y-1">
                        {validation.warnings.map((warning, index) => (
                          <li key={index}>• {warning}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 錯誤訊息顯示 */}
            {uploadProgress.status === 'error' && (
              <div className="mt-6">
                <div className="rounded-lg p-4 bg-red-50 border border-red-200">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                    <p className="text-sm text-red-700">{uploadProgress.message}</p>
                  </div>
                </div>
              </div>
            )}

            {/* 按鈕區域 - 只要有選擇檔案就顯示 */}
            {selectedFile && (
              <div className="mt-6 flex gap-4">
                <button
                  onClick={onClose}
                  disabled={isUploading}
                  className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium text-lg"
                >
                  <X className="w-5 h-5" />
                  <span>{t.cancel}</span>
                </button>

                <button
                  onClick={handleUpload}
                  disabled={!validation?.isValid || isUploading || uploadProgress.status === 'success'}
                  className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium text-lg"
                >
                  {isUploading ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      <span>{uploadProgress.message}</span>
                    </>
                  ) : uploadProgress.status === 'success' ? (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      <span>{t.success}</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-5 h-5" />
                      <span>{t.upload}</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* 上傳進度 */}
            {(isUploading || uploadProgress.status === 'success') && (
              <div className="mt-6">
                <div className="bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-300 ${
                      uploadProgress.status === 'success' ? 'bg-green-600' : 'bg-blue-600'
                    }`}
                    style={{ width: `${uploadProgress.progress}%` }}
                  />
                </div>
                <p className="text-sm text-gray-600 mt-2 text-center">{uploadProgress.message}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default QuestionUploader;