import React, { useState, useEffect, useRef } from "react";
import { Volume2, VolumeX, Play, Pause, Maximize2 } from 'lucide-react';
import { useLanguage } from "../contexts/LanguageContext";
import { createPortal } from 'react-dom';

export const AudioPlayer: React.FC = () => {
  const { t, getAudioUrl, language } = useLanguage()
  const audioRef = useRef<HTMLAudioElement>(null)
  
  const [showPrompt, setShowPrompt] = useState(false)
  const [isMinimized, setIsMinimized] = useState(true)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(0.7)
  const [isMuted, setIsMuted] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [currentAudioUrl, setCurrentAudioUrl] = useState(getAudioUrl())

  // 監聽語言切換，更新音頻 URL
  useEffect(() => {
    const newAudioUrl = getAudioUrl()
    if (newAudioUrl !== currentAudioUrl) {
      const wasPlaying = isPlaying
      const currentPosition = currentTime
      
      // 暫停當前播放
      if (audioRef.current) {
        audioRef.current.pause()
      }
      
      // 更新 URL
      setCurrentAudioUrl(newAudioUrl)
      setIsPlaying(false)
      setCurrentTime(0)
      
      // 如果之前正在播放，載入新音頻後繼續播放
      if (wasPlaying && audioRef.current) {
        audioRef.current.load()
        audioRef.current.play().then(() => {
          setIsPlaying(true)
        }).catch((error) => {
          console.error("語言切換後播放失敗:", error)
        })
      }
    }
  }, [language, getAudioUrl, currentAudioUrl, isPlaying, currentTime])


  // 首次訪問提示邏輯
  useEffect(() => {
    const promptSeen = localStorage.getItem("audioPromptSeen");
    const playerMinimized = localStorage.getItem("audioPlayerMinimized");

    if (playerMinimized === "false") {
      setIsMinimized(false);
    }

    if (!promptSeen) {
      const timer = setTimeout(() => {
        setShowPrompt(true);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, []);

  // 音頻事件監聽
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const handleCanPlay = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const handleTimeUpdate = () => {
      if (!isDragging) {
        setCurrentTime(audio.currentTime);
      }
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener("loadedmetadata", handleLoadedMetadata);
    audio.addEventListener("canplay", handleCanPlay);
    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("ended", handleEnded);

    return () => {
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
      audio.removeEventListener("canplay", handleCanPlay);
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("ended", handleEnded);
    };
  }, [isDragging]);

  // 音量控制
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  const handleStartListening = async () => {
    setShowPrompt(false);
    setIsMinimized(false);
    localStorage.setItem("audioPromptSeen", "true");
    localStorage.setItem("audioPlayerMinimized", "false");

    // 強制載入音頻
    if (audioRef.current) {
      audioRef.current.load();
      try {
        await audioRef.current.play();
        setIsPlaying(true);
      } catch (error) {
        console.error("播放失敗:", error);
      }
    }
  };

  const handleDecline = () => {
    setShowPrompt(false);
    setIsMinimized(true);
    localStorage.setItem("audioPromptSeen", "true");
    localStorage.setItem("audioPlayerMinimized", "true");
  };

  const togglePlay = async () => {
    if (!audioRef.current) return;

    try {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        await audioRef.current.play();
        setIsPlaying(true);
      }
    } catch (error) {
      console.error("播放操作失敗:", error);
    }
  };

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    setIsMuted(false);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const handleMinimize = () => {
    setIsMinimized(true);
    localStorage.setItem("audioPlayerMinimized", "true");
  };

  const handleExpand = () => {
    setIsMinimized(false);
    localStorage.setItem("audioPlayerMinimized", "false");
  };

  const formatTime = (time: number): string => {
    if (!time || isNaN(time) || !isFinite(time)) return "0:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  console.log('AudioPlayer 狀態:', { showPrompt, isMinimized })

  return (
    <>
      <audio
        ref={audioRef}
        src={currentAudioUrl}
        preload="metadata"
      />

      {/* 首次訪問提示卡片 - 使用 Portal 渲染到 body */}
      {showPrompt && createPortal(
        <div className="fixed bottom-24 right-6 z-[60] w-80 bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-6 animate-[slideUp_0.5s_ease-out]">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-full flex items-center justify-center flex-shrink-0">
              <Volume2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800 text-lg mb-1">
                {t("audio.promptTitle")}
              </h3>
              <p className="text-sm text-gray-600">{t("audio.promptSubtitle")}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleStartListening}
              className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-500 text-white py-2.5 px-4 rounded-lg font-medium hover:from-emerald-600 hover:to-teal-600 transition-all"
            >
              {t("audio.startListening")}
            </button>
            <button
              onClick={handleDecline}
              className="flex-1 bg-gray-200 text-gray-700 py-2.5 px-4 rounded-lg font-medium hover:bg-gray-300 transition-all"
            >
              {t("audio.decline")}
            </button>
          </div>
        </div>,
        document.body
      )}

      {/* 音頻播放器 - 永遠顯示 */}
      {isMinimized ? (
        /* 最小化狀態 - 內聯在 Navbar 中 */
        <div className="flex items-center gap-2 ml-4">
          {/* 播放/暫停按鈕 */}
          <button
            onClick={togglePlay}
            className="w-8 h-8 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full flex items-center justify-center hover:from-emerald-600 hover:to-teal-600 transition-all shadow-lg"
            title={isPlaying ? t("audio.pause") : t("audio.play")}
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 text-white" />
            ) : (
              <Play className="w-4 h-4 text-white ml-0.5" />
            )}
          </button>

          {/* 展開按鈕 */}
          <button
            onClick={handleExpand}
            className="w-8 h-8 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all"
            title={t("audio.expand")}
          >
            <Maximize2 className="w-4 h-4 text-white" />
          </button>

          {/* 音樂波形動畫 */}
          {isPlaying && (
            <div className="flex items-center gap-1 h-6">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="w-1 bg-emerald-400 rounded-full animate-pulse"
                  style={{
                    height: `${Math.random() * 16 + 8}px`,
                    animationDelay: `${i * 0.15}s`,
                    animationDuration: '0.6s'
                  }}
                />
              ))}
            </div>
          )}
        </div>
      ) : (
        /* 完整播放器 - 固定在右上角 */
        <div className="fixed top-20 right-6 z-40 w-80 md:w-96 bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-6 animate-[fadeIn_0.3s_ease-out]">
          {/* 頂部控制按鈕 */}
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-800 text-lg">
              {t("audio.title")}
            </h3>
            <button
              onClick={handleMinimize}
              className="text-emerald-500 hover:text-emerald-600 transition-colors"
              title={t("audio.minimize")}
            >
              <Maximize2 className="w-5 h-5 rotate-180" />
            </button>
          </div>

          {/* 播放按鈕 */}
          <div className="flex items-center gap-4 mb-4">
            <button
              onClick={togglePlay}
              className="w-14 h-14 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full flex items-center justify-center hover:from-emerald-600 hover:to-teal-600 transition-all shadow-lg"
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 text-white" />
              ) : (
                <Play className="w-6 h-6 text-white ml-1" />
              )}
            </button>
            <div className="flex-1">
              <div className="text-sm text-gray-600 mb-1">
                {formatTime(currentTime)} / {formatTime(duration)}
              </div>
              <input
                type="range"
                min="0"
                max={duration || 0}
                value={currentTime}
                onChange={handleProgressChange}
                onMouseDown={() => setIsDragging(true)}
                onMouseUp={() => setIsDragging(false)}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer audio-progress-bar"
                style={{
                  background: `linear-gradient(to right, #10b981 0%, #10b981 ${
                    duration ? (currentTime / duration) * 100 : 0
                  }%, #e5e7eb ${duration ? (currentTime / duration) * 100 : 0}%, #e5e7eb 100%)`
                }}
              />
            </div>
          </div>

          {/* 音量控制 */}
          <div className="flex items-center gap-3">
            <button
              onClick={toggleMute}
              className="text-gray-600 hover:text-emerald-500 transition-colors"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-5 h-5" />
              ) : (
                <Volume2 className="w-5 h-5" />
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={isMuted ? 0 : volume}
              onChange={handleVolumeChange}
              className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer audio-volume-bar"
              style={{
                background: `linear-gradient(to right, #10b981 0%, #10b981 ${
                  (isMuted ? 0 : volume) * 100
                }%, #e5e7eb ${(isMuted ? 0 : volume) * 100}%, #e5e7eb 100%)`
              }}
            />
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: scale(0.9);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .audio-progress-bar::-webkit-slider-thumb {
          appearance: none;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #10b981;
          cursor: pointer;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .audio-progress-bar::-moz-range-thumb {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #10b981;
          cursor: pointer;
          border: none;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .audio-volume-bar::-webkit-slider-thumb {
          appearance: none;
          width: 14px;
          height: 14px;
          border-radius: 50%;
          background: #10b981;
          cursor: pointer;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .audio-volume-bar::-moz-range-thumb {
          width: 14px;
          height: 14px;
          border-radius: 50%;
          background: #10b981;
          cursor: pointer;
          border: none;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }
      `}</style>
    </>
  );
};
