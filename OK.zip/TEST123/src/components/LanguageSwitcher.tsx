import React from 'react'
import { useLanguage } from '../contexts/LanguageContext'

const LanguageSwitcher: React.FC = () => {
  const { language, setLanguage } = useLanguage()

  return (
    <div className="flex items-center space-x-2">
      <button
        onClick={() => setLanguage('zh')}
        className={`px-3 py-1 text-sm rounded transition-colors ${
          language === 'zh'
            ? 'bg-emerald-600 text-white'
            : 'text-gray-600 hover:text-emerald-600'
        }`}
      >
        中文
      </button>
      <span className="text-gray-400">|</span>
      <button
        onClick={() => setLanguage('en')}
        className={`px-3 py-1 text-sm rounded transition-colors ${
          language === 'en'
            ? 'bg-emerald-600 text-white'
            : 'text-gray-600 hover:text-emerald-600'
        }`}
      >
        EN
      </button>
    </div>
  )
}

export default LanguageSwitcher
 
