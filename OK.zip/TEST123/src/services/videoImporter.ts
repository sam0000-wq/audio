import ExcelJS from 'exceljs';
import { videoBase, VideoItem } from './videoBase';
import type { ValidationResult, ProcessedVideoItem, VideoCSVRow } from '../types/uploadTypes';

class VideoImporter {
  private static instance: VideoImporter;
  private videos: VideoItem[] = [...videoBase];
  private listeners: Set<() => void> = new Set();

  private constructor() {}

  static getInstance(): VideoImporter {
    if (!VideoImporter.instance) {
      VideoImporter.instance = new VideoImporter();
    }
    return VideoImporter.instance;
  }

  // 訂閱更新事件
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  // 通知所有訂閱者
  private notify(): void {
    this.listeners.forEach(listener => listener());
  }

  // 取得所有影片
  getAllVideos(): VideoItem[] {
    return this.videos;
  }

  // 取得 Hero Section 影片
  getHeroVideos(): VideoItem[] {
    return this.videos.filter(v => v.category === 'hero' && v.enabled);
  }

  // 取得 Gallery 影片
  getGalleryVideos(): VideoItem[] {
    return this.videos.filter(v => v.category === 'gallery' && v.enabled);
  }

  // 新增影片
  addVideo(video: VideoItem): void {
    this.videos.push(video);
    this.notify();
  }

  // 更新影片
  updateVideo(videoId: string, updatedVideo: VideoItem): void {
    const index = this.videos.findIndex(v => v.videoId === videoId);
    if (index !== -1) {
      this.videos[index] = updatedVideo;
      this.notify();
    }
  }

  // 刪除影片
  deleteVideo(videoId: string): void {
    this.videos = this.videos.filter(v => v.videoId !== videoId);
    this.notify();
  }

  // 驗證 Excel 檔案
  async validateExcelFile(file: File): Promise<ValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];

    try {
      const workbook = new ExcelJS.Workbook();
      const arrayBuffer = await file.arrayBuffer();
      await workbook.xlsx.load(arrayBuffer);

      const worksheet = workbook.getWorksheet(1);
      if (!worksheet) {
        errors.push('找不到工作表');
        return { isValid: false, errors, warnings };
      }

      const headerRow = worksheet.getRow(1);
      const headers = headerRow.values as any[];
      
      const requiredColumns = ['videoId', 'title_zh', 'title_en', 'description_zh', 'description_en', 'category', 'enabled'];
      
      requiredColumns.forEach(col => {
        if (!headers.includes(col)) {
          errors.push(`缺少必要欄位: ${col}`);
        }
      });

      if (worksheet.rowCount < 2) {
        warnings.push('檔案中沒有資料行');
      }

      return {
        isValid: errors.length === 0,
        errors,
        warnings
      };

    } catch (error) {
      errors.push(`檔案解析失敗: ${error instanceof Error ? error.message : '未知錯誤'}`);
      return { isValid: false, errors, warnings };
    }
  }

  // 匯入 Excel
  async importFromExcel(file: File): Promise<{ success: boolean; message: string }> {
    try {
      const validation = await this.validateExcelFile(file);
      if (!validation.isValid) {
        throw new Error(validation.errors.join(', '));
      }

      // 上傳到本地服務器
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('http://localhost:3001/api/upload-videos', {
        method: 'POST',
        body: formData
      });

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.message);
      }


   // 成功後重新載入頁面
      setTimeout(() => {
        window.location.reload();
      }, 500);

      return {
        success: true,
        message: result.message,
      };

    } catch (error) {
      return {
        success: false,
        message: error instanceof Error ? error.message : '匯入失敗'
      };
    }
  }

  // 匯出 Excel
  async exportToExcel(): Promise<void> {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Videos');

    // 設定欄位
    worksheet.columns = [
      { header: 'videoId', key: 'videoId', width: 20 },
      { header: 'title_zh', key: 'title_zh', width: 40 },
      { header: 'title_en', key: 'title_en', width: 40 },
      { header: 'description_zh', key: 'description_zh', width: 50 },
      { header: 'description_en', key: 'description_en', width: 50 },
      { header: 'category', key: 'category', width: 15 },
      { header: 'enabled', key: 'enabled', width: 10 }
    ];

    // 加入資料
    this.videos.forEach(video => {
      worksheet.addRow({
        videoId: video.videoId,
        title_zh: video.title_zh,
        title_en: video.title_en,
        description_zh: video.description_zh,
        description_en: video.description_en,
        category: video.category,
        enabled: video.enabled
      });
    });

    // 下載
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `videos-${new Date().toISOString().split('T')[0]}.xlsx`;
    link.click();
    URL.revokeObjectURL(url);
  }

  // 下載範本
  async downloadTemplate(): Promise<void> {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Videos Template');

    worksheet.columns = [
      { header: 'videoId', key: 'videoId', width: 20 },
      { header: 'title_zh', key: 'title_zh', width: 40 },
      { header: 'title_en', key: 'title_en', width: 40 },
      { header: 'description_zh', key: 'description_zh', width: 50 },
      { header: 'description_en', key: 'description_en', width: 50 },
      { header: 'category', key: 'category', width: 15 },
      { header: 'enabled', key: 'enabled', width: 10 }
    ];

    // 範例資料
    worksheet.addRow({
      videoId: 'PK7veIY94Rc',
      title_zh: '範例影片標題',
      title_en: 'Example Video Title',
      description_zh: '範例描述',
      description_en: 'Example Description',
      category: 'hero',
      enabled: true
    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'video-template.xlsx';
    link.click();
    URL.revokeObjectURL(url);
  }
}

export default VideoImporter;