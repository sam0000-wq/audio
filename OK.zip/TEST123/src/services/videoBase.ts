// src/services/videoBase.ts

export interface VideoItem {
  videoId: string;
  title_zh: string;
  title_en: string;
  description_zh: string;
  description_en: string;
  category: 'hero' | 'gallery';
  enabled: boolean;
}

export const videoBase: VideoItem[] = [
  {
    "videoId": "PK7veIY94Rc",
    "title_zh": "客戶回訪實錄。",
    "title_en": "Customer Revisit Record.",
    "description_zh": "",
    "description_en": "",
    "category": "hero",
    "enabled": true
  },
  {
    "videoId": "GhZYPoq9-P0",
    "title_zh": "重要關鍵—信賴EGD。",
    "title_en": "Key Factor—Trust EGD.",
    "description_zh": "",
    "description_en": "",
    "category": "hero",
    "enabled": true
  },
  {
    "videoId": "INnUG4JHrOQ",
    "title_zh": "您的擔心，都被「都值得了」取代。",
    "title_en": "Your Worries, All Replaced by \"It Was Worth It\".",
    "description_zh": "",
    "description_en": "",
    "category": "hero",
    "enabled": true
  },
  {
    "videoId": "TFQMGVSEOA4",
    "title_zh": "侘寂之境(Wabi-Sabi)，極簡美學。",
    "title_en": "Wabi-Sabi Realm, Minimalist Aesthetics.",
    "description_zh": "",
    "description_en": "",
    "category": "hero",
    "enabled": true
  },
  {
    "videoId": "h8edKG3H-6Y",
    "title_zh": "台灣EGD: 願美好永遠存在。",
    "title_en": "Taiwan EGD: May Goodness Forever Endure.",
    "description_zh": "",
    "description_en": "",
    "category": "hero",
    "enabled": true
  },
  {
    "videoId": "byFTTj1znH0",
    "title_zh": "再有難度-用心作園藝。",
    "title_en": "No Matter How Difficult—Gardening with Heart.",
    "description_zh": "",
    "description_en": "",
    "category": "hero",
    "enabled": true
  },
  {
    "videoId": "uwDDYu8mI3Q",
    "title_zh": "帶你上雲端！為高空定義真正的夢幻花園。",
    "title_en": "Take You to the Clouds! Defining a True Dream Garden at Heights.",
    "description_zh": "",
    "description_en": "",
    "category": "hero",
    "enabled": true
  },
  {
    "videoId": "ddGXcJUxORM",
    "title_zh": "征服困難崎零地，打造夢幻庭園!",
    "title_en": "Conquer Difficult Terrain, Create a Dream Garden!",
    "description_zh": "",
    "description_en": "",
    "category": "hero",
    "enabled": true
  },
  {
    "videoId": "rfS4HxVM1ps",
    "title_zh": "植癒生活:讓美好,在指尖與花葉間永續。",
    "title_en": "Plant Healing Life: Let Beauty Flourish Sustainably, Between Your Fingertips and the Greenery.",
    "description_zh": "植癒生活:讓美好,在指尖與花葉間永續。",
    "description_en": "Plant Healing Life: Let Beauty Flourish Sustainably, Between Your Fingertips and the Greenery.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "o3qBmM54Fbs",
    "title_zh": "視覺魔術-瞬間上色!",
    "title_en": "Visual Alchemy! Monochrome Rendered in Color!",
    "description_zh": "視覺魔術-瞬間上色!",
    "description_en": "Visual Alchemy! Monochrome Rendered in Color!",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "U_XKi919euc",
    "title_zh": "超越視野-定義新標竿。",
    "title_en": "Beyond the Horizon: Defining the New Benchmark.",
    "description_zh": "超越視野-定義新標竿。",
    "description_en": "Beyond the horizon: Defining the new benchmark.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "xm3UtfIysl0",
    "title_zh": "施工、驗收與完美交付!",
    "title_en": "Execution, Verification, and Perfect Handoff!",
    "description_zh": "施工、驗收與完美交付!",
    "description_en": "Execution, Verification, and Perfect Handoff!",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "9au64VDA06k",
    "title_zh": "復育生態鏈:給下一代最好的禮物。",
    "title_en": "The Ultimate Forest Gift for the Next Generation.",
    "description_zh": "復育生態鏈:給下一代最好的禮物。",
    "description_en": "The Ultimate Forest Gift for the Next Generation.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "GO9AFVEqFzk",
    "title_zh": "秋日黃金海",
    "title_en": "A Golden Sea in Autumn, Dyeing a Thousand Peaks.",
    "description_zh": "秋日黃金海",
    "description_en": "A Golden Sea in Autumn, Dyeing a Thousand Peaks.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "0N4J6sYIr50",
    "title_zh": "草地變魔戒森林？頻率是關鍵！",
    "title_en": "Frequency is the Key!",
    "description_zh": "草地變魔戒森林？頻率是關鍵！",
    "description_en": "Frequency is the Key!",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "SV9H23E_R9Q",
    "title_zh": "15秒!就是台灣系列: 預告片。",
    "title_en": "Taiwan in 15 Seconds! The Teaser.",
    "description_zh": "15秒!就是台灣系列: 預告片。",
    "description_en": "Taiwan in 15 Seconds! The Teaser.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "ylhvXL8ueW0",
    "title_zh": "從零到有,實現你的夢幻花園。",
    "title_en": "From Zero to Bloom: Realize Your Dream Garden.",
    "description_zh": "從零到有,實現你的夢幻花園。",
    "description_en": "From Zero to Bloom: Realize your dream garden.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "Rdg3Wo8p5bU",
    "title_zh": "白領: 享受周末的園藝時光!",
    "title_en": "Our Dreamy Weekend Indoor Gardening Routine.",
    "description_zh": "白領: 享受周末的園藝時光!",
    "description_en": "Our Dreamy Weekend Indoor Gardening Routine.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "AOUNGkD064I",
    "title_zh": "從積水到美景: 雨水花園。",
    "title_en": "Building Our Dream Rain Garden from Scratch.",
    "description_zh": "從積水到美景: 雨水花園。",
    "description_en": "Building Our Dream Rain Garden from Scratch.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "ryaP_GS_Hi8",
    "title_zh": "肖楠: 種子覺醒。",
    "title_en": "Seed to Life",
    "description_zh": "肖楠: 種子覺醒。",
    "description_en": "Seed to Life",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "K879oNZvLr8",
    "title_zh": "月桃: 何止是記憶,更是溫暖印記。",
    "title_en": "It's Grandma's Warm Legacy.",
    "description_zh": "月桃: 何止是記憶,更是溫暖印記。",
    "description_en": "It's Grandma's Warm Legacy.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "-4x07g4rlxo",
    "title_zh": "ESG-綠色永續營運。",
    "title_en": "ESG - Green Sustainable Operations.",
    "description_zh": "ESG-綠色永續營運。",
    "description_en": "ESG - Green Sustainable Operations.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "hO_fIaq0mjA",
    "title_zh": "浪載星屑，灣藏夢幻光。",
    "title_en": "Waves Carry Stardust, the Bay Holds a Magical Light.",
    "description_zh": "浪載星屑，灣藏夢幻光。",
    "description_en": "Waves carry stardust, the bay holds a magical light.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "hoYBYkCaoxg",
    "title_zh": "台灣衫: 極致的心靈森呼吸。",
    "title_en": "Give Your Mind the Ultimate Forest Bathing (Shinrin-yoku).",
    "description_zh": "台灣衫: 極致的心靈森呼吸。",
    "description_en": "Give Your Mind the Ultimate Forest Bathing (Shinrin-yoku).",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "oLwpEJpcd3k",
    "title_zh": "玉山圓柏: 環境再艱苦也絕不放棄。",
    "title_en": "A Resilience Guide",
    "description_zh": "玉山圓柏: 環境再艱苦也絕不放棄。",
    "description_en": "A Resilience Guide",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "rDlbaw7znEs",
    "title_zh": "藍眼淚，共同守護藍色星魂。",
    "title_en": "The Emotion of Guarding the Blue Star Soul.",
    "description_zh": "藍眼淚，共同守護藍色星魂。",
    "description_en": "The Emotion of Guarding the Blue Star Soul.",
    "category": "gallery",
    "enabled": true
  },
  {
    "videoId": "sFtCKquZYwM",
    "title_zh": "退休不空虛：告別無聊人生的實用指南。",
    "title_en": "A Practical Guide to Saying Goodbye to a Boring Life.",
    "description_zh": "退休不空虛：告別無聊人生的實用指南。",
    "description_en": "A Practical Guide to Saying Goodbye to a Boring Life.",
    "category": "gallery",
    "enabled": true
  }
];
