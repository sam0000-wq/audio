import { useState, useEffect, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";
import {
  VisitorLog,
  ChartData,
  CountryData,
  ComparisonStats,
  TimeRange,
  OperationLog,
  OperationStats,
  MILESTONES
} from "../constants/analyticsConstants";

import { supabase } from "../lib/supabase";

export const useAnalyticsData = () => {
  const [visitors, setVisitors] = useState<VisitorLog[]>([]);
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [countryData, setCountryData] = useState<CountryData[]>([]);
  const [timeRange, setTimeRange] = useState<TimeRange>("week");
  const [loading, setLoading] = useState(true);
  const [totalVisits, setTotalVisits] = useState(0);
  const [uniqueVisitors, setUniqueVisitors] = useState(0);
  const [comparisonStats, setComparisonStats] = useState<ComparisonStats | null>(null);
  const [reachedMilestone, setReachedMilestone] = useState<number | null>(null);

  const [cookieConsent, setCookieConsent] = useState<boolean | null>(null);
  const [showCookieConsent, setShowCookieConsent] = useState(false);

  const [operationLogs, setOperationLogs] = useState<OperationLog[]>([]);
  const [operationStats, setOperationStats] = useState<OperationStats | null>(null);
  const [logFilter, setLogFilter] = useState<string | null>(null);
  const [logsLoading, setLogsLoading] = useState(false);

  const [hoveredCountry, setHoveredCountry] = useState<string | null>(null);

  const checkMilestone = useCallback((visitorCount: number) => {
    const achievedMilestones = MILESTONES.filter(m => visitorCount >= m);
    const highestMilestone = achievedMilestones[achievedMilestones.length - 1];
    
    if (highestMilestone) {
      setReachedMilestone(highestMilestone);
    }
  }, []);

  // ✅ 新版：使用 Supabase Function 自動記錄 IP
  const trackVisitor = useCallback(async () => {
    if (cookieConsent === false) return;
    
    try {
      const { data, error } = await supabase.rpc('track_visitor', {
        p_user_agent: navigator.userAgent
      });

      if (error) {
        console.error("❌ 追蹤失敗:", error);
      } else {
        console.log("✅ 訪客已記錄，IP:", data?.ip);
      }
    } catch (error) {
      console.error("❌ 追蹤錯誤:", error);
    }
  }, [cookieConsent]);

  const calculateCountryData = useCallback((data: VisitorLog[]) => {
    const countryMap = new Map<string, { count: number; visitors: number }>();

    data.forEach((visitor) => {
      const country = visitor.country || "Unknown";
      const existing = countryMap.get(country) || { count: 0, visitors: 0 };
      countryMap.set(country, {
        count: existing.count + visitor.visit_count,
        visitors: existing.visitors + 1,
      });
    });

    const countryArray = Array.from(countryMap.entries())
      .map(([country, data]) => ({
        country,
        count: data.count,
        visitors: data.visitors,
      }))
      .sort((a, b) => b.count - a.count);

    setCountryData(countryArray);
  }, []);

  const calculateComparison = useCallback((data: VisitorLog[], range: TimeRange) => {
    const now = new Date();
    let currentStart: Date, currentEnd: Date, previousStart: Date, previousEnd: Date;

    if (range === "week") {
      currentEnd = now;
      currentStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      previousEnd = new Date(currentStart.getTime() - 1);
      previousStart = new Date(previousEnd.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (range === "twoWeeks") {
      currentEnd = now;
      currentStart = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
      previousEnd = new Date(currentStart.getTime() - 1);
      previousStart = new Date(previousEnd.getTime() - 14 * 24 * 60 * 60 * 1000);
    } else if (range === "month") {
      currentEnd = now;
      currentStart = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      previousEnd = new Date(currentStart.getTime() - 1);
      previousStart = new Date(previousEnd.getTime() - 30 * 24 * 60 * 60 * 1000);
    } else {
      currentEnd = now;
      currentStart = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
      previousEnd = new Date(currentStart.getTime() - 1);
      previousStart = new Date(previousEnd.getTime() - 365 * 24 * 60 * 60 * 1000);
    }

    const currentTotal = data.reduce((sum, visitor) => {
      const visitDate = new Date(visitor.last_visit);
      if (visitDate >= currentStart && visitDate <= currentEnd) {
        return sum + visitor.visit_count;
      }
      return sum;
    }, 0);

    const previousTotal = data.reduce((sum, visitor) => {
      const visitDate = new Date(visitor.last_visit);
      if (visitDate >= previousStart && visitDate <= previousEnd) {
        return sum + visitor.visit_count;
      }
      return sum;
    }, 0);

    const changePercent = previousTotal === 0 
      ? (currentTotal > 0 ? 100 : 0)
      : ((currentTotal - previousTotal) / previousTotal) * 100;

    const changeType: "increase" | "decrease" | "neutral" = 
      changePercent > 0 ? "increase" : changePercent < 0 ? "decrease" : "neutral";

    setComparisonStats({
      currentTotal,
      previousTotal,
      changePercent,
      changeType,
    });
  }, []);

  const generateChartDataWithComparison = useCallback((data: VisitorLog[], range: TimeRange) => {
    const now = new Date();
    const chartMap = new Map<string, number>();
    const compareMap = new Map<string, number>();

    let daysBack = 7;
    let dateFormat: (date: Date) => string = (d) =>
      `${d.getMonth() + 1}/${d.getDate()}`;

    if (range === "twoWeeks") {
      daysBack = 14;
    } else if (range === "month") {
      daysBack = 30;
    } else if (range === "year") {
      daysBack = 365;
      dateFormat = (d) => `${d.getFullYear()}/${d.getMonth() + 1}`;
    }

    for (let i = daysBack - 1; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      const key = dateFormat(date);
      chartMap.set(key, 0);
    }

    for (let i = daysBack - 1; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - daysBack - i);
      const key = dateFormat(date);
      compareMap.set(key, 0);
    }

    data.forEach((visitor) => {
      const visitDate = new Date(visitor.last_visit);
      const daysDiff = Math.floor(
        (now.getTime() - visitDate.getTime()) / (1000 * 60 * 60 * 24)
      );

      if (daysDiff < daysBack) {
        const key = dateFormat(visitDate);
        chartMap.set(key, (chartMap.get(key) || 0) + visitor.visit_count);
      } else if (daysDiff >= daysBack && daysDiff < daysBack * 2) {
        const key = dateFormat(visitDate);
        compareMap.set(key, (compareMap.get(key) || 0) + visitor.visit_count);
      }
    });

    const chartArray = Array.from(chartMap.entries()).map(([date, count], index) => {
      const compareValues = Array.from(compareMap.values());
      return {
        date,
        count,
        compareCount: compareValues[index] || 0,
      };
    });

    setChartData(chartArray);
  }, []);

  const fetchVisitorData = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("visitor_logs")
        .select("*")
        .order("last_visit", { ascending: false });

      if (error) {
        console.error("Error fetching visitors:", error);
        return;
      }

      setVisitors(data || []);
      
      const total = (data || []).reduce((sum, v) => sum + v.visit_count, 0);
      setTotalVisits(total);
      const uniqueCount = (data || []).length;
      setUniqueVisitors(uniqueCount);
      
      checkMilestone(uniqueCount);
      generateChartDataWithComparison(data || [], timeRange);
      calculateComparison(data || [], timeRange);
      calculateCountryData(data || []);
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  }, [timeRange, calculateCountryData, checkMilestone, calculateComparison, generateChartDataWithComparison]);

  const fetchOperationLogs = useCallback(async () => {
    setLogsLoading(true);
    try {
      const { data, error } = await supabase
        .rpc("get_operation_logs", {
          p_limit: 100,
          p_offset: 0,
          p_operation_type: logFilter
        });

      if (error) {
        console.error("Error fetching operation logs:", error);
        return;
      }

      setOperationLogs(data || []);
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLogsLoading(false);
    }
  }, [logFilter]);

  const fetchOperationStats = useCallback(async () => {
    try {
      const { data, error } = await supabase.rpc("get_operation_stats");

      if (error) {
        console.error("Error fetching operation stats:", error);
        return;
      }

      setOperationStats(data || null);
    } catch (error) {
      console.error("Error:", error);
    }
  }, []);

  useEffect(() => {
    const consent = localStorage.getItem("visitor_tracking_consent");
    if (consent === null) {
      setShowCookieConsent(true);
      setCookieConsent(null);
    } else {
      setCookieConsent(consent === "true");
    }
  }, []);

  useEffect(() => {
    if (cookieConsent === true) {
      trackVisitor();
    }
  }, [cookieConsent, trackVisitor]);

  useEffect(() => {
    if (visitors.length > 0) {
      generateChartDataWithComparison(visitors, timeRange);
      calculateComparison(visitors, timeRange);
    }
  }, [timeRange, visitors, calculateComparison, generateChartDataWithComparison]);

  const handleCookieConsent = (accepted: boolean) => {
    localStorage.setItem("visitor_tracking_consent", accepted.toString());
    setCookieConsent(accepted);
    setShowCookieConsent(false);
    
    if (accepted) {
      trackVisitor();
    }
  };

  return {
    visitors,
    chartData,
    countryData,
    timeRange,
    setTimeRange,
    loading,
    totalVisits,
    uniqueVisitors,
    comparisonStats,
    reachedMilestone,
    cookieConsent,
    showCookieConsent,
    handleCookieConsent,
    fetchVisitorData,
    operationLogs,
    operationStats,
    logFilter,
    setLogFilter,
    logsLoading,
    fetchOperationLogs,
    fetchOperationStats,
    hoveredCountry,
    setHoveredCountry,
  };
};