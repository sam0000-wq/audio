import React, { useState, lazy, Suspense } from 'react'
import { LanguageProvider } from './contexts/LanguageContext'
import Navbar from './components/Navbar'
import HeroSection from './components/HeroSection'
{/*  import { AudioPlayer } from './components/AudioPlayer' */}
import VideoManager from "./components/VideoManager"
import KnowledgeBaseManager from "./components/KnowledgeBaseManager"


{/* 動態導入非首屏組件(Code Splitting) */}
const AboutSection = lazy(() => import('./components/AboutSection'))
const ServicesSection = lazy(() => import('./components/ServicesSection'))
const PortfolioSection = lazy(() => import('./components/PortfolioSection'))
const TestimonialsSection = lazy(() => import('./components/TestimonialsSection'))
const YouTubeGallery = lazy(() => import('./components/YouTubeGallery'))
const ContactSection = lazy(() => import('./components/ContactSection'))
const Footer = lazy(() => import('./components/Footer'))
const VideoModal = lazy(() => import('./components/VideoModal'))
const ChatBot = lazy(() => import('./components/ChatBot/ChatBot'))
const VisitorAnalytics = lazy(() => import('./components/VisitorAnalytics'))

function App() {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)

  const openVideoModal = () => {
    setIsVideoModalOpen(true)
  }

  const closeVideoModal = () => {
    setIsVideoModalOpen(false)
  }

  return (
    <LanguageProvider>
      <div className="min-h-screen bg-[#0B0919] text-white">
        <Navbar />
        <main>
          <HeroSection onPlayVideo={openVideoModal} />
          
          {/* Suspense 包裹延遲載入的組件 */}
          <Suspense fallback={
            <div className="flex items-center justify-center py-20">
              <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
            </div>
          }>
            <AboutSection />
            <ServicesSection />
            <PortfolioSection onPlayVideo={openVideoModal} />
            <YouTubeGallery />
            <TestimonialsSection />
            <ContactSection />
          </Suspense>
        </main>
        
        <Suspense fallback={null}>
          <Footer />
        </Suspense>
        
        {/* 視頻模態框 - 延遲載入 */}
        <Suspense fallback={null}>
          {isVideoModalOpen && (
            <VideoModal
              isOpen={isVideoModalOpen}
              onClose={closeVideoModal}
            />
          )}
        </Suspense>
        
        {/* 聊天機器人 - 延遲載入 */}
        <Suspense fallback={null}>
          <ChatBot />
        </Suspense>
        
        {/* 訪客分析組件 - 延遲載入 */}
        <Suspense fallback={null}>
          <VisitorAnalytics />
        </Suspense>
        
        {/* 多語言音頻播放器 - 自動根據語言切換 
        <AudioPlayer />  */}
      </div>
    </LanguageProvider>
  )
}

export default App
