import type { UserConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import { defineConfig } from 'vite'
import JavaScriptObfuscator from 'vite-plugin-javascript-obfuscator'

export default defineConfig(({ mode }) => {
  let build: UserConfig['build'], esbuild: UserConfig['esbuild'], define: UserConfig['define']
  let plugins = [react()]

  if (mode === 'development') {
    build = {
      minify: false,
      sourcemap: true,
      rollupOptions: {
        output: {
          manualChunks: undefined,
        },
      },
    }

    esbuild = {
      jsxDev: true,
      keepNames: true,
      minifyIdentifiers: false,
    }

    define = {
      'process.env.NODE_ENV': '"development"',
      '__DEV__': 'true',
    }
  } else {
    build = {
      sourcemap: false,
      rollupOptions: {
        output: {
          manualChunks(id) {
            // React 相關庫
            if (id.includes('node_modules/react') || 
                id.includes('node_modules/react-dom') || 
                id.includes('node_modules/react-router-dom')) {
              return 'react-vendor'
            }
            
            // Supabase
            if (id.includes('node_modules/@supabase')) {
              return 'supabase'
            }
            
            // UI 庫
            if (id.includes('node_modules/lucide-react')) {
              return 'ui-libs'
            }
            
            // 🔥 每個 component 打包成獨立檔案
            if (id.includes('/components/')) {
              const match = id.match(/\/components\/([^/]+)\.(tsx|ts|jsx|js)/)
              if (match) {
                return match[1]
              }
            }
          },
          entryFileNames: 'assets/[name]-[hash].js',
          chunkFileNames: 'assets/[name]-[hash].js',
        }
      },
      chunkSizeWarningLimit: 10000
    }

    plugins.push(
      JavaScriptObfuscator({
        include: ['src/**/*.tsx', 'src/**/*.ts'],
        exclude: [
          '**/react-vendor*.js',
          '**/supabase*.js',
          '**/ui-libs*.js'
        ],
        options: {
          compact: true,
          controlFlowFlattening: false,
          deadCodeInjection: false,
          stringArray: true,
          stringArrayThreshold: 0.75
        }
      })
    )
  }

  return {
    plugins,
    build,
    esbuild,
    define,
    resolve: {
      alias: {
        '@': '/src',
      }
    },
    optimizeDeps: {
      exclude: ['lucide-react'],
    },
    server: {
      port: 5173,
    },
    preview: {
      port: 4173,
    }
  }
})